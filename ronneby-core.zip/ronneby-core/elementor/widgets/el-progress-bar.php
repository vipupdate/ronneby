<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Progress_Bar extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_progress_bar';
	}

	public function get_title() {
		return esc_html__('DFD Progress bar', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'progressbar';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_progress_bar',
			[
				'label' => esc_html__('Progress bar', 'dfd'),
			]
		);
		
		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Simple', 'dfd'),
					'layout-2' => esc_html__('Bordered', 'dfd'),
					'layout-3' => esc_html__('Diagonal', 'dfd'),
					'layout-4' => esc_html__('Tiled', 'dfd')
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'percent',
			[
				'label' => esc_html__('Progress value', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'animate_progress',
			[
				'label' => esc_html__('Progress animation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'animate_lines',
			[
				'label' => esc_html__('Slanting lines decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [
					'main_layout' => 'layout-3'
				]
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'text_position',
			[
				'label' => esc_html__('Title position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'top' => esc_html__('Top', 'dfd'),
					'bottom' => esc_html__('Bottom', 'dfd')
				],
				'default' => 'top'
			]
		);
		
		$this->add_control(
			'delim_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				],
				'condition' => [
					'main_layout' => 'layout-4'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_progress_line',
			[
				'label' => esc_html__('Progress line', 'dfd'),
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'progress_background_gradient',
				'label' => esc_html__('Background', 'dfd'),
				'types' => ['gradient'],
				'selector' => '{{WRAPPER}} .meter'
			]
		);
		
		$this->add_control(
			'height',
			[
				'label' => esc_html__('Progress line height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_progress_back',
			[
				'label' => esc_html__('Back line', 'dfd'),
			]
		);
		
		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3']
				]
			]
		);
		
		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				],
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3']
				]
			]
		);
		
		$this->add_control(
			'bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .progressbar-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .progressbar-title' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'number_html_tag',
			[
				'label' => esc_html__('Number HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'separator' => 'before',
				'default' => 'div',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-number-typography',
				'label' => esc_html__('Number typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .progressbar-number',
			]
		);
		
		$this->add_control(
			'number_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Number color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .progressbar-number' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
	}

	protected function render() {

		$line_style = $content_html = $progress_anim_data = $uniqid = $output = $el_class = $link_css = '';

		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-progress-') . '-' . rand(1, 9999);

		if (!empty($settings['title'])) {
			$title_html = '<div class="title-wrap"><' . $settings['title_html_tag'] . ' class="progressbar-title">' . esc_html($settings['title']) . '</' . $settings['title_html_tag'] . '><' . $settings['number_html_tag'] . ' class="progressbar-number">' . $settings['percent'] . '<span>%</span></' . $settings['number_html_tag'] . '></div>';
		} else {
			$title_html = '<div class="title-wrap"><' . $settings['number_html_tag'] . ' class="progressbar-number">' . $settings['percent'] . '<span>%</span></' . $settings['number_html_tag'] . '></div>';
		}

		if ( $settings['bg_color'] || (  $settings['line_border'] !== '0' ) ||  $settings['line_color'] ||  $settings['delim_color'] || (  $settings['height'] !== '8' )) {
			$line_style .= 'style="';
			if ( $settings['bg_color']) {
				$line_style .= 'background:' .  $settings['bg_color'] . '; ';
			}

			$line_style .= 'height:' . ( intval( (int)$settings['height']) + intval( (int)$settings['line_border'] * 2) ) . 'px;';

			if ('layout-4' ===  $settings['main_layout'] &&  $settings['delim_color']) {
				$line_style .= ' color: ' . esc_attr( $settings['delim_color']) . '; ';
			}
			$line_style .= '"';
		}

		if ('0' !==  $settings['percent']) {
			if ('layout-4' ===  $settings['main_layout']) {
				$settings['percent'] = ceil($settings['percent'] / 10) * 10;
			}
			$progress_anim_data = ' data-percentage-value="' . esc_attr(intval( $settings['percent'])) . '"';
		}

		if ($settings['animate_progress'] !== 'yes') {
			$el_class .= ' no-animation ';
		}
		if ('yes' ===  $settings['animate_lines']) {
			$el_class .= ' move-lines ';
		}

		$link_css .= '#' . $uniqid . '.dfd-progressbar.layout-2 .progress-bar-line:before, #' . $uniqid . '.dfd-progressbar.layout-3 .progress-bar-line:before { border-width: ' . esc_attr( $settings['line_border']) . 'px; border-color: ' . esc_attr( $settings['line_color']) . '}';

		$content_html .= '<div class="progress-bar-line" ' . $line_style . '>';
		if ('layout-4' === $settings['main_layout']) {
			for ($i = 1; $i <= 10; $i++) {
				$content_html .= '<span class="vertical-line"></span>';
			}
		}
		$content_html .= '<div  class="meter" ' . $progress_anim_data . '>';
		$content_html .= '</div></div>';

		$output .= '<div id="' . $uniqid . '" class="dfd-progressbar ' . $settings['main_layout'] . ' text-' . $settings['text_position'] . ' ' . esc_attr($el_class) . '">';

		if ('top' === $settings['text_position']) {
			$output .= $title_html;
			$output .= $content_html;
		} else {
			$output .= $content_html;
			$output .= $title_html;
		}

		$output .= '</div>';

		if (!empty($link_css)) {
			$output .= '<script type="text/javascript">
							(function($) {
								$("head").append("<style>' . esc_js($link_css) . '</style>");
							})(jQuery);
						</script>';
		}

		echo $output;
		
	}

}