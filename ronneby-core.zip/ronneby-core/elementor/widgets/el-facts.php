<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Facts extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_facts';
	}

	public function get_title() {
		return esc_html__('DFD Facts', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'facts';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_facts',
			[
				'label' => esc_html__('Facts', 'dfd')
			]
		);

		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Standard', 'dfd'),
					'layout-2' => esc_html__('Top icon', 'dfd'),
					'layout-3' => esc_html__('Bottom icon', 'dfd'),
					'layout-4' => esc_html__('Left counter', 'dfd'),
					'layout-5' => esc_html__('Right counter', 'dfd'),
					'layout-6' => esc_html__('Left icon', 'dfd'),
					'layout-7' => esc_html__('Right icon', 'dfd'),
					'layout-8' => esc_html__('Left number, right title', 'dfd'),
					'layout-9' => esc_html__('Left title, right number', 'dfd')
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'number',
			[
				'label' => esc_html__('Number', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Facts title', 'dfd')
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'transition',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'counter' => esc_html__('Count numbers', 'dfd'),
					'odometer' => esc_html__('Odometr animation', 'dfd'),
					'disable-animation' => esc_html__('Without animation', 'dfd')
				],
				'default' => 'counter'
			]
		);
		
		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					],
				],
				'default' => 'text-left',
				'condition'  => [
					'main_layout' => 'layout-2'
				]
			]
		);
		$this->add_control(
			'number_margin',
			[
				'label' => esc_html__('Number offset top +/-', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition'  => [
					'main_layout' => ['layout-8', 'layout-9']
				]
			]
		);
		
		$this->add_control(
			'title_margin',
			[
				'label' => esc_html__('Title wrap offset top +/-', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition'  => [
					'main_layout' => ['layout-8', 'layout-9']
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_del_style',
			[
				'label' => esc_html__('Delimiter style', 'dfd'),
			]
		);
		
		$this->add_control(
			'line_hide',
			[
				'label' => esc_html__('Enable delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'line_width',
			[
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'line_position',
			[
				'type' => \Elementor\Controls_Manager::SELECT,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'options' => [
					'default' => esc_html__('Default', 'dfd'),
					'top' => esc_html__('Before Title', 'dfd'),
					'medium' => esc_html__('After Title', 'dfd'),
					'bottom' => esc_html__('After Subtitle', 'dfd')
				],
				'default' => 'default',
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_ico_set',
			[
				'label' => esc_html__('Icon settings', 'dfd')
			]
		);
		
		$this->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon', 'dfd'),
					'custom' => esc_html__('Image', 'dfd'),
					'text' => esc_html__('Text', 'dfd')
				],
				'default' => 'selector'
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__('Opacity', 'dfd'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					]
				],
				'default' => [
					'size' => '100'
				],
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'icon_type' => ['selector', 'custom']
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon_hover',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-info-box:hover .module-icon i' => 'color: {{SCHEME}} !important;'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon_image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);

		$this->add_control(
			'icon_text',
			[
				'label' => esc_html__('Text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_icon_font_options',
				'label' => esc_html__('Text icon typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .facts-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .facts-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .facts-subtitle'
			]
		);

		$this->add_control(
			'number_letter_spacing',
			[
				'label' => esc_html__('Letter spacing', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'separator' => 'before'
			]
		);

		$this->add_control(
			'number_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Number color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .odometer' => 'color: {{SCHEME}};'
				]
			]
		); 
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'number_typography',
				'label' => esc_html__('Number typography', 'dfd'),
				'selector' => '{{WRAPPER}} .odometer'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$title_block = $delimiter_html = $delimiter_style = $title_html = $subtitle_html  = $icon_html = '';
		$animation =   $content_html =  '';
		$output = $el_class = $data_max = $facts_number_html = $disable_animation_class = $link_css = $uniqid = '';

		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-facts-') .'-'.rand(1,9999);

		if(isset($settings['main_layout']) && $settings['main_layout'] == 'layout-2') {
			$el_class .= ' '.esc_attr($settings['content_alignment']);
		}
		if(isset($settings['transition']) && !empty($settings['transition'])) {
			$el_class .= ' dfd-'.esc_attr($settings['transition']);
		}

		if ( (!empty($settings['icon']) && $settings['icon'] != 'none') || !empty($settings['icon_image_id']) ) {
			$el_class .= ' with-icon';
			if (isset($settings['icon_size']) && $settings['icon_size'] != '') {
				$link_css .= '#'.esc_js($uniqid).' {min-height: '.esc_js($settings['icon_size']).'px;}';
				$link_css .= '#'.esc_js($uniqid).'.layout-8 .module-icon + .content-wrap {padding-left: '.esc_js($settings['icon_size'] + 20).'px;}';
				$link_css .= '#'.esc_js($uniqid).'.layout-9 .content-wrap {padding-right: '.esc_js($settings['icon_size'] + 20).'px;}';
			}
			$icon_html = '<div class="module-icon">' . dfd_elementor_icon_render($settings) . '</div>';
		}

		if ( ! empty( $settings['title'] ) ) {
			$title_html = '<'.$settings['title_html_tag'].' class="facts-title feature-title">' . esc_html( $settings['title'] ) . '</'.$settings['title_html_tag'].'>';
		}
		if ( ! empty( $settings['subtitle'] ) ) {
			$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="facts-subtitle subtitle">' . wp_kses($settings['subtitle'], array('br' => array())) . '</'.$settings['subtitle_html_tag'].'>';
		}

		if ( $settings['line_width'] || $settings['line_border'] || $settings['line_color'] ) {
			$delimiter_style .= 'style="';
			if ( $settings['line_width'] ) {
				$delimiter_style .= 'width:' . $settings['line_width'] . 'px;';
			}
			if ( $settings['line_border'] ) {
				$delimiter_style .= 'border-width:' . $settings['line_border'] . 'px;';
			}
			if ( $settings['line_color'] ) {
				$delimiter_style .= 'border-color:' . $settings['line_color'];
			}
			$delimiter_style .= '"';
		}
		if($settings['line_hide'] === 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter" ' . $delimiter_style . '></div></div>';
		}

		switch ( $settings['line_position'] ) {
			case 'top':
				$title_block .= $delimiter_html;
				$title_block .= $title_html;
				$title_block .= $subtitle_html;
				break;

			case 'medium':
				$title_block .= $title_html;
				$title_block .= $delimiter_html;
				$title_block .= $subtitle_html;
				break;

			case 'bottom':
				$title_block .= $title_html;
				$title_block .= $subtitle_html;
				$title_block .= $delimiter_html;
				break;

			default:
				$title_block .= $delimiter_html;
				$title_block .= $title_html;
				$title_block .= $subtitle_html;
				break;
		}

		if('counter' === $settings['transition']) {
			$animation = 'count';
		}

		if(isset($settings['number_letter_spacing']) && !empty($settings['number_letter_spacing'])) {
			$letter_spacing = esc_attr($settings['number_letter_spacing']) / 2;
			$link_css .= '#'.esc_js($uniqid).'.dfd-facts-counter .odometer.odometer-auto-theme .odometer-digit {margin: 0 '.esc_js($letter_spacing).'px;}';
		}
		
		if(isset($settings['number_margin']) && $settings['number_margin'] != '') {
			$link_css .= '#'.esc_js($uniqid).' .content-wrap .stat-count {margin-top: '.esc_js($settings['number_margin']).'px;}';
		}
		
		if(isset($settings['title_margin']) && $settings['title_margin'] != '') {
			$link_css .= '#'.esc_js($uniqid).' .content-wrap .tittle-wrap {margin-top: '.esc_js($settings['title_margin']).'px;}';
		}

		if (isset($settings['transition']) && strcmp($settings['transition'], 'disable-animation') === 0) {
			$disable_animation_class = 'disable-animation';
		}
		
		$data_max = 'data-max="' . esc_attr( $settings['number'] ) . '"';
		$facts_number_html .= '<div class="facts-number call-on-waypoint '.$disable_animation_class.'" data-animation="' . esc_attr( $animation ) . '" '.$data_max.' >';
		
		if (isset($settings['transition']) && strcmp($settings['transition'], 'disable-animation') === 0) {
			$facts_number_html .= esc_attr( $settings['number'] );
		}else{
			$facts_number_html .= '0';
		}
		
		$facts_number_html .= '</div>';

		if('layout-1' === $settings['main_layout']) {
			if (intval($settings['icon_size']) !== '80' && !empty($settings['icon_size'])) {
				$wrap_style = 'style="padding-top:' . ( intval( $settings['icon_size'] ) - 60 ) . 'px;"';
			} else {
				$wrap_style = '';
			}
			$content_html .= '<div class="wrap" ' . $wrap_style . '><div class="stat-count">' . $icon_html . ' '.$facts_number_html.' </div></div>';
		} else {
			$content_html .= '<div class="stat-count"> '.$facts_number_html.' </div>';
		}

		$output .= '<div id="'.$uniqid.'" class="dfd-facts-counter ' . $settings['main_layout'] . ' ' . $el_class . '">';

			switch ( $settings['main_layout'] ) {
				case 'layout-1':
					$output .= $content_html;
					$output .= $title_block;
					break;

				case 'layout-2':
					$output .= $icon_html;
					$output .= $content_html;
					$output .= $title_block;
					break;

				case 'layout-3':
					$output .= $content_html;
					if ( ! empty( $settings['line_position'] ) ) {
						$output .= $title_block;
					} else {
						$output .= $title_html;
						$output .= $subtitle_html;
						$output .= $delimiter_html;
					}
					$output .= $icon_html;
					break;

				case 'layout-4':
					$output .= $content_html;
					$output .= $icon_html;
					$output .= $title_block;
					break;

				case 'layout-5':
					$output .= $icon_html;
					$output .= $content_html;
					$output .= $title_block;
					break;

				case 'layout-6':
				case 'layout-7':
					$output .= $icon_html;
					$output .= '<div class="content-wrap">';
					$output .= $content_html;
					$output .= $title_block;
					$output .= '</div>';
					break;

				case 'layout-8':
					$output .= $icon_html;
					$output .= '<div class="content-wrap">';
						$output .= $content_html;
						$output .= '<div class="tittle-wrap">';
							$output .= $title_block;
						$output .= '</div>';
					$output .= '</div>';
					break;

				case 'layout-9':
					$output .= '<div class="content-wrap">';
						$output .= '<div class="tittle-wrap">';
							$output .= $title_block;
						$output .= '</div>';
						$output .= $content_html;
					$output .= '</div>';
					$output .= $icon_html;
					break;

				default:
					$output .= $content_html;
					$output .= $title_block;
					break;
			}

			if(!empty($link_css)) {
				$output .= '<script type="text/javascript">
					(function($) {
						$("head").append("<style>'. esc_js($link_css) .'</style>");
					})(jQuery);
				</script>';
			}
		$output .= '</div>';
		
		echo $output;
	}

}
