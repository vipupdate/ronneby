<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Portfolio_Module extends \Elementor\Widget_Base {

	var $front_template = 'elementor/templates/portfolio/';
	
	public function get_name() {
		return 'el_portfolio_module';
	}

	public function get_title() {
		return esc_html__('DFD Portfolio module', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_portfolio_module';
	}

	/**
	 * Get single portfolio item.
	 * */
	private function get_dfd_single_portfolio_item() {
		$options = array();

		$terms = array(
			'post_status' => 'publish',
			'post_type' => 'my-product',
			'posts_per_page' => -1
		);
		
		$query = new WP_Query($terms);
		
		foreach($query->posts as $post) {
			if(isset($post->ID) && isset($post->post_title)) {
				$options[$post->ID] = $post->post_title;
			}
		}

		return $options;
	}
	
	/**
	 * Get portfolio categories.
	 * */
	private function get_dfd_portfolio_category() {
		$options = array();

		$terms = get_terms(
			array(
				'taxonomy' => 'my-product_category',
				'hide_empty' => true,
			)
		);
		foreach($terms as $term) {
			if(isset($term)) {
				if(isset($term->slug) && isset($term->name)) {
					$options[$term->slug] = $term->name;
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_portfolio_module',
			[
				'label' => esc_html__('Portfolio module', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'carousel' => esc_html__('Carousel', 'dfd'),
					'fitRows' => esc_html__('Grid', 'dfd'),
					'masonry' => esc_html__('Masonry', 'dfd'),
					'simple' => esc_html__('Simple', 'dfd')
				],
				'default' => 'carousel'
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'loop' => esc_html__('Loop', 'dfd'),
					'single' => esc_html__('Single item', 'dfd')
				],
				'default' => 'loop'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_items',
			[
				'label' => esc_html__('Select items', 'dfd')
			]
		);
		
		$this->add_control(
			'single_custom_post_item',
			[
				'label' => esc_html__('Item to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $this->get_dfd_single_portfolio_item(),
				'condition' => [
					'items' => ['single']
				]
			]
		);
		
		if (!empty($this->get_dfd_portfolio_category())) {
			foreach ($this->get_dfd_portfolio_category() as $slug => $name) {
				$this->add_control(
					'portfolio_categories_' . $slug,
					[
						'label' => $name,
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'default' => 'no',
						'condition' => [
							'items' => ['loop']
						]
					]
				);
			}
		}
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_items_settings',
			[
				'label' => esc_html__('Portfolio items settings', 'dfd')
			]
		);
		
		$this->add_control(
			'posts_to_show',
			[
				'label' => esc_html__('Items to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 9
			]
		);
		
		$this->add_control(
			'items_offset',
			[
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
//				'selectors' => [
//					'{{WRAPPER}} .dfd-portfolio-module.carousel .dfd-portfolio' => 'margin: -({{SCHEME}}/2)px;',
//					'{{WRAPPER}} .dfd-portfolio-module.carousel .dfd-portfolio .cover' => 'padding: -({{SCHEME}}/2)px;',
//					'{{WRAPPER}} .dfd-portfolio-module.carousel .dfd-portfolio-loop .dfd-portfolio .project .cover .dfd-folio-heading-wrap' => 'left: -({{SCHEME}}/2)px; right: -({{SCHEME}}/2)px;',
//				],
				'condition' => [
					'style' => ['carousel', 'fitRows', 'masonry']
				]
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'text-center'
			]
		);
		
		$this->add_control(
			'content_effect',
			[
				'label' => esc_html__('Content visibility', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'desc-hover' => esc_html__('Show content on hover', 'dfd'),
					'' => esc_html__('Show content by default', 'dfd')
				],
				'condition' => [
					'style' => ['simple']
				],
				'default' => 'desc-hover'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_layout_settings',
			[
				'label' => esc_html__('Layout settings', 'dfd')
			]
		);
		
		$this->add_control(
			'columns',
			[
				'label' => esc_html__('Number of columns', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
				'condition' => [
					'style' => ['masonry', 'fitRows', 'carousel']
				]
			]
		);
		
		$this->add_control(
			'enabled_autoslideshow',
			[
				'label' => esc_html__('Auto slideshow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel']
				],
			]
		);

		$this->add_control(
			'carousel_slideshow_speed',
			[
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_autoslideshow' => ['yes'],
					'style' => ['carousel']
				],
				'default' => 5000
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_content_elements',
			[
				'label' => esc_html__('Content elements', 'dfd')
			]
		);
		
		$this->add_control(
			'sort_panel',
			[
				'label' => esc_html__('Sort Panel', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_meta',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_excerpt',
			[
				'label' => esc_html__('Excerpt', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_read_more',
			[
				'label' => esc_html__('Read more button', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_share',
			[
				'label' => esc_html__('Share buttons', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_comments',
			[
				'label' => esc_html__('Comments', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_likes',
			[
				'label' => esc_html__('Likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_anim_com_like',
			[
				'label' => esc_html__('Animate comments and likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'sort_alignment',
			[
				'label' => esc_html__('Sort panel alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'sort_panel' => ['yes']
				],
				'default' => 'text-center'
			]
		);
		
		$this->add_control(
			'heading_position',
			[
				'label' => esc_html__('Heading position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Under image', 'dfd'),
					'dfd-folio-title-front' => esc_html__('In front of the image', 'dfd')
				],
				'condition' => [
					'enabled_title' => ['yes']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'read_more_style',
			[
				'label' => esc_html__('Read more style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'simple' => esc_html__('Simple', 'dfd'),
					'chaffle' => esc_html__('Shuffle', 'dfd'),
					'slide-up' => esc_html__('Slide up', 'dfd')
				],
				'condition' => [
					'enabled_read_more' => ['yes']
				],
				'default' => 'simple'
			]
		);
		
		$this->add_control(
			'share_style',
			[
				'label' => esc_html__('Share style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'animated' => esc_html__('Animated', 'dfd'),
					'simple' => esc_html__('Simple', 'dfd')
				],
				'condition' => [
					'enabled_share' => ['yes']
				],
				'default' => 'animated'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_thumbs_settings',
			[
				'label' => esc_html__('Thumbs settings', 'dfd')
			]
		);
		
		$this->add_control(
			'image_width',
			[
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['carousel', 'fitRows']
				],
				'default' => 900
			]
		);

		$this->add_control(
			'image_height',
			[
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['carousel', 'fitRows']
				],
				'default' => 600
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_portfolio_hover_options',
			[
				'label' => esc_html__('Hover options', 'dfd')
			]
		);
		
		$this->add_control(
			'hover_style',
			[
				'label' => esc_html__('Hover style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Inherit from theme options', 'dfd'),
					'custom' => esc_html__('Design your own', 'dfd')
				],
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'folio_hover_appear_effect',
			[
				'label' => esc_html__('Mask appear effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-fade-out' => esc_html__('Fade out', 'dfd'),
					'dfd-fade-offset' => esc_html__('Fade out with offset', 'dfd'),
					'dfd-left-to-right' => esc_html__('From left to right', 'dfd'),
					'dfd-right-to-left' => esc_html__('From right to left', 'dfd'),
					'dfd-top-to-bottom' => esc_html__('From top to bottom', 'dfd'),
					'dfd-bottom-to-top' => esc_html__('From bottom to top', 'dfd'),
					'dfd-left-to-right-shift' => esc_html__('From left to right shift image', 'dfd'),
					'dfd-right-to-left-shift' => esc_html__('From right to left shift image', 'dfd'),
					'dfd-top-to-bottom-shift' => esc_html__('From top to bottom shift image', 'dfd'),
					'dfd-bottom-to-top-shift' => esc_html__('From bottom to top shift image', 'dfd'),
					'portfolio-hover-style-1' => esc_html__('Following the mouse', 'dfd'),
					'dfd-rotate-content-up' => esc_html__('Rotate content up', 'dfd'),
					'dfd-rotate-content-down' => esc_html__('Rotate content down', 'dfd'),
					'dfd-rotate-left' => esc_html__('Rotate left', 'dfd'),
					'dfd-rotate-right' => esc_html__('Rotate right', 'dfd'),
					'dfd-rotate-top' => esc_html__('Rotate top', 'dfd'),
					'dfd-rotate-bottom' => esc_html__('Rotate bottom', 'dfd')
				],
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'dfd-fade-out'
			]
		);
		
		$this->add_control(
			'mask_offset_size',
			[
				'label' => esc_html__('Mask offset size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .project.dfd-fade-offset .entry-thumb:hover .portfolio-custom-hover' => 'left: {{SCHEME}}px; right: {{SCHEME}}px; top: {{SCHEME}}px; bottom: {{SCHEME}}px;'
				],
				'condition' => [
					'folio_hover_appear_effect' => ['dfd-fade-offset']
				]
			]
		);
		
		$this->add_control(
			'mask_background',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover mask background', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .project .entry-thumb .portfolio-custom-hover' => 'background-color: {{SCHEME}};'
				],
				'condition' => [
					'hover_style' => 'custom'
				]
			]
		);
		
		$this->add_control(
			'folio_hover_image_effect',
			[
				'label' => esc_html__('Image hover effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'panr' => esc_html__('Image parallax', 'dfd'),
					'dfd-image-scale' => esc_html__('Grow', 'dfd'),
					'dfd-image-scale-rotate' => esc_html__('Grow with rotation', 'dfd'),
					'dfd-image-shift-left' => esc_html__('Shift left', 'dfd'),
					'dfd-image-shift-right' => esc_html__('Shift right', 'dfd'),
					'dfd-image-shift-top' => esc_html__('Shift top', 'dfd'),
					'dfd-image-shift-bottom' => esc_html__('Shift bottom', 'dfd'),
					'dfd-image-blur' => esc_html__('Blur', 'dfd'),
					'grow-grayscale' => esc_html__('Colored with grow', 'dfd'),
					'dfd-not-image-effect' => esc_html__('None', 'dfd')
				],
				'condition' => [
					'folio_hover_appear_effect' => ['dfd-fade-out', 'dfd-fade-offset', 'dfd-left-to-right', 'dfd-right-to-left', 'dfd-top-to-bottom', 'dfd-bottom-to-top', 'portfolio-hover-style-1', 'dfd-rotate-content-up', 'dfd-rotate-content-down']
				],
				'default' => 'panr'
			]
		);
		
		$this->add_control(
			'folio_hover_main_dedcoration',
			[
				'label' => esc_html__('Main decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__('None', 'dfd'),
					'heading' => esc_html__('Heading', 'dfd'),
					'plus' => esc_html__('Plus', 'dfd'),
					'lines' => esc_html__('Lines', 'dfd'),
					'dots' => esc_html__('Dots', 'dfd')
				],
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'none'
			]
		);
		
		$this->add_control(
			'folio_hover_title_dedcoration',
			[
				'label' => esc_html__('Heading decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'title-deco-none' => esc_html__('None', 'dfd'),
					'diagonal-line' => esc_html__('Diagonal line', 'dfd'),
					'title-underline' => esc_html__('Title underline', 'dfd'),
					'square-behind-heading' => esc_html__('Square behind heading', 'dfd')
				],
				'condition' => [
					'folio_hover_main_dedcoration' => ['heading']
				],
				'default' => 'title-deco-none'
			]
		);
		
		$this->add_control(
			'folio_hover_show_title',
			[
				'label' => esc_html__('Titles', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'folio_hover_main_dedcoration' => ['heading']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'folio_hover_show_subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'folio_hover_main_dedcoration' => ['heading']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'folio_hover_plus_position',
			[
				'label' => esc_html__('Plus position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-middle' => esc_html__('Middle of the project', 'dfd'),
					'dfd-top-right' => esc_html__('Top right corner', 'dfd'),
					'dfd-top-left' => esc_html__('Top left corner', 'dfd'),
					'dfd-bottom-right' => esc_html__('Bottom right corner', 'dfd'),
					'dfd-bottom-left' => esc_html__('Bottom left corner', 'dfd')
				],
				'condition' => [
					'folio_hover_main_dedcoration' => ['plus']
				],
				'default' => 'dfd-middle'
			]
		);
		
		$this->add_control(
			'folio_hover_plus_bg',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Plus background', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
//				'selectors' => [
//					'{{WRAPPER}} .icon-wrapper .info-box-icon-text' => 'color: {{SCHEME}};'
//				],
				'condition' => [
					'folio_hover_plus_position' => ['dfd-top-right', 'dfd-top-left', 'dfd-bottom-right', 'dfd-bottom-left']
				]
			]
		);
		
		$this->add_control(
			'folio_hover_show_ext_link',
			[
				'label' => esc_html__('External link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'folio_hover_show_quick_view',
			[
				'label' => esc_html__('Quick view', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'folio_hover_show_lightbox',
			[
				'label' => esc_html__('Lightbox', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'yes'
			]
		);
		
		$this->end_controls_section();
		
			$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);
			
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-portfolio-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_font_options',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-portfolio-title',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-folio-heading-wrap .subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_font_options',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-folio-heading-wrap .subtitle',
			]
		);
		
		$this->add_control(
			'hover_title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .project .entry-thumb .portfolio-custom-hover .title-wrap h6.widget-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hover_title_font_options',
				'label' => esc_html__('Hover title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .portfolio-custom-hover .widget-title',
			]
		);
		
		$this->add_control(
			'hover_subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .project .entry-thumb .portfolio-custom-hover .title-wrap h6.widget-sub-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hover_subtitle_font_options',
				'label' => esc_html__('Hover subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .portfolio-custom-hover .widget-sub-title',
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$output = $el_class = $css_rules = $js_scripts = $data_atts = $folio_hover_style_class = '';
		$article_data_atts = '';
		
		
		$title_html = '';
		
		$sort_panel_enabled = false;
		
		$settings = $this->get_settings_for_display();

		$el_class .= ' ' . $settings['style'];

		$uniqid = uniqid('dfd-portfolio-module-');

		if($settings['items'] == 'single' && isset($settings['single_custom_post_item']) && !empty($settings['single_custom_post_item'])) {
			$args = array(
				'post_type' => 'my-product',
				'p' => $settings['single_custom_post_item']
			);
			$settings['columns'] = 1;
		} else {
			$sticky = get_option( 'sticky_posts' );

			$portfolio_categories = array();
			foreach ($this->get_dfd_portfolio_category() as $slug => $name) {
				if($settings['portfolio_categories_' . $slug] == 'yes') {
					$portfolio_categories[] = $slug;
				}
			}
		
			if (!empty($portfolio_categories)){
				$args = array(
					'post_type' => 'my-product',
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'my-product_category',
						'field' => 'slug',
						'terms' => $portfolio_categories,
					)
				);
			} else {
				$args = array(
					'post_type' => 'my-product',
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
			}
		}

		$enable_title = ($settings['enabled_title'] == 'yes') ? true : false;

		$enable_meta = ($settings['enabled_meta'] == 'yes') ? true : false;

		$enable_excerpt = ($settings['enabled_excerpt'] == 'yes') ? true : false;

		$read_more = ($settings['enabled_read_more'] == 'yes') ? true : false;

		$share = ($settings['enabled_share'] == 'yes') ? true : false;

		$comments = ($settings['enabled_comments'] == 'yes') ? true : false;

		$likes = ($settings['enabled_likes'] == 'yes')? true : false;

		$media_class = ($settings['enabled_anim_com_like'] == 'yes') ? 'comments-like-hover' : '';

		$wp_query = new WP_Query($args);

		$style_template = DFD_RONNEBY_PLUGIN_PATH . $this->front_template . $settings['style'].'.php';

		$options = array(
			'folio_hover_appear_effect',
			'folio_hover_image_effect',
			'folio_hover_main_dedcoration',
			'folio_hover_title_dedcoration',
			'folio_hover_show_title',
			'folio_hover_show_subtitle',
			'folio_hover_show_ext_link',
			'folio_hover_show_quick_view',
			'folio_hover_show_lightbox',
			'folio_hover_plus_position',
		);

		if($settings['hover_style'] == 'custom') {
			foreach($options as $k => $v) {
				$settings[$k] = (isset($$k)) ? $$k : $v;
			}
		} else {
			global $dfd_ronneby;
			foreach($options as $k => $v) {
				$settings[$k] = (isset($dfd_ronneby[$k])) ? $dfd_ronneby[$k] : $v;
			}
		}

		$non3d_hovers = array(
			'dfd-fade-out',
			'dfd-fade-offset',
			'dfd-left-to-right',
			'dfd-right-to-left',
			'dfd-top-to-bottom',
			'dfd-bottom-to-top',
			'dfd-rotate-content-up'
		);

		$folio_hover_style_class .= $settings['folio_hover_appear_effect'];

		if(in_array($settings['folio_hover_appear_effect'], $non3d_hovers)) {
			$folio_hover_style_class .= ' '.$settings['folio_hover_image_effect'];
		}

		$output .= '<div class="dfd-module-wrapper">';

		if(file_exists($style_template)) {
			ob_start();

			include($style_template);

			$output .= ob_get_clean();
		}

		if(!empty($css_rules) || !empty($js_scripts)) {
			$output .= '<script type="text/javascript">
							(function($) {';

			if(!empty($css_rules)) {
				$output .= '$("head").append("<style>'.$css_rules.'</style>");';
			}
			if(!empty($js_scripts)) {
				$output .= $js_scripts;
			}

			$output .= '})(jQuery);
						</script>';
		}

		$output .= '</div>';

		echo $output;
		
	}

}
