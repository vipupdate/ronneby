<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_DFD_Gallery_Module extends \Elementor\Widget_Base {

	var $front_template = 'elementor/templates/gallery/';
	
	public function get_name() {
		return 'el_dfd_gallery_module';
	}

	public function get_title() {
		return esc_html__('DFD Gallery module', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_gallery_module_shortcode';
	}

	/**
	 * Get single gallery item.
	 * */
	private function get_dfd_single_gallery_item() {
		$options = array();

		$terms = array(
			'post_status' => 'publish',
			'post_type' => 'gallery',
			'posts_per_page' => -1
		);
		
		$query = new WP_Query($terms);
		
		foreach($query->posts as $post) {
			if(isset($post->ID) && isset($post->post_title)) {
				$options[$post->ID] = $post->post_title;
			}
		}

		return $options;
	}
	
	/**
	 * Get gallery categories.
	 * */
	private function get_dfd_gallery_category() {
		$options = array();

		$terms = get_terms(
			array(
				'taxonomy' => 'gallery_category',
				'hide_empty' => true,
			)
		);
		foreach($terms as $term) {
			if(isset($term)) {
				if(isset($term->slug) && isset($term->name)) {
					$options[$term->slug] = $term->name;
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_gallery_module',
			[
				'label' => esc_html__('Gallery module', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'carousel' => esc_html__('Carousel', 'dfd'),
					'fitRows' => esc_html__('Grid', 'dfd'),
					'masonry' => esc_html__('Masonry', 'dfd')
				],
				'default' => 'carousel'
			]
		);

		$this->add_control(
			'title_position',
			[
				'label' => esc_html__('Heading position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'bottom' => esc_html__('Bottom', 'dfd'),
					'top' => esc_html__('Top', 'dfd')
				],
				'default' => 'bottom'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_items',
			[
				'label' => esc_html__('Select items', 'dfd')
			]
		);
		
		$this->add_control(
			'items',
			[
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'loop' => esc_html__('Loop', 'dfd'),
					'single' => esc_html__('Single item', 'dfd')
				],
				'default' => 'loop'
			]
		);
		
		$this->add_control(
			'single_custom_post_item',
			[
				'label' => esc_html__('Item to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $this->get_dfd_single_gallery_item(),
				'condition' => [
					'items' => ['single']
				]
			]
		);
		
		if (!empty($this->get_dfd_gallery_category())) {
			foreach ($this->get_dfd_gallery_category() as $slug => $name) {
				$this->add_control(
					'gallery_categories_' . $slug,
					[
						'label' => $name,
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'condition' => [
							'items' => ['loop']
						]
					]
				);
			}
		}
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_items_settings',
			[
				'label' => esc_html__('Gallery items settings', 'dfd')
			]
		);
		
		$this->add_control(
			'posts_to_show',
			[
				'label' => esc_html__('Items to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'items' => 'loop'
				],
				'default' => 9
			]
		);
		
		$this->add_control(
			'items_offset',
			[
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'condition' => [
					'items' => 'loop'
				]
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-center'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_layout_settings',
			[
				'label' => esc_html__('Layout settings', 'dfd')
			]
		);
		
		$this->add_control(
			'columns',
			[
				'label' => esc_html__('Number of columns', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'items' => 'loop'
				],
				'default' => 3,
			]
		);
		
		$this->add_control(
			'enabled_autoslideshow',
			[
				'label' => esc_html__('Auto slideshow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => 'carousel'
				],
			]
		);

		$this->add_control(
			'carousel_slideshow_speed',
			[
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_autoslideshow' => ['yes'],
					'style' => ['carousel']
				],
				'default' => 5000
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_content_elements',
			[
				'label' => esc_html__('Content elements', 'dfd')
			]
		);
		
		$this->add_control(
			'sort_panel',
			[
				'label' => esc_html__('Sort Panel', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'fitRows']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_meta',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_read_more',
			[
				'label' => esc_html__('Read more button', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_share',
			[
				'label' => esc_html__('Share buttons', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_comments',
			[
				'label' => esc_html__('Comments', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_likes',
			[
				'label' => esc_html__('Likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_anim_com_like',
			[
				'label' => esc_html__('Animate comments and likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'read_more_style',
			[
				'label' => esc_html__('Read more style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'simple' => esc_html__('Simple', 'dfd'),
					'chaffle' => esc_html__('Shuffle', 'dfd'),
					'slide-up' => esc_html__('Slide up', 'dfd')
				],
				'condition' => [
					'enabled_read_more' => ['yes']
				],
				'default' => 'simple'
			]
		);
		
		$this->add_control(
			'share_style',
			[
				'label' => esc_html__('Share style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'animated' => esc_html__('Animated', 'dfd'),
					'simple' => esc_html__('Simple', 'dfd')
				],
				'condition' => [
					'enabled_share' => ['yes']
				],
				'default' => 'animated'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_thumbs_settings',
			[
				'label' => esc_html__('Thumbs settings', 'dfd')
			]
		);
		
		$this->add_control(
			'image_width',
			[
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['carousel', 'fitRows']
				],
				'default' => 900
			]
		);

		$this->add_control(
			'image_height',
			[
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['carousel', 'fitRows']
				],
				'default' => 600
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_gallery_hover_options',
			[
				'label' => esc_html__('Hover options', 'dfd')
			]
		);
		
		$this->add_control(
			'hover_style',
			[
				'label' => esc_html__('Hover style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Inherit from theme options', 'dfd'),
					'custom' => esc_html__('Design your own', 'dfd')
				],
				'condition' => [
					'style' => ['carousel', 'masonry', 'fitRows']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_link',
			[
				'label' => esc_html__('Apply link to', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'lightbox' => esc_html__('Open gallery in lightbox', 'dfd'),
					'link' => esc_html__('Go to Gallery single item', 'dfd')
				],
				'condition' => [
					'hover_style' => 'custom'
				],
				'default' => 'lightbox'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_appear_effect',
			[
				'label' => esc_html__('Mask appear effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-fade-out' => esc_html__('Fade out', 'dfd'),
					'dfd-fade-offset' => esc_html__('Fade out with offset', 'dfd'),
					'dfd-left-to-right' => esc_html__('From left to right', 'dfd'),
					'dfd-right-to-left' => esc_html__('From right to left', 'dfd'),
					'dfd-top-to-bottom' => esc_html__('From top to bottom', 'dfd'),
					'dfd-bottom-to-top' => esc_html__('From bottom to top', 'dfd'),
					'dfd-left-to-right-shift' => esc_html__('From left to right shift image', 'dfd'),
					'dfd-right-to-left-shift' => esc_html__('From right to left shift image', 'dfd'),
					'dfd-top-to-bottom-shift' => esc_html__('From top to bottom shift image', 'dfd'),
					'dfd-bottom-to-top-shift' => esc_html__('From bottom to top shift image', 'dfd'),
					'portfolio-hover-style-1' => esc_html__('Following the mouse', 'dfd'),
					'dfd-rotate-content-up' => esc_html__('Rotate content up', 'dfd'),
					'dfd-rotate-content-down' => esc_html__('Rotate content down', 'dfd'),
					'dfd-rotate-left' => esc_html__('Rotate left', 'dfd'),
					'dfd-rotate-right' => esc_html__('Rotate right', 'dfd'),
					'dfd-rotate-top' => esc_html__('Rotate top', 'dfd'),
					'dfd-rotate-bottom' => esc_html__('Rotate bottom', 'dfd')
				],
				'condition' => [
					'hover_style' => 'custom'
				],
				'default' => 'dfd-fade-out'
			]
		);
		
		$this->add_control(
			'mask_offset_size',
			[
				'label' => esc_html__('Mask offset size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .project.dfd-fade-offset .entry-thumb:hover .portfolio-custom-hover' => 'left: {{SCHEME}}px; right: {{SCHEME}}px; top: {{SCHEME}}px; bottom: {{SCHEME}}px;'
				],
				'condition' => [
					'folio_hover_appear_effect' => ['dfd-fade-offset']
				]
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_image_effect',
			[
				'label' => esc_html__('Image hover effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'panr' => esc_html__('Image parallax', 'dfd'),
					'dfd-image-scale' => esc_html__('Grow', 'dfd'),
					'dfd-image-scale-rotate' => esc_html__('Grow with rotation', 'dfd'),
					'dfd-image-shift-left' => esc_html__('Shift left', 'dfd'),
					'dfd-image-shift-right' => esc_html__('Shift right', 'dfd'),
					'dfd-image-shift-top' => esc_html__('Shift top', 'dfd'),
					'dfd-image-shift-bottom' => esc_html__('Shift bottom', 'dfd'),
					'dfd-image-blur' => esc_html__('Blur', 'dfd')
				],
				'condition' => [
					'dfd_gallery_hover_appear_effect' => ['dfd-fade-out', 'dfd-fade-offset', 'dfd-left-to-right', 'dfd-right-to-left', 'dfd-top-to-bottom', 'dfd-bottom-to-top', 'portfolio-hover-style-1', 'dfd-rotate-content-up', 'dfd-rotate-content-down']
				],
				'default' => 'panr'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_main_dedcoration',
			[
				'label' => esc_html__('Main decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__('None', 'dfd'),
					'heading' => esc_html__('Heading', 'dfd'),
					'plus' => esc_html__('Plus', 'dfd'),
					'lines' => esc_html__('Lines', 'dfd'),
					'dots' => esc_html__('Dots', 'dfd')
				],
				'condition' => [
					'hover_style' => ['custom']
				],
				'default' => 'none'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_title_dedcoration',
			[
				'label' => esc_html__('Heading decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'title-deco-none' => esc_html__('None', 'dfd'),
					'diagonal-line' => esc_html__('Diagonal line', 'dfd'),
					'title-underline' => esc_html__('Title underline', 'dfd'),
					'square-behind-heading' => esc_html__('Square behind heading', 'dfd')
				],
				'condition' => [
					'dfd_gallery_hover_main_dedcoration' => ['heading']
				],
				'default' => 'title-deco-none'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_show_title',
			[
				'label' => esc_html__('Titles', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'dfd_gallery_hover_main_dedcoration' => ['heading']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_show_subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'dfd_gallery_hover_main_dedcoration' => ['heading']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_plus_position',
			[
				'label' => esc_html__('Plus position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-middle' => esc_html__('Middle of the project', 'dfd'),
					'dfd-top-right' => esc_html__('Top right corner', 'dfd'),
					'dfd-top-left' => esc_html__('Top left corner', 'dfd'),
					'dfd-bottom-right' => esc_html__('Bottom right corner', 'dfd'),
					'dfd-bottom-left' => esc_html__('Bottom left corner', 'dfd')
				],
				'condition' => [
					'dfd_gallery_hover_main_dedcoration' => ['plus']
				],
				'default' => 'dfd-middle'
			]
		);
		
		$this->add_control(
			'dfd_gallery_hover_plus_bg',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Plus background', 'dfd'),
				'condition' => [
					'dfd_gallery_hover_plus_position' => ['dfd-top-right', 'dfd-top-left', 'dfd-bottom-right', 'dfd-bottom-left']
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);
			
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_font_options',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-blog-title',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$output = $css_rules = $js_scripts = $dfd_gallery_hover_style_class = $extra_class_name = '';
		$article_data_atts = $title_html = $data_atts = '';
		
		$sort_panel = false;
		
		$settings = $this->get_settings_for_display();

		$el_class = $settings['style'];
		
		$uniqid = uniqid('dfd-gallery-module-');

		if($settings['items'] == 'single' && isset($settings['single_custom_post_item']) && !empty($settings['single_custom_post_item'])) {
			$args = array(
				'post_type' => 'gallery',
				'p' => $settings['single_custom_post_item']
			);
			$settings['columns'] = 1;
		} else {
			$sticky = get_option( 'sticky_posts' );

			$gallery_categories = array();
			foreach ($this->get_dfd_gallery_category() as $slug => $name) {
				if($settings['gallery_categories_' . $slug] == 'yes') {
					$gallery_categories[] = $slug;
				}
			}
		
			if (!empty($gallery_categories)){
				$args = array(
					'post_type' => 'gallery',
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'gallery_category',
						'field' => 'slug',
						'terms' => $gallery_categories,
					)
				);
			} else {
				$args = array(
					'post_type' => 'gallery',
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
			}
		}

		$enable_title = ($settings['enabled_title'] == 'yes') ? true : false;

		$enable_meta = ($settings['enabled_meta'] == 'yes') ? true : false;

		$read_more = ($settings['enabled_read_more'] == 'yes') ? true : false;

		$share = ($settings['enabled_share'] == 'yes') ? true : false;

		$comments = ($settings['enabled_comments'] == 'yes') ? true : false;

		$likes = ($settings['enabled_likes'] == 'yes')? true : false;

		$media_class = ($settings['enabled_anim_com_like'] == 'yes') ? 'comments-like-hover' : '';
		
		$wp_query = new WP_Query($args);
		
		$style_template = DFD_RONNEBY_PLUGIN_PATH . $this->front_template . $settings['style'].'.php';

		$options = array(
			'dfd_gallery_hover_link' => 'lightbox',
			'dfd_gallery_hover_appear_effect' => 'dfd-fade-out',
			'dfd_gallery_hover_image_effect' => '',
			'dfd_gallery_hover_main_dedcoration' => 'heading',
			'dfd_gallery_hover_title_dedcoration' => 'none',
			'dfd_gallery_hover_show_title' => 'on',
			'dfd_gallery_hover_show_subtitle' => 'on',
			'dfd_gallery_hover_plus_position' => '',
			'dfd_gallery_hover_plus_bg' => '',
			'dfd_gallery_item_appear_effect' => '',
			'dfd_gallery_comments_likes_style' => '',
		);
		
		if($settings['hover_style'] == 'custom') {
			foreach($options as $k => $v) {
				$settings[$k] = (isset($settings[$k])) ? $settings[$k] : $v;
				$options[$k] = (isset($settings[$k])) ? $settings[$k] : $v;
			}
		} else {
			global $dfd_ronneby;
			foreach($options as $k => $v) {
				$settings[$k] = (isset($dfd_ronneby[$k])) ? $dfd_ronneby[$k] : $v;
				$options[$k] = (isset($dfd_ronneby[$k])) ? $dfd_ronneby[$k] : $v;
			}
		}
		
		$transformation = array(
			'dfd_gallery_hover_show_title',
			'dfd_gallery_hover_show_subtitle'
		);
		foreach ($transformation as $value) {
			if($settings[$value] == 'yes') {
				$options[$value] = 'on';
			}
		}
		
		$non3d_hovers = array(
			'dfd-fade-out',
			'dfd-fade-offset',
			'dfd-left-to-right',
			'dfd-right-to-left',
			'dfd-top-to-bottom',
			'dfd-bottom-to-top',
			'dfd-rotate-content-up'
		);

		$dfd_gallery_hover_style_class .= $settings['dfd_gallery_hover_appear_effect'];

		if(in_array($settings['dfd_gallery_hover_appear_effect'], $non3d_hovers)) {
			$dfd_gallery_hover_style_class .= ' '.$settings['dfd_gallery_hover_image_effect'];
		}

		if($settings['dfd_gallery_hover_plus_bg'] && !empty($settings['dfd_gallery_hover_plus_bg'])) {
			switch($dfd_gallery_hover_plus_position) {
				case 'dfd-top-right' :
				case 'dfd-bottom-right' :
					$css_rules .= '#'.esc_attr($uniqid).' .dfd-gallery-single-item .entry-thumb .portfolio-custom-hover .plus-link:before {border-right-color: '.esc_attr($settings['dfd_gallery_hover_plus_bg']).';}';
					break;
				case 'dfd-top-left' :
				case 'dfd-bottom-left' :
					$css_rules .= '#'.esc_attr($uniqid).' .dfd-gallery-single-item .entry-thumb .portfolio-custom-hover .plus-link:before {border-left-color: '.esc_attr($settings['dfd_gallery_hover_plus_bg']).';}';
					break;
			}
		}

		$output .= '<div class="dfd-module-wrapper">';

		if(file_exists($style_template)) {
			ob_start();

			include($style_template);

			$output .= ob_get_clean();
		}

		if(!empty($css_rules) || !empty($js_scripts)) {
			$output .= '<script type="text/javascript">
							(function($) {';

								if(!empty($css_rules))
									$output .= '$("head").append("<style>'.$css_rules.'</style>");';

								if(!empty($js_scripts))
									$output .= $js_scripts;

			$output .= '})(jQuery);
						</script>';
		}

		$output .= '</div>';

		echo $output;
		
	}

}
