<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Team_Member extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_team_member';
	}

	public function get_title() {
		return esc_html__('DFD Team member', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'new_team_member';
	}

	private function dfd_team_member_social() {
		return array(
			'deviantart' => array('name' => 'Deviantart', 'icon' => 'soc_icon-deviantart'),
			'digg' => array('name' => 'Digg', 'icon' => 'soc_icon-digg'),
			'dribbble' => array('name' => 'Dribbble', 'icon' => 'soc_icon-dribbble'),
			'dropbox' => array('name' => 'Dropbox', 'icon' => 'soc_icon-dropbox'),
			'evernote' => array('name' => 'Evernote', 'icon' => 'soc_icon-evernote'),
			'facebook' => array('name' => 'Facebook', 'icon' => 'soc_icon-facebook'),
			'flickr' => array('name' => 'Flickr', 'icon' => 'soc_icon-flickr'),
			'foursquare' => array('name' => 'Foursquare', 'icon' => 'soc_icon-foursquare_2'),
			'google' => array('name' => 'Google', 'icon' => 'soc_icon-google__x2B_'),
			'instagram' => array('name' => 'Instagram', 'icon' => 'soc_icon-instagram'),
			'last_fm' => array('name' => 'Last FM', 'icon' => 'soc_icon-last_fm'),
			'linkedin' => array('name' => 'LinkedIN', 'icon' => 'soc_icon-linkedin'),
			'livejournal' => array('name' => 'Livejournal', 'icon' => 'soc_icon-livejournal'),
			'picasa' => array('name' => 'Picasa', 'icon' => 'soc_icon-picasa'),
			'pinterest' => array('name' => 'Pinterest', 'icon' => 'soc_icon-pinterest'),
			'rss' => array('name' => 'RSS', 'icon' => 'soc_icon-rss'),
			'tumblr' => array('name' => 'Tumblr', 'icon' => 'soc_icon-tumblr'),
			'twitter' => array('name' => 'Twitter', 'icon' => 'dfd-added-icon-twitter-x-logo'),
			'vimeo' => array('name' => 'Vimeo', 'icon' => 'soc_icon-vimeo'),
			'wordpress' => array('name' => 'Wordpress', 'icon' => 'soc_icon-wordpress'),
			'youtube' => array('name' => 'Youtube', 'icon' => 'soc_icon-youtube'),
			'px_500' => array('name' => '500 px', 'icon' => 'dfd-added-font-icon-px-icon'),
			'mail' => array('name' => 'Mail', 'icon' => 'soc_icon-mail'),
			'viewbug' => array('name' => 'ViewBug', 'icon' => 'dfd-added-font-icon-vb'),
			'vkontakte' => array('name' => 'VKontakte', 'icon' => 'soc_icon-rus-vk-02'),
			'xing' => array('name' => 'Xing', 'icon' => 'dfd-added-font-icon-b_Xing-icon_bl'),
			'spotify' => array('name' => 'Spotify', 'icon' => 'dfd-added-font-icon-c_spotify-512-black'),
			'houzz' => array('name' => 'Houzz', 'icon' => 'dfd-added-font-icon-houzz-dark-icon'),
			'skype' => array('name' => 'Skype', 'icon' => 'dfd-added-font-icon-skype'),
			'slideshare' => array('name' => 'Slideshare', 'icon' => 'dfd-added-font-icon-slideshare'),
			'bandcamp' => array('name' => 'Bandcamp', 'icon' => 'dfd-added-font-icon-bandcamp-logo'),
			'soundcloud' => array('name' => 'Soundcloud', 'icon' => 'dfd-added-font-icon-soundcloud-logo'),
			'meerkat' => array('name' => 'Meerkat', 'icon' => 'dfd-added-font-icon-Meerkat-color'),
			'periscope' => array('name' => 'Periscope', 'icon' => 'dfd-added-font-icon-periscope-logo'),
			'snapchat' => array('name' => 'Snapchat', 'icon' => 'dfd-added-font-icon-Snapchat-logo'),
			'thecity' => array('name' => 'The City', 'icon' => 'dfd-added-font-icon-the-city'),
			'behance' => array('name' => 'Behance', 'icon' => 'soc_icon-behance'),
			'microsoft_pinpoint' => array('name' => 'Microsoft Pinpoint', 'icon' => 'dfd-added-font-icon-pinpoint'),
			'viadeo' => array('name' => 'Viadeo', 'icon' => 'dfd-added-font-icon-viadeo')
		);
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'el_team_member', [
				'label' => esc_html__('Team member', 'dfd')
			]
		);
		
		$this->add_control(
			'main_layout', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-01' => esc_html__('Classic', 'dfd'),
					'layout-02' => esc_html__('Classic left', 'dfd'),
					'layout-03' => esc_html__('Classic right', 'dfd'),
					'layout-04' => esc_html__('Classic top', 'dfd'),
					'layout-05' => esc_html__('Classic overlay', 'dfd'),
					'layout-06' => esc_html__('Hovered slide', 'dfd'),
					'layout-07' => esc_html__('Hovered bottom', 'dfd'),
					'layout-08' => esc_html__('Hovered description', 'dfd'),
					'layout-09' => esc_html__('Hovered overlay', 'dfd'),
					'layout-10' => esc_html__('Hovered thumbnail', 'dfd'),
					'layout-11' => esc_html__('Hovered title & icons', 'dfd')
				],
				'default' => 'layout-01'
			]
		);
		
		$this->add_control(
			'team_member_photo', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Image', 'dfd')
			]
		);
		
		$this->add_control(
			'team_member_img_width', [
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 400
			]
		);
		
		$this->add_control(
			'team_member_img_height', [
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 400
			]
		);
		
		$this->add_control(
			'team_member_name', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('John Brown', 'dfd')
			]
		);
		
		$this->add_control(
			'team_member_job_position', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Manager', 'dfd')
			]
		);
		
		$this->add_control(
			'team_member_description', [
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('The main text about your team member', 'dfd')
			]
		);
		
		$this->add_control(
			'enable_custom_link', [
				'label' => esc_html__('Team member custom link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'apply_link_to', [
				'label' => esc_html__('Apply link to', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'image-link' => esc_html__('Team member image', 'dfd'),
					'title-link' => esc_html__('Title', 'dfd'),
					'both-title-and-image' => esc_html__('Both title and image', 'dfd'),
				],
				'condition' => [
					'enable_custom_link' => 'yes'
				],
				'default' => 'image-link'
			]
		);
		
		$this->add_control(
			'custtom_link_url', [
				'label' => esc_html__('Custom link url', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'enable_custom_link' => 'yes'
				]
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_soc_member', [
				'label' => esc_html__('Social accounts', 'dfd')
			]
		);
		
		$this->add_control(
			'soc_icons_hover', [
				'label' => esc_html__('Icon hover style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_attr__('Square top to bottom', 'dfd'),
					'2' => esc_attr__('Circle colored style', 'dfd'),
					'3' => esc_attr__('Square colored style', 'dfd'),
					'4' => esc_attr__('Flying line', 'dfd'),
					'5' => esc_attr__('Square black and white', 'dfd'),
					'6' => esc_attr__('Circle black and white', 'dfd'),
					'7' => esc_attr__('Circle icons with border 3px', 'dfd'),
					'8' => esc_attr__('Square icons with border 3px', 'dfd'),
					'9' => esc_attr__('Square icon on a dark background', 'dfd'),
					'10' => esc_attr__('Circle icon on a light background', 'dfd'),
					'11' => esc_attr__('Square icon on a light background', 'dfd'),
					'12' => esc_attr__('Circle icons with border', 'dfd'),
					'13' => esc_attr__('Square icons with border', 'dfd'),
					'14' => esc_attr__('Change color', 'dfd'),
					'15' => esc_attr__('In general border', 'dfd'),
					'16' => esc_attr__('Retro Disco Style', 'dfd'),
					'17' => esc_attr__('Circle from the center', 'dfd'),
					'18' => esc_attr__('The circle in the center', 'dfd'),
					'19' => esc_attr__('Round icons on gray background', 'dfd'),
					'20' => esc_attr__('Square icon on a gray background', 'dfd'),
					'21' => esc_attr__('Circle fade', 'dfd'),
					'22' => esc_attr__('Square background from left to right', 'dfd'),
					'23' => esc_attr__('Circle icon on a dark background', 'dfd'),
					'24' => esc_attr__('Square icon scale background', 'dfd'),
					'25' => esc_attr__('Circle icon scale background', 'dfd'),
					'26' => esc_attr__('Square icon on a light background', 'dfd'),
				],
				'default' => '1'
			]
		);
		
		foreach($this->dfd_team_member_social() as $key => $value) {
			$this->add_control(
				$key, [
					'label' => $value['name'],
					'type' => \Elementor\Controls_Manager::TEXT
				]
			);
		}
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_member_style', [
				'label' => esc_html__('Image options', 'dfd')
			]
		);
		
		$this->add_control(
			'thumb_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .team-member-photo' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'shadow', [
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'shadow_style', [
				'label' => esc_html__('Shadow style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'permanent' => esc_html__('Permanent', 'dfd'),
					'hover' => esc_html__('On hover', 'dfd')
				],
				'default' => 'permanent',
				'condition' => [
					'shadow' => 'yes'
				],
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
		'el_overlay_style',
			[
				'label' => esc_html__('Overlay options', 'dfd'),
				'condition' => [
					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'gradient_color',
				'label' => esc_html__('Background', 'plugin-name'),
				'types' => ['gradient'],
				'selector' => '{{WRAPPER}} .overlay',
				'condition' => [
					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'full_width_overlay', [
				'label' => esc_html__('Full width overlay', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_layout' => ['layout-11']
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_delimeter_settings', [
				'label' => esc_html__('Delimiter settings', 'dfd'),
//				'condition' => [
//					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
//				]
			]
		);
		
		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('Title HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-title.feature-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('Subtitle HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-description'
			]
		);

		$this->add_control(
			'content_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-description' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->end_controls_section();
		
	}

	protected function render() {
		$el_class = $link_atts = $delimiter_html = $shadow_class = $soc_icon_html = $subtitle_html = $title_html = '';
		$soc_networks_output = $output = $overlay_output = $content_css = '';

		$settings = $this->get_settings_for_display();

		if(isset($settings['full_width_overlay']) && $settings['full_width_overlay'] == 'yes') {
			$el_class .= ' team-full-width-owerlay';
		}

		if($settings['enable_custom_link']) {
			$link_atts .= 'href="' . (!empty($settings['custtom_link_url']['url']) ? esc_url($settings['custtom_link_url']['url']) : '#') . '"';
			$link_atts .= ' target="' . (!empty($settings['custtom_link_url']['is_external']) ? '_blank' : '_self' ) . '"';
			$link_atts .= !empty($settings['custtom_link_url']['nofollow']) ? ' rel="nofollow"' : '';
			$link_atts .= !empty($settings['custtom_link_url']['custom_attributes']) ? ' ' . esc_attr($settings['custtom_link_url']['custom_attributes']) : '';
		}

		$soc_icons_hover_style = 'dfd-soc-icons-hover-style-' . esc_attr($settings['soc_icons_hover']);
		
		foreach($this->dfd_team_member_social() as $soc_network => $soc_name) {
			if (isset($settings[$soc_network]) && !empty($settings[$soc_network])) {
				$soc_icon_html .= '<a href="' . $settings[$soc_network] . '" class="' . esc_attr($soc_name['icon']) . '" ' . esc_attr(' target="' . ($settings['enable_custom_link'] == 'new_tab' ? '_blank' : '_self' ) . '"') . '><span class="line-top-left ' . esc_attr($soc_name['icon']) . '"></span><span class="line-top-center ' . esc_attr($soc_name['icon']) . '"></span><span class="line-top-right ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-left ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-center ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-right ' . esc_attr($soc_name['icon']) . '"></span><i class="' . esc_attr($soc_name['icon']) . '"></i></a>';
			}
		}
		
		if(!empty($soc_icon_html)) {
			$soc_networks_output .= '<div class="widget soc-icons ' . $soc_icons_hover_style . '">';
				$soc_networks_output .= $soc_icon_html;
			$soc_networks_output .= '</div>';
		}

		if(!empty($settings['team_member_name'])) {
			$title_html = '<'.$settings['title_html_tag'].' class="team-member-title feature-title">';
			if ($settings['enable_custom_link'] && ('title-link' === $settings['apply_link_to']) || $settings['enable_custom_link'] && ('both-title-and-image' === $settings['apply_link_to'])) {
				$title_html .= '<a '.$link_atts.'>';
					$title_html .= esc_html($settings['team_member_name']);
				$title_html .= '</a>';
			} else {
				$title_html .= esc_html($settings['team_member_name']);
			}
			$title_html .= '</'.$settings['title_html_tag'].'>';
		}
		
		if (!empty($settings['team_member_job_position'])) {
			$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="team-member-subtitle subtitle" >'.esc_html($settings['team_member_job_position']).'</'.$settings['subtitle_html_tag'].'>';
		}

		if ($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter" ></div></div>';
		}

		if ($settings['shadow'] == 'yes') {
			if ('hover' === $settings['shadow_style']) {
				$shadow_class .= ' module-shadow-hover ';
			} else {
				$shadow_class .= ' module-shadow-permanent ';
			}
		}

		$content_output = '<div class="team-member-description" >'.$settings['team_member_description'].'</div>';

		if (isset($settings['team_member_photo']['id']) && !( $settings['team_member_photo']['id'] == '' )) {
			$image_url = dfd_aq_resize($settings['team_member_photo']['url'], $settings['team_member_img_width'], $settings['team_member_img_height'], true, true, true);
			if (!$image_url) {
				$image_url = $settings['team_member_photo']['url'];
			}
			$attr = Dfd_Theme_Helpers::get_image_attrs($settings['team_member_photo']['url'], $settings['team_member_photo'], $settings['team_member_img_width'], $settings['team_member_img_height']);
			global $dfd_ronneby;
			if (isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$el_class .= ' dfd-img-lazy-load';
				$team_member_img_width = $settings['team_member_img_width'];
				$team_member_img_height = $settings['team_member_img_height'];
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $team_member_img_width $team_member_img_height'%2F%3E";
				$image_output = '<img src="' . $loading_img_src . '" data-src="' . esc_url($image_url) . '" ' . $attr . ' width="' . esc_attr($team_member_img_width) . '" height="' . esc_attr($team_member_img_height) . '" class="team-member-photo ' . $shadow_class . '"/>';
			} else {
				$image_output = '<img src="' . esc_url($image_url) . '" ' . $attr . ' class="team-member-photo ' . $shadow_class . '"/>';
			}
		}

		if ('layout-06' === $settings['main_layout'] || 'layout-09' === $settings['main_layout'] || 'layout-10' === $settings['main_layout'] || 'layout-05' === $settings['main_layout'] || 'layout-07' === $settings['main_layout'] || 'layout-11' === $settings['main_layout']) {
			$overlay_output .= '<div class="overlay"></div>';
		}
		if ($settings['main_layout'] === 'layout-11') {
			if (isset($team_member_img_width) && !empty($settings['team_member_img_width'])) {
				$content_css .= 'style="max-width:' . $team_member_img_width . 'px;"';
			}
		}

		if ($settings['enable_custom_link'] && ('image-link' === $settings['apply_link_to']) || $settings['enable_custom_link'] && ('both-title-and-image' === $settings['apply_link_to'])) {
			$overlay_output .= '<a class="image-custom-link ' . esc_attr($settings['apply_link_to']) . '" ' . $link_atts . '></a>';
		}


		$output .= '<div class="dfd-team-member ' . $settings['main_layout'] . ' ' . $el_class . '" >';

		if ('layout-05' === $settings['main_layout'] || 'layout-06' === $settings['main_layout'] || 'layout-07' === $settings['main_layout']) {

			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="content-wrap">';
			$output .= $content_output;
			$output .= $soc_networks_output;
			$output .= '</div>';
		} elseif ('layout-04' === $settings['main_layout'] || 'layout-08' === $settings['main_layout']) {
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			$output .= '</div>';
			$output .= '<div class="content-wrap">';
			$output .= $content_output;
			$output .= $soc_networks_output;
			$output .= '</div>';
		} elseif ('layout-09' === $settings['main_layout']) {
			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			$output .= '<div class="ovh">';
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= $content_output;
			$output .= '</div>';
			$output .= '<div class="content-wrap">';
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= $content_output;
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			if (!empty($soc_networks_output)) {
				$output .= '<div class="soc-icons-wrap">';
				$output .= $soc_networks_output;
				$output .= '</div>';
			}
		} elseif ('layout-10' === $settings['main_layout']) {
			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="content-wrap">';
			$output .= $content_output;
			$output .= $soc_networks_output;
			$output .= '</div>';
		} elseif ('layout-11' === $settings['main_layout']) {
			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			if (!empty($soc_networks_output)) {
				$output .= '<div class="soc-icon-wrap">';
				$output .= $soc_networks_output;
				$output .= '</div>';
			}
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="content-wrap" ' . $content_css . '>';
			$output .= $content_output;
			$output .= '</div>';
		} else {
			$output .= '<div class="image-wrap">';
			$output .= $image_output;
			$output .= $overlay_output;
			$output .= '</div>';
			$output .= '<div class="content-wrap">';
			$output .= '<div class="title-wrap">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= $delimiter_html;
			$output .= '</div>';
			$output .= $content_output;
			$output .= $soc_networks_output;
			$output .= '</div>';
		}

		$output .= '</div>';

		echo $output;
	}

}
