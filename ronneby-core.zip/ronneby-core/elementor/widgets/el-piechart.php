<?php

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Piechart extends \Elementor\Widget_Base {

    public function get_name() {
        return 'el_piechart';
    }

    public function get_title() {
        return esc_html__('DFD Piechart', 'dfd');
    }

    public function get_categories() {
        return ['ronneby-category'];
    }

    public function get_icon() {
        return 'piecharts';
    }

    protected function register_controls() {

		$this->start_controls_section(
			'el_piechart',
			[
				'label' => esc_html__('Piechart', 'dfd')
			]
		);

		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Simple', 'dfd'),
					'layout-2' => esc_html__('Info', 'dfd'),
					'layout-3' => esc_html__('Combined', 'dfd'),
					'layout-4' => esc_html__('Advanced', 'dfd')
				],
				'default' => 'layout-1'
			]
		);

		$this->add_control(
			'percent',
			[
				'label' => esc_html__('Percent circle to fill', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'range' => [
					'min' => 1,
					'max' => 100
				],
				'default' => '75'
			]
		);

		$this->add_control(
			'size',
			[
				'label' => esc_html__('Circle size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => '150'
			]
		);

		$this->add_control(
			'animation_off',
			[
				'label' => esc_html__('Circle animation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no'
			]
		);
		
		$this->add_control(
			'clock_wise',
			[
				'label' => esc_html__('Anticlockwise', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no'
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cont_heading',
			[
				'label' => esc_html__('Content', 'dfd')
			]
		);

		$this->add_control(
			'number',
			[
				'label' => esc_html__('Number', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_layout!' => 'layout-2'
				]
			]
		);

		$this->add_control(
			'unit',
			[
				'type' => \Elementor\Controls_Manager::TEXT,
				'label' => esc_html__('Measuring unit', 'dfd'),
				'condition' => [
					'main_layout!' => 'layout-2'
				],
				'separator' => 'after',
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_heading',
			[
				'label' => esc_html__('Icon settings', 'dfd'),
				'condition' => [
					'main_layout!' => 'layout-1'
				]
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon', 'dfd'),
					'custom' => esc_html__('Image', 'dfd')
				],
				'default' => 'selector'
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-socicon-film-strip-with-two-photograms',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon_image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'icon_type' => ['selector', 'custom']
				],
				'selectors' => [
					'{{WRAPPER}} .featured-icon' => 'font-size: {{SCHEME}}px;'
				]
			]
		);

		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'description' => esc_html__('The default color is #e7e7e7', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .featured-icon' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'circle_heading',
			[
				'label' => esc_html__('Circle gradient', 'dfd')
			]
		);

		$this->add_control(
			'fill_color_start',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Start color', 'dfd')
			]
		);

		$this->add_control(
			'fill_color_end',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('End color', 'dfd')
			]
		);

		$this->add_control(
			'fill_width',
			[
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'border_heading',
			[
				'label' => esc_html__('Border style', 'dfd')
			]
		);

		$this->add_control(
			'bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd')
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'del_heading',
			[
				'label' => esc_html__('Delimiter style', 'dfd')
			]
		);
		
		$this->add_control(
			'line_hide',
			[
				'label' => esc_html__('Enable delimiter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'line_width',
			[
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pichart-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .pichart-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pichart-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .pichart-subtitle'
			]
		);

		$this->add_control(
			'content_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .piecharts-number' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_t_heading',
				'label' => esc_html__('Content typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .piecharts-number'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$delimiter_html = $title_html = $subtitle_html = $icon_html = $content_html = $output = $el_class = $fill_style = '';

		$settings = $this->get_settings_for_display();
			
		$uniqid = uniqid('dfd-piecharts-') .'-'. rand(1,9999);
			
		if($settings['percent'] == '') {
			$settings['percent'] = 0;
		}	

		if($settings['number'] == '') {
			$settings['number'] = 0;
		}

		if($settings['fill_color_start'] == '') {
			$settings['fill_color_start'] = '#c39f76';
		}	

		if($settings['bg_color'] == '') {
			$settings['bg_color'] = '#efefef';
		}	

		if ($settings['animation_off'] != 'yes') {
			$el_class .= ' circle-off-animation';
		}

		if(isset($settings['clock_wise']) && strcmp($settings['clock_wise'], 'yes') == 0) {
			$el_class .= ' counterclock-wise-animation';
		}
			
		$icon_html = dfd_elementor_icon_render($settings) ;

		if(!empty($settings['number'])) {
			$content_html = '<div class="piecharts-number " data-max="' . esc_attr( $settings['number'] ) . '" data-units="' . esc_attr( $settings['unit'] ) . '">0</div>';
		}
			
		if(!empty( $settings['title'])) {
			$title_html = '<' . $settings['title_html_tag']  . ' class="pichart-title ">' . esc_html($settings['title']) . '</' .  $settings['title_html_tag']  . '>';
		}

		if(!empty( $settings['subtitle'])) {
			$subtitle_html = '<' . $settings['subtitle_html_tag'] . ' class="pichart-subtitle " >' . esc_html($settings['subtitle']) . '</' . $settings['subtitle_html_tag'] . '>';
		}

		if($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter"></div></div>';
		}

		if(!empty($settings['fill_color_end']) && !empty($settings['fill_color_start'])) {
			$fill_style .= ' data-fill="{&quot;gradient&quot;: [&quot;' . esc_attr($settings['fill_color_start']) . '&quot;,&quot;' . esc_attr($settings['fill_color_end']) . '&quot;]}" ';
		} elseif (!empty($settings['fill_color_end'])) {
			$fill_style .= ' data-fill="{&quot;color&quot;: &quot;' . esc_attr($settings['fill_color_end']) . '&quot;}" ';
		} else {
			$fill_style .= ' data-fill="{&quot;color&quot;: &quot;' . esc_attr($settings['fill_color_start']) . '&quot;}" ';
		}
			
		$value = $settings['percent'] / 100;
		
		$output .= '<div id="'.esc_attr($uniqid).'" class="dfd-piecharts call-on-waypoint '.$settings['main_layout'].''.esc_attr($el_class).'"
			data-emptyfill = "'.$settings['bg_color'].'" '.$fill_style.'
			data-value="'.$value.'" data-size="'. $settings['size'] .'"  data-thickness="'.$settings['fill_width'].'"  data-animation-start-value="0"
			data-reverse="true">';

		switch($settings['main_layout']) {
			case 'layout-1':
				$output .= '<div class="inner-circle" style="line-height:'.esc_attr($settings['size']).'px; height:'.esc_attr($settings['size']).'px; width:'.esc_attr($settings['size']).'px;">';
				$output .= $content_html;
				$output .= '</div>';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				break;

			case 'layout-2':
				$output .= '<div class="inner-circle" style="line-height:'.esc_attr($settings['size']).'px; height:'.esc_attr($settings['size']).'px; width:'.esc_attr($settings['size']).'px;">';
				$output .= $icon_html;
				$output .= '</div>';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				break;

			case 'layout-3':
				$output .= '<div class="inner-circle" style="line-height:'.esc_attr($settings['size']).'px; height:'.esc_attr($settings['size']).'px; width:'.esc_attr($settings['size']).'px;">';
				$output .= $icon_html;
				$output .= $content_html;
				$output .= '</div>';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				break;

			case 'layout-4':
				$output .= '<div class="inner-circle" style="line-height:'.esc_attr($settings['size']).'px; height:'.esc_attr($settings['size']).'px; width:'.esc_attr($settings['size']).'px;">';
				$output .= $content_html;
				$output .= '</div>';
				$output .= '<div class="wrap">';
				$output .= '<div class="module-icon">';
				$output .= $icon_html;
				$output .= '</div>';
				$output .= '<div class="title-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= '</div>';
				break;

			default:
				$output .= $content_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				break;
		}

		$output .= '</div>';

        echo $output;
    }

}
