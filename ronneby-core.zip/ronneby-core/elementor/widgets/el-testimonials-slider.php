<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Testimonials_Slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_testimonials_slider';
	}

	public function get_title() {
		return esc_html__('DFD Testimonials slider', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'testimonials_slider';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_testimonials_slider', [
			'label' => esc_html__('Testimonials slider', 'dfd')
			]
		);

		$this->add_control(
			'style', [
				'label' => esc_html__('Image position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'above' => esc_html__('Above content', 'dfd'),
					'below' => esc_html__('Below content', 'dfd')
				],
				'default' => 'above'
			]
		);
		
		$this->add_control(
			'align',
			[
				'label' => esc_html__('Content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'align-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'align-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'align-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'align-center'
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'client_photo',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Author image', 'dfd')
			]
		);
		
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Title'
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Subtitle'
			]
		);

		$repeater->add_control(
			'testimonial_text',
			[
				'label' => esc_html__('Testimonial', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Content'
			]
		);
		
		$this->add_control(
			'testimonials',
			[
				'label' => esc_html__('images', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_testimonials_slider_settings', [
			'label' => esc_html__('Slider settings', 'dfd')
			]
		);
		
		$this->add_control(
			'autoplay', [
				'label' => esc_html__('Autoplay‏', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'autoplay_speed', [
				'label' => esc_html__('Autoplay Speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'autoplay' => 'yes'
				],
				'default' => 5000
			]
		);
		
		$this->add_control(
			'draggable', [
				'label' => esc_html__('Draggable effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonials_styles', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Testimonials styles', 'dfd')
			]
		);
		
		$this->add_control(
			'title_author_thumbnail_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Author thumbnail', 'dfd')
			]
		);
		
		$this->add_control(
			'shadow', [
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'thumb_size', [
				'label' => esc_html__('Image size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 80
			]
		);
		
		$this->add_control(
			'thumb_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .thumb img' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'title_delimeter_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Delimiter style', 'dfd'),
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 100,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'default' => '#878787',
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'title_quote_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Quote symbol', 'dfd'),
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'quote_hide', [
				'label' => esc_html__('Enable element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'quote_size', [
				'label' => esc_html__('Size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'condition' => [
					'quote_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .icon-wrap i' => 'font-size: {{SCHEME}}px;',
					'{{WRAPPER}} .text-wrap' => 'min-height: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'quote_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'default' => '#878787',
				'condition' => [
					'quote_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .icon-wrap i' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonials_typography_styles', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);
		
		$this->add_control(
			'title_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Title typography', 'dfd'),
			]
		);
		
		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-title.feature-title, {{WRAPPER}} .info-box-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-title.feature-title, {{WRAPPER}} .info-box-title.feature-title'
			]
		);
		
		$this->add_control(
			'subtitle_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-subtitle.subtitle, {{WRAPPER}} .info-box-subtitle.subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-subtitle.subtitle, {{WRAPPER}} .info-box-subtitle.subtitle'
			]
		);

		$this->add_control(
			'testimonial_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Testimonial typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'testimonial_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-text.dfd-testimonial-content' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'testimonial-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-text.dfd-testimonial-content'
			]
		);
		
		$this->end_controls_section();
	}

	protected function render() {
		$output = $el_class = $delimiter_html = $icon_html = $shadow = $nav_style = $style_width_thumb_below = '';
		$cover_class = $controls_html = $content_html = $thumbs_html = '';
		$lazy_load = false;
		$draggable = "false";
		
		global $dfd_ronneby;
		
		$settings = $this->get_settings_for_display();
		
		$_autoplay = $settings["autoplay"] == 'yes' ? "true" : "false";

		$el_class .= $settings['style'].' '.$settings['align'];

		if($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter"></div></div>';
		}

		if($settings['quote_hide'] == 'yes') {
			$icon_html .= '<span class="icon-wrap"><i class="navicon-quote-right"></i></span>';
		}

		if($settings['shadow'] == 'yes') {
			$shadow = 'enable-shadow';
		}

		if($settings['align'] === 'align-right') {
			$right_style = 'dir="rtl"';
			$nav_style = 'direction:rtl;';
			$rtl = 'true';
		} else {
			$right_style = '';
			$rtl = 'false';
		}
		
		$thumb_size = $settings['thumb_size'];
		if(isset($thumb_size) && 80 < intval($thumb_size)) {
			$nav_style .= ' width: '.((intval($thumb_size) + 20) * 3).'px;';

			if(strcmp($settings['style'], 'below') === 0) {
				$style_width_thumb_below = 'style="max-width: '.(intval($thumb_size) + 20).'px;"';
			}
		}

		if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
			$lazy_load = true;
			$cover_class = 'dfd-img-lazy-load';
			$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $thumb_size $thumb_size'%2F%3E";
		}

		foreach($settings['testimonials'] as $testimonial) {
			$img_id = '';
			$testimonial_title = isset($testimonial['title']) ? $testimonial['title'] : "";
			if(isset($testimonial['client_photo']['id'])) {
				$img_id = $testimonial['client_photo']['id'];
				$image_src = wp_get_attachment_image_src($img_id, 'full');
				$image_url = dfd_aq_resize( $image_src[0], $thumb_size, $thumb_size, true, true, true );
				if(!$image_url) {
					$image_url = $image_src[0];
				}
			} else {
				$image_url = get_template_directory_uri() . '/assets/img/no-user.png';
			}
			$attr = Dfd_Theme_Helpers::get_image_attrs($image_url, $img_id, $thumb_size, $thumb_size);
			$thumbs_html .= '<a class="thumb '.$cover_class.'" '.$style_width_thumb_below.'>';

			if($lazy_load) {
				$img_html = '<img src="'.$loading_img_src.'" data-src="' . $image_url . '" width="'.$thumb_size.'" height="'.$thumb_size.'" '.$attr.'/>';
			} else {
				$img_html = '<img src="' . $image_url . '" width="'.$thumb_size.'" height="'.$thumb_size.'" '.$attr.'/>';
			}
			$thumbs_html .= $img_html;
			if($settings['style'] === 'below') {

				$thumbs_html .='<span class="below-title">';
				if(isset($testimonial['title'])) {
					$thumbs_html .= '<'.$settings['title_html_tag'].' class="testimonial-title feature-title">'.esc_html($testimonial['title']).'</'.$settings['title_html_tag'].'>';
				}
				if(isset($testimonial['subtitle'])) {
					$thumbs_html .= '<'.$settings['subtitle_html_tag'].' class="testimonial-subtitle subtitle" >'.esc_html($testimonial['subtitle']).'</'.$settings['subtitle_html_tag'].'>';
				}
				$thumbs_html .= '</span>';
			}
			$thumbs_html .= '</a>';
		}

		$controls_html .= '<div class="testimonials-thumbs-wrap ' . $shadow . '" style="'.$nav_style.'"  ' . $right_style . '>';
			$controls_html .= '<div class="testimonials-thumbs-slider">';
				$controls_html .= $thumbs_html;
			$controls_html .= '</div>';
		$controls_html .= '</div>';

		$content_html .= '<div class="testimonials-content-wrap" ' . $right_style . '>';

		$content_html .= '<div class="testimonials-slider">';
		$counter = 0;
		foreach($settings['testimonials'] as $single_testimonial) {
			$content_html .= '<div class="testimonials-content">';
			$content_html .= $icon_html;
			$content_html .= '<div class="text-wrap">';
			if(isset($single_testimonial['testimonial_text']) && !empty($single_testimonial['testimonial_text'])) {
				$content_html .= '<div class="testimonial-text dfd-testimonial-content">' . $single_testimonial['testimonial_text'] . '</div>';
			}
			$content_html .= '</div>';
			if($settings['style'] === 'above') {

				$content_html .= $delimiter_html;

				if(isset($single_testimonial['title'])) {
					$content_html .= '<'.$settings['title_html_tag'].' class="info-box-title feature-title">' . esc_html( $single_testimonial['title'] ) . '</'.$settings['title_html_tag'].'>';
				}
				if(isset($single_testimonial['subtitle'])) {
					$content_html .= '<'.$settings['subtitle_html_tag'].' class="info-box-subtitle subtitle">' . esc_html( $single_testimonial['subtitle'] ) . '</'.$settings['subtitle_html_tag'].'>';
				}
			}
			$content_html .= '</div>';
			$counter++;
		}
		$content_html .= '</div>';
		$content_html .= '</div>';

		$uniqid = uniqid('testimonial-slider');
		
		if($settings['align'] === 'align-center') {
			$centered_slider = 'true';
		} else {
			$centered_slider = 'false';
		}
		
		if($settings['draggable'] == 'yes') {
			$draggable = 'true';
			$el_class .= ' draggable';
		}
		
		if(($settings['align'] === 'align-center') && ($counter > 2) ) {
			$start_from = absint($counter / 2);
		} else {
			$start_from = '0';
		}

		$output .= '<div id="' . esc_attr( $uniqid ) . '" class="dfd-testimonial-slider ' . $el_class . '"
		data-autoplay="' . $_autoplay . '"
		data-centered="' . $centered_slider . '"
		data-autoplay_speed="' . $settings['autoplay_speed'] . '"
		data-draggable="' . $draggable . '"
		data-start_slide="' . $start_from . '"
		data-rtl="' . $rtl . '"
		>';

		if($settings['style'] === 'above') {
			$output .= $controls_html;
			$output .= $content_html;
		} else {
			$output .= $content_html;
			$output .= $delimiter_html;
			$output .= $controls_html;
		}
		
		$output .= '</div>';
		
		ob_start();
		
		?>
		<script type="text/javascript">
			(function ($) {
				"use strict";
				var $carousel = $('#<?php echo esc_js($uniqid); ?>');
				$(document).ready(function () {
					$carousel.find('.testimonials-slider').slick({
						slidesToShow: 1,
						slidesToScroll: 1,
						arrows: false,
						dots: false,
						fade: false,
						asNavFor: $carousel.find('.testimonials-thumbs-slider'),
						centerPadding: '0',
						autoplay: $carousel.data('autoplay'),
						autoplaySpeed: $carousel.data('autoplay_speed'),
						draggable: $carousel.data('draggable'),
						centerMode: $carousel.data('centered'),
						infinite: true,
						rtl: $carousel.data('rtl'),
						initialSlide: $carousel.data('start_slide')

					});
					$carousel.find('.testimonials-thumbs-slider').slick({
						slidesToShow: 1,
						slidesToScroll: 1,
						asNavFor: $carousel.find('.testimonials-slider'),
						dots: false,
						arrows: false,
						draggable: false,
						centerMode: $carousel.data('centered'),
						initialSlide:  $carousel.data('start_slide'),
						infinite: true,
						variableWidth: true,
						focusOnSelect: true,
						rtl: $carousel.data('rtl')
					});
				});
			})(jQuery);
		</script>
		<?php
		$output .= ob_get_clean();
		
		echo $output;
	}

}
