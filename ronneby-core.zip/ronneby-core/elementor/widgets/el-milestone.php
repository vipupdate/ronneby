<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Milestone extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_milestone';
	}

	public function get_title() {
		return esc_html__('DFD Milestone', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_milestone';
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'el_milestone',
			[
				'label' => esc_html__('Milestone', 'dfd')
			]
		);
		
		$this->add_control(
			'main_style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Simple', 'dfd'),
					'style-2' => esc_html__('Left align', 'dfd'),
					'style-3' => esc_html__('Right align', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->add_control(
			'columns_width',
			[
				'label' => esc_html__('Element width', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'full-width-elements' => esc_html__('Full width', 'dfd'),
					'half-size-elements' => esc_html__('Half size', 'dfd'),
					'one-third-width-elements' => esc_html__('Third size', 'dfd'),
					'quarter-width-elements' => esc_html__('Quarter size', 'dfd')
				],
				'default' => 'one-third-width-elements',
				'condition' => [
					'main_style' => 'style-1'
				]
			]
		);
		
		$this->add_control(
			'content_only_hover',
			[
				'label' => esc_html__('Description only on hover', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'side_delimeter',
			[
				'label' => esc_html__('Side delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_responsive_control(
			'centred_content_alignment',
			[
				'label' => esc_html__( 'Content alignment', 'dfd' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => esc_html__( 'Top', 'dfd' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'dfd' ),
						'icon' => 'eicon-v-align-middle',
					]
				],
				'condition' => [
					'main_style' => ['style-2', 'style-3']
				],
				'default' => 'middle'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'milestone_content',
			[
				'label' => esc_html__('Milestone content', 'dfd')
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon', 'dfd'),
					'custom' => esc_html__('Image', 'dfd'),
					'text' => esc_html__('Text', 'dfd')
				],
				'default' => 'selector'
			]
		);
		
		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__('Select icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);
		
		$repeater->add_control(
			'icon_image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);
		
		$repeater->add_control(
			'icon_text',
			[
				'label' => esc_html__('Text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);
		
		$repeater->add_control(
			'block_title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$repeater->add_control(
			'block_subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$repeater->add_control(
			'block_content',
			[
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA
			]
		);
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('List content', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'icon_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Icon style', 'dfd'),
			]
		);
		
		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item .icon-wrap' => 'font-size: {{SCHEME}}px;'
				],
				'default' => 27
			]
		);
		
		$this->add_control(
			'icon_bg_size',
			[
				'label' => esc_html__('Icon background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 70
			]
		);
		
		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .icon-decoration' => 'border-radius: {{SCHEME}}px;'
				],
				'default' => 35
			]
		);
		
		$this->start_controls_tabs(
			'dfd_icon_styles', [
				'separator' => 'before',
			]
		);
		
		$this->start_controls_tab(
			'dfd_icon_styles_normal',
			[
				'label' => esc_html__('Normal', 'dfd')
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item .icon-wrap' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item .icon-decoration:before' => 'border-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item .icon-decoration:before' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'dfd_icon_styles_hover',
			[
				'label' => esc_html__('Hover', 'dfd')
			]
		);
		
		$this->add_control(
			'icon_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item:hover .icon-wrap' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'hover_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item:hover .icon-decoration:before' => 'border-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'hover_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-item:hover .icon-decoration:before' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'content_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Content styles', 'dfd'),
			]
		);
		
		$this->add_control(
			'custom_content_style',
			[
				'label' => esc_html__('Custom content style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->start_controls_tabs(
			'dfd_content_styles', [
				'separator' => 'before',
				'condition' => [
					'custom_content_style' => 'yes'
				]
			]
		);
		
		$this->start_controls_tab(
			'dfd_content_styles_normal',
			[
				'label' => esc_html__('Normal', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'content_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content background color', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-wrap:not(.content-only-hover) .content-wrap' => 'border-color: {{SCHEME}}; background: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'content_border_radius',
			[
				'type' => \Elementor\Controls_Manager::NUMBER,
				'label' => esc_html__('Content border radius', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-wrap:not(.content-only-hover) .content-wrap' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'dfd_content_styles_hover',
			[
				'label' => esc_html__('Hover', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'content_background_color_hover',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content background color', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-wrap:not(.content-only-hover) .dfd-milestone-item:hover .content-wrap' => 'border-color: {{SCHEME}}; background: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'content_border_radius_hover',
			[
				'type' => \Elementor\Controls_Manager::NUMBER,
				'label' => esc_html__('Content border radius', 'dfd'),
				'condition' => [
					'custom_content_style' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-milestone-wrap:not(.content-only-hover) .dfd-milestone-item:hover .content-wrap' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'delimiter_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Delimiter and spacer options', 'dfd')
			]
		);
		
		$this->add_control(
			'item_offset',
			[
				'label' => esc_html__('Space between blocks', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-2', 'style-3']
				],
				'default' => 50
			]
		);
		
		$this->add_control(
			'connector_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimeter color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .icon-wrap:before, {{WRAPPER}} .icon-wrap:after' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .feature-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .grad-millestone-subtitle.subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .grad-millestone-subtitle.subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'selector' => '{{WRAPPER}} .description'
			]
		);

		$this->add_control(
			'content_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .description' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $list_class = $link_css = '';
		
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-milestone-').'-'.rand(1,9999);
		
		$el_class = ' '.$settings['main_style'];

		if(isset($settings['content_only_hover']) && strcmp($settings['content_only_hover'], 'yes') == 0) {
			$el_class .= ' content-only-hover';
		}
		if (isset($settings['side_delimeter']) && $settings['side_delimeter'] == 'yes') {
			$el_class .= ' side-delimeter';
		}
		if (isset($settings['centred_content_alignment']) && $settings['centred_content_alignment'] == 'top') {
			$el_class .= ' dfd-milestone-content-top';
		}
		if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-1') == 0) {
			$list_class .= $settings['columns_width'];
		}

		if(isset($settings['icon_bg_size']) && !empty($settings['icon_bg_size'])) {
			$link_css .= '#'.esc_js($uniqid).'.style-1 .dfd-milestone-item .icon-centered-container, #'.esc_js($uniqid).'.style-2 .dfd-milestone-item .icon-wrap, #'.esc_js($uniqid).'.style-3 .dfd-milestone-item .icon-wrap {width: '.esc_js($settings['icon_bg_size']).'px; height: '.esc_js($settings['icon_bg_size']).'px; line-height: '.esc_js($settings['icon_bg_size']).'px;}';
			if(is_rtl()) {
				$link_css .= '#'.esc_js($uniqid).'.style-1 .icon-wrap:before {left: '.esc_js($settings['icon_bg_size']).'px;}';
				$link_css .= '#'.esc_js($uniqid).'.style-1 .icon-wrap:after {right: '.esc_js($settings['icon_bg_size']).'px;}';
			} else {
				$link_css .= '#'.esc_js($uniqid).'.style-1 .icon-wrap:before {right: '.esc_js($settings['icon_bg_size']).'px;}';
				$link_css .= '#'.esc_js($uniqid).'.style-1 .icon-wrap:after {left: '.esc_js($settings['icon_bg_size']).'px;}';
			}
			$link_css .= '#'.esc_js($uniqid).'.style-2 .icon-wrap:before, #'.esc_js($uniqid).'.style-3 .icon-wrap:before {bottom: '.esc_js($settings['icon_bg_size']).'px;}';
			$link_css .= '#'.esc_js($uniqid).'.style-2 .icon-wrap:after, #'.esc_js($uniqid).'.style-3 .icon-wrap:after {top: '.esc_js($settings['icon_bg_size']).'px;}';
			$link_css .= '#'.esc_js($uniqid).'.style-2 .content-wrap {margin-left: '.esc_js($settings['icon_bg_size'] + 25).'px;}';
			$link_css .= '#'.esc_js($uniqid).'.style-3 .content-wrap {margin-right: '.esc_js($settings['icon_bg_size'] + 25).'px;}';
			$link_css .= '#'.esc_js($uniqid).'.style-2 .icon-wrap, #'.esc_js($uniqid).'.style-3 .icon-wrap {margin-top: -'.esc_js($settings['icon_bg_size'] / 2).'px;}';
			$link_css .= '#'.esc_js($uniqid).'.style-2 .icon-centered-container, #'.esc_js($uniqid).'.style-3 .icon-centered-container {min-height: '.esc_js($settings['icon_bg_size']).'px;}';
		}
		
		if(isset($settings['item_offset']) && strcmp($settings['item_offset'], '') != 0) {
			$link_css .= '#'.esc_js($uniqid).'.style-2 .dfd-milestone-item, #'.esc_js($uniqid).'.style-3 .dfd-milestone-item {padding: '.esc_js($settings['item_offset'] / 2).'px 0;}';
		}
		
		if (isset($settings['custom_content_style']) && strcmp($settings['custom_content_style'], 'yes') === 0) {
			$el_class .= ' content-with-decoration';
		}

		$output .= '<div id="'.esc_attr($uniqid).'" class="dfd-milestone-wrap '.esc_attr($el_class).'">';
			$output .= '<ul class="dfd-milestone-list clearfix '.esc_attr($list_class).'">';
				if(isset($settings['list_fields']) && !empty($settings['list_fields'])) {
					foreach($settings['list_fields'] as $fields) {
						$fields['icon_size'] = $settings['icon_size'];
						$title_html = $subtitle_html = $content_html = $icon_html = '';
						if(isset($fields['block_title']) && !empty($fields['block_title'])) {
							$title_html = '<'.$settings['title_html_tag'].' class="feature-title">'.(strip_tags($fields['block_title'], "<br><br/>")).'</'.$settings['title_html_tag'].'>';
						}
						if(isset($fields['block_subtitle']) && !empty($fields['block_subtitle'])) {
							$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="grad-millestone-subtitle subtitle">'.(strip_tags($fields['block_subtitle'], "<br><br/>")).'</'.$settings['subtitle_html_tag'].'>';
						}
						if(isset($fields['block_content']) && !empty($fields['block_content'])) {
							$content_html = '<div class="description">'.(strip_tags($fields['block_content'], "<br><br/>")).'</div>';
						}
						$icon_html = dfd_elementor_icon_render($fields);

						$output .= '<li class="dfd-milestone-item dfd-equalize-height">';
							$output .= '<div class="icon-centered-container">';
								$output .= '<div class="icon-wrap">';
									$output .= '<span class="icon-decoration">';
										$output .= $icon_html;
									$output .= '</span>';
								$output .= '</div>';
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
								$output .= '<div class="content-centered-container">';
									$output .= '<div class="title-wrap">';
										$output .= $title_html;
										$output .= $subtitle_html;
									$output .= '</div>';
									if(!empty($content_html)) {
										$output .= '<div class="description-container">';
											$output .= $content_html;
										$output .= '</div>';
									}
								$output .= '</div>';
							$output .= '</div>';
						$output .= '</li>';
					}
				}
			$output .= '</ul>';
//
			if(!empty($link_css)) {
				$output .= '<script type="text/javascript">'
								. '(function($) {'
									. '$("head").append("<style>'.$link_css.'</style>");'
								. '})(jQuery);'
							. '</script>';
			}

		$output .= '</div>';
		
		echo $output;
		
	}

}