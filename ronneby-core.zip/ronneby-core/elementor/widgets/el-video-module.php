<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Dfd_Videoplayer extends \Elementor\Widget_Base {
	
	public function get_name() {
		return 'el_dfd_videoplayer';
	}

	public function get_title() {
		return esc_html__('DFD Video player', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'videoplayer';
	}

	protected function register_controls() {
		
		$this->start_controls_section(
			'el_dfd_videoplayer',
			[
				'label' => esc_html__('Video player', 'dfd')
			]
		);
		
		$this->add_control(
			'main_style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Background', 'dfd'),
					'style-2' => esc_html__('Simple', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Layout', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Underlined', 'dfd'),
					'layout-2' => esc_html__('Bordered', 'dfd'),
					'layout-3' => esc_html__('Icon underline', 'dfd'),
					'layout-4' => esc_html__('Icon border', 'dfd')
				],
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'button_align',
			[
				'label' => esc_html__('Button alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'text-center'
			]
		);
		
		$this->add_control(
			'videoanimation',
			[
				'label' => esc_html__('Full screen video animation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('No Animation', 'dfd'),
					'transition.fadeIn' => esc_html__('FadeIn', 'dfd'),
					'transition.flipXIn' => esc_html__('FlipXIn', 'dfd'),
					'transition.flipYIn' => esc_html__('FlipYIn', 'dfd'),
					'transition.flipBounceXIn' => esc_html__('FlipBounceXIn', 'dfd'),
					'transition.flipBounceYIn' => esc_html__('FlipBounceYIn', 'dfd'),
					'transition.swoopIn' => esc_html__('SwoopIn', 'dfd'),
					'transition.whirlIn' => esc_html__('WhirlIn', 'dfd'),
					'transition.shrinkIn' => esc_html__('ShrinkIn', 'dfd'),
					'transition.expandIn' => esc_html__('ExpandIn', 'dfd'),
					'transition.bounceIn' => esc_html__('BounceIn', 'dfd'),
					'transition.bounceUpIn' => esc_html__('BounceUpIn', 'dfd'),
					'transition.bounceDownIn' => esc_html__('BounceDownIn', 'dfd'),
					'transition.bounceLeftIn' => esc_html__('BounceLeftIn', 'dfd'),
					'transition.bounceRightIn' => esc_html__('BounceRightIn', 'dfd'),
					'transition.slideUpIn' => esc_html__('SlideUpIn', 'dfd'),
					'transition.slideDownIn' => esc_html__('SlideDownIn', 'dfd'),
					'transition.slideLeftIn' => esc_html__('SlideLeftIn', 'dfd'),
					'transition.slideRightIn' => esc_html__('SlideRightIn', 'dfd'),
					'transition.slideUpBigIn' => esc_html__('SlideUpBigIn', 'dfd'),
					'transition.slideDownBigIn' => esc_html__('SlideDownBigIn', 'dfd'),
					'transition.slideLeftBigIn' => esc_html__('SlideLeftBigIn', 'dfd'),
					'transition.slideRightBigIn' => esc_html__('SlideRightBigIn', 'dfd'),
					'transition.perspectiveUpIn' => esc_html__('PerspectiveUpIn', 'dfd'),
					'transition.perspectiveDownIn' => esc_html__('PerspectiveDownIn', 'dfd'),
					'transition.perspectiveLeftIn' => esc_html__('PerspectiveLeftIn', 'dfd'),
					'transition.perspectiveRightIn' => esc_html__('PerspectiveRightIn', 'dfd')
				],
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => ''
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_content',
			[
				'label' => esc_html__('Content', 'dfd')
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'Title'
			]
		);
		
		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'Subtitle'
			]
		);
		
		$this->add_control(
			'video_thumb',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Thumbnail Image', 'dfd'),
				'condition' => [
					'main_style' => 'style-1'
				]
			]
		);
		
		$this->add_control(
			'video_link',
			[
				'label' => esc_html__('Video link', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_module_style',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Module Style', 'dfd')
			]
		);
		
		$this->add_control(
			'round_button',
			[
				'label' => esc_html__('Equal sides', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_layout' => 'layout-4'
				]
			]
		);
		
		$this->add_control(
			'bg_size',
			[
				'label' => esc_html__('Icon background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'round_button' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-video-button' => 'width: {{SCHEME}}px; height: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .play' => 'border-left-color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'icon_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon Background Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .style-1 .dfd-video-content .dfd-video-box .dfd-video-image-thumb .container-play' => 'background: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => 'style-1'
				]
			]
		);
		
		$this->add_control(
			'bg_t_h',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Button style', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'video_button_background',
				'label' => esc_html__('Video button background', 'plugin-name'),
				'types' => ['classic', 'gradient'],
				'selector' => 
					'{{WRAPPER}} .style-2 .dfd-video-button .mask-for-hover'
				,
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'bg_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => 
					['{{WRAPPER}} .style-2 .dfd-video-button .mask-for-hover, {{WRAPPER}} .dfd-video-button' => 'border-radius: {{SCHEME}}px;']
				,
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'button_b_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .style-2 .dfd-video-button .mask-for-hover' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'button_b_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .style-2 .dfd-video-button .mask-for-hover' => 'border-style:solid; border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'shadow',
			[
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'del_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Delimiter style', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'line_hide',
			[
				'label' => esc_html__('Enable delimiter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->add_control(
			'line_style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Default', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'condition' => [
					'main_style' => 'style-2',
					'line_hide' => 'yes'
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => 'style-2',
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'lightbox_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('lightbox Background settings', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_module_style_typography',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
				'condition' => [
					'main_style' => 'style-2'
				],
			]
		);
		
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .feature-title' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .feature-title',
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);

		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'condition' => [
					'main_style' => 'style-2'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .subtitle' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .subtitle',
				'condition' => [
					'main_style' => 'style-2'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		global $content_width;
		
		$output = $an_appear_class = $el_class = $title_html = $subtitle_html = $delimiter_style = '';
		$delimiter_html = $link_css = $thumb_html = $button_html = $content_html = '';
		
		$settings = $this->get_settings_for_display();
		
		$size = ( isset( $content_width ) ) ? $content_width : 500;

		if($settings['round_button'] === 'yes'){
			$el_class .= ' rounded-play-button ';
		}

		$unique_id_shortcode = uniqid('video-player-') .'-'.rand(1,9999);
		
		$unique_id = uniqid('module_video_');

		if(!empty($settings['title'])) {
			$title_html = '<'.$settings['title_html_tag'].' class="feature-title">' . esc_html($settings['title']) . '</'.$settings['title_html_tag'].'>';
		}

		if(!empty($settings['subtitle'])) {
			$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="subtitle">' . esc_html($settings['subtitle']) . '</'.$settings['subtitle_html_tag'].'>';
		}

		if($settings['line_style']) {
			if(($settings['main_layout'] === 'layout-1') || ($settings['main_layout'] === 'layout-2')) {
				$delimiter_style .= 'style="border-right-style:' . $settings['line_style'] . ';"';
			} else {
				$delimiter_style .= 'style="border-bottom-style:' . $settings['line_style'] . ';"';
			}
		}
		
		if($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="delimiter" ' . $delimiter_style . '></div>';
		}

		if($settings['shadow'] == 'yes') {
			$el_class .= ' shadow';
		}

		if (($settings['main_layout'] === 'layout-1') || ($settings['main_layout'] === 'layout-2')) {
			$button_html .= '<span class="dfd-video-button ' . $el_class . '" >';
			$button_html .= '<span class="mask-for-hover">';
				if($settings['main_layout'] === 'layout-1'){
					$button_html .= '<u></u><b></b>';
				}
			$button_html .= $delimiter_html;
			$button_html .= '</span>';
			$button_html .= '<span class="play"></span>';
			if($settings['title'] || $settings['subtitle']) {
				$button_html .= '<div class="title-wrap">';
					$button_html .= $title_html;
					$button_html .= $subtitle_html;
				$button_html .= '</div>';
			}
			$button_html .= '<a href="#'.$unique_id.'" class="dfd-video-link '.$an_appear_class.'" data-animation="'.$settings['videoanimation'].'" aria-label="Play video"></a>';
			$button_html .= '</span>';
		} else {
			$button_html .= '<div class="button-wrap">';
			$button_html .= '<div class="dfd-video-button ' . $el_class . '" >';
			$button_html .= '<span class="mask-for-hover">';
				if($settings['main_layout'] === 'layout-3'){
					$button_html .= '<u></u><b></b>';
				}
			$button_html .= '</span>';
			$button_html .= '<span class="play"></span>';
			$button_html .= '</div>';
			if($settings['title'] || $settings['subtitle']) {
				$button_html .= '<div class="title-wrap">';
				$button_html .= $title_html;
				$button_html .= $delimiter_html;
				$button_html .= $subtitle_html;
				$button_html .= '</div>';
			}
			$button_html .= '<a href="#'.$unique_id.'" class="dfd-video-link '.$an_appear_class.'" data-animation="'.$settings['videoanimation'].'"></a>';
			$button_html .= '</div>';
		}

		$video_w = $size;
		$video_h = ceil($size / 1.61); //1.61 golden ratio

		/** @var WP_Embed $wp_embed  */
		global $wp_embed;
		$embed = $wp_embed->run_shortcode( '[embed width="' . $video_w . '" height="' . $video_h . '"]' . $settings['video_link'] . '[/embed]' );

		if($settings['main_style'] === 'style-1') {
			$content_html .= '<div class="dfd-video-content video-content" id="' . $unique_id . '">';
			if(isset($settings['video_thumb']['id']) && !empty($settings['video_thumb']['id'])) {
				$thumb_image_url = wp_get_attachment_image_src($settings['video_thumb']['id'], 'full');
				$image_src = dfd_aq_resize($thumb_image_url[0], $video_w, $video_h, true, true, true);
				if(!$image_src) {
					$image_src = $thumb_image_url[0];
				}
				$attr = Dfd_Theme_Helpers::get_image_attrs($thumb_image_url[0], $image_src, $video_w, $video_h);

				global $dfd_ronneby;
				$cover_class = '';
				if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
					$cover_class = 'dfd-img-lazy-load';
					$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $video_w $video_h'%2F%3E";
					$img_html = '<img src="'.$loading_img_src.'" data-src="'.esc_url($image_src).'" '.$attr.' />';
				} else {
					$img_html = '<img src="'.esc_url($image_src).'" '.$attr.' />';
				}
				$thumb_html = '<a href="#'. $unique_id.'" class="dfd-video-image-thumb '.$cover_class.'" title="'.esc_html__('Play video','dfd').'"><span class="container-play"><span class="play"></span><span class="play-shadow"></span></span>'.$img_html.'</a>';
				$opacity_class = '';
			} else {
				$opacity_class = 'no-thumb';
			}

			$content_html .= '<div class="dfd-video-box '.$opacity_class.'">';
			$content_html .= $thumb_html;
			$content_html .= '<div class="wpb_video_wrapper">' . $embed . '</div>';
			$content_html .= '</div>';
			$content_html .= '</div>';
		}

		if($settings['main_style'] === 'style-2') {
			$content_html .=  '<div  style="display:none;" class="'.$an_appear_class.'" id="' . $unique_id . '" data-animation="' . $settings['videoanimation']. '">' . $embed . '</div>';
		}

		$output .= '<div class="animation-container">';
			$output .= '<div id="'.$unique_id_shortcode.'" class="dfd-videoplayer ' . $settings['main_style'] . ' ' . $settings['main_layout'] . ' ' . $settings['button_align'] . '">';
				if ($settings['main_style'] === 'style-2') {
					$output .= $button_html;
					$output .= $content_html;
				} else {
					$output .= $content_html;
				}
			$output .= '</div>';
		$output .= '</div>';

		$output .= '<script type="text/javascript">
						(function($) {
							$("head").append("<style>'. esc_js($link_css) .'</style>");
							$(document).ready(function(){
								DFD_VideoModule.init("'.$unique_id.'","'.$unique_id_shortcode.'");
							});
						})(jQuery);
					</script>';

		echo $output;
	}

}
