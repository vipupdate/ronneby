<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Info_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_info_box';
	}

	public function get_title() {
		return esc_html__('DFD Info box', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_info_box';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_info_box',
			[
				'label' => esc_html__('Info box', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-01' => esc_html__('Simple', 'dfd'),
					'style-02' => esc_html__('Solid', 'dfd'),
					'style-03' => esc_html__('Bordered', 'dfd'),
					'style-04' => esc_html__('Framed', 'dfd'),
					'style-05' => esc_html__('Image background', 'dfd'),
					'style-06' => esc_html__('Overlay', 'dfd')
				],
				'default' => 'style-01'
			]
		);

		$this->add_control(
			'layout',
			[
				'label' => esc_html__('Layout', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-01' => esc_html__('Top', 'dfd'),
					'layout-02' => esc_html__('Bottom', 'dfd'),
					'layout-03' => esc_html__('Middle', 'dfd'),
					'layout-04' => esc_html__('Left', 'dfd'),
					'layout-05' => esc_html__('Right', 'dfd'),
					'layout-06' => esc_html__('Top left', 'dfd'),
					'layout-07' => esc_html__('Top right', 'dfd')
				],
				'condition' => [
					'style!' => ['style-06']
				],
				'default' => 'layout-01'
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'style!' => ['style-06'],
					'layout' => ['layout-01', 'layout-02', 'layout-03']
				],
				'default' => 'text-center'
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__('Hover animation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('No Effect', 'dfd'),
					'hover-up-icon' => esc_html__('Icon Bounce Up', 'dfd'),
					'hover-up-box' => esc_html__('All box bounce up', 'dfd')
				],
				'default' => ''
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'el_content', [
				'label' => esc_html__('Content', 'dfd')
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Title'
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Subtitle'
			]
		);

		$this->add_control(
			'content',
			[
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Content'
			]
		);
		
		$this->add_control(
			'content_under_offset',
			[
				'label' => esc_html__('Offset above content', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .description' => 'padding-top: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'read_more',
			[
				'label' => esc_html__('Apply link to', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('No Link', 'dfd'),
					'box' => esc_html__('Complete Box', 'dfd'),
					'title' => esc_html__('Box Title', 'dfd'),
					'more' => esc_html__('Read More', 'dfd')
				],
				'default' => '',
				'separator' => 'before'
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__('Link URL', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'read_more' => ['box', 'title', 'more']
				]
			]
		);

		$this->add_control(
			'readmore_show',
			[
				'label' => esc_html__('Read more button', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'read_more' => ['box', 'title', 'more']
				]
			]
		);

		$this->add_control(
			'more_show',
			[
				'label' => esc_html__('Button visibility', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'permanent' => esc_html__('Permanent', 'dfd'),
					'hover' => esc_html__('Show on hover', 'dfd')
				],
				'default' => 'permanent',
				'condition' => [
					'readmore_show' => 'yes',
					'read_more' => ['box', 'title', 'more']
				]
			]
		);

		$this->add_control(
			'readmore_style',
			[
				'label' => esc_html__('Read more style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'read-more-01' => esc_html__('Text link', 'dfd'),
					'read-more-02' => esc_html__('Lines', 'dfd'),
					'read-more-03' => esc_html__('Dots', 'dfd'),
					'read-more-04' => esc_html__('Slashes', 'dfd'),
					'read-more-05' => esc_html__('Text + Arrow', 'dfd'),
					'read-more-06' => esc_html__('Arrow', 'dfd'),
					'read-more-07' => esc_html__('Circle', 'dfd'),
					'read-more-08' => esc_html__('Button', 'dfd'),
					'read-more-09' => esc_html__('Text shaffle', 'dfd'),
					'read-more-10' => esc_html__('Lines to crosses', 'dfd')
				],
				'default' => 'read-more-01',
				'condition' => [
					'readmore_show' => 'yes',
					'read_more' => ['box', 'title', 'more']
				]
			]
		);

		$this->add_control(
			'readmore_text',
			[
				'label' => esc_html__('Read more text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Read more',
				'condition' => [
					'readmore_style' => ['read-more-01', 'read-more-05', 'read-more-08', 'read-more-09'],
					'readmore_show' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Icon style', 'dfd')
			]
		);

		$this->add_control(
			'icon_number',
			[
				'label' => esc_html__('Number at icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style!' => ['style-06']
				]
			]
		);

		$this->add_control(
			'icon_number_text',
			[
				'label' => esc_html__('Number', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '01',
				'condition' => [
					'icon_number' => ['yes']
				]
			]
		);
		
		$this->add_control(
			'number_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Numfer background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-box-icon-text' => 'background-color: {{SCHEME}};'
				],
				'condition' => [
					'icon_number' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon', 'dfd'),
					'custom' => esc_html__('Image', 'dfd'),
					'text' => esc_html__('Text', 'dfd')
				],
				'default' => 'selector'
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__('Opacity', 'dfd'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					]
				],
				'default' => [
					'size' => '100'
				],
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'icon_type' => ['selector', 'custom']
				]
			]
		);

		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon_hover',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-info-box:hover .module-icon i' => 'color: {{SCHEME}} !important;'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);

		$this->add_control(
			'icon_image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);

		$this->add_control(
			'icon_text',
			[
				'label' => esc_html__('Text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_icon_font_options',
				'label' => esc_html__('Text icon typography', 'dfd'),
				'selector' => '{{WRAPPER}} .icon-wrapper .module-icon .dfd-text-icon-render',
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);
		$this->add_control(
			'text_icon_col',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Text Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-text-icon-render' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'icon_type' => 'text'
				]
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_ibg',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Icon background', 'dfd')
			]
		);

		$this->add_control(
			'icon_bg_size',
			[
				'label' => esc_html__('Icon background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .module-icon' => 'font-size: {{SCHEME}}px;'
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .hover-layer' => 'border-radius: {{SCHEME}}px;',
					'{{WRAPPER}} .style-04 .hover-layer' => 'border-radius: {{SCHEME}} - 4 px;',
					'{{WRAPPER}} .module-icon' => 'border-radius: {{SCHEME}}px;'
				],
			]
		);

		$this->add_control(
			'border_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .style-03 .module-icon:before, {{WRAPPER}} .style-05 .module-icon:before' => 'border-width: {{SCHEME}}px !important;',
					'{{WRAPPER}} .style-03 .module-icon, {{WRAPPER}} .style-05 .module-icon' => 'border-width: {{SCHEME}}px;',
				],
				'condition' => [
					'main_style' => ['style-03', 'style-05']
				]
			]
		);

		$this->start_controls_tabs(
			'tabs_icon_background'
		);
		
		$this->start_controls_tab(
			'tab_icon_background_normal',
			[
				'label' => esc_html__('Normal', 'dfd')
			]
		);
		
		$this->add_control(
			'border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-info-box .module-icon' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'style' => ['style-03', 'style-04', 'style-05']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'icon_background',
				'label' => esc_html__('Icon background', 'plugin-name'),
				'types' => ['classic', 'gradient'],
				'selector' =>
				'{{WRAPPER}} .dfd-info-box .module-icon'
			,
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'tab_icon_background_hover',
			[
				'label' => esc_html__('Hover', 'dfd'),
				'condition' => [
					'style!' => ['style-01', 'style-06']
				]
			]
		);
		
		$this->add_control(
			'hover_icon_border',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Hover border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-info-box:hover .module-icon' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'style' => ['style-03', 'style-04', 'style-05']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'hover_icon_bg',
				'label' => esc_html__('Icon background', 'plugin-name'),
				'types' => ['classic', 'gradient'],
				'selector' =>
				'{{WRAPPER}} .dfd-info-box:hover .hover-layer, {{WRAPPER}} .dfd-info-box:hover .module-icon'
				,
				'condition' => [
					'style!' => ['style-01', 'style-06']
				]
			]
		);

		$this->end_controls_tab();
		
		$this->end_controls_tabs();

		$this->add_control(
			'icon_bg_img',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Background image', 'dfd'),
				'condition' => [
					'style' => 'style-05'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-box-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .info-box-title.feature-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-box-subtitle.subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .info-box-subtitle.subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'selector' => '{{WRAPPER}} .description'
			]
		);

		$this->add_control(
			'content_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .description' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'delimiter_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Delimiter options', 'dfd')
			]
		);

		$this->add_control(
			'line_hide',
			[
				'label' => esc_html__('Enable delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'delimiter_style',
			[
				'label' => esc_html__('Delimiter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Theme default', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'default' => '',
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_width',
			[
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_read_more_heading',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Read more options', 'dfd'),
				'condition' => [
					'readmore_style' => ['read-more-09', 'read-more-10']
				]
			]
		);

		$this->add_control(
			'read_more_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Element color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-module-readmore .read-more-09' => 'color: {{SCHEME}};',
					'{{WRAPPER}} .dfd-module-readmore .read-more-10 span:before' => 'background: {{SCHEME}};'
				],
				'condition' => [
					'readmore_style' => ['read-more-09', 'read-more-10']
				]
			]
		);

		$this->add_control(
			'read_more_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Element hover color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-module-readmore .read-more-09:hover' => 'color: {{SCHEME}};',
					'{{WRAPPER}} .dfd-module-readmore .read-more-10:hover span:before, {{WRAPPER}} .dfd-module-readmore .read-more-10:hover span:after' => 'background: {{SCHEME}};',
				],
				'condition' => [
					'readmore_style' => ['read-more-09', 'read-more-10']
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$output = $el_class = $icon_style = $link_atts = $icon_html = $title_html = $subtitle_html = '';
		$delimiter_html = $delimiter_styles = $content_html = $id = $read_more_html = '';
		$readmore_class = $readmore_data = $more_open = $more_close = '';

		$settings = $this->get_settings_for_display();

		$id = "idinfobox" . uniqid();
		$el_class .= ' ' . esc_attr($id);

		if (isset($settings['layout']) && strcmp($settings['layout'], 'layout-01') == 0 || strcmp($settings['layout'], 'layout-02') == 0 || strcmp($settings['layout'], 'layout-03') == 0) {
			$el_class .= ' ' . esc_attr($settings['content_alignment']);
		}

		if ($settings['more_show'] === 'hover') {
			$el_class .= ' more-hover';
		}

		if (!empty($settings['hover_animation'])) {
			$el_class .= ' ' . $settings['hover_animation'];
		}

		// if ($settings['hover_icon_bg_background']) {
		// 	$el_class .= ' icon-bg-change';
		// }

		if ($settings['style'] === 'style-05' && !empty($settings['icon_bg_img']['url'])) {

			$icon_style .= 'style="background-image: url(' . $settings['icon_bg_img']['url'] . ');"';
		}

		if (!empty($settings['link'])) {
			$link_atts .= 'href="' . (!empty($settings['link']['url']) ? esc_url($settings['link']['url']) : '#') . '"';
			$link_atts .= ' target="' . (!empty($settings['link']['is_external']) ? '_blank' : '_self' ) . '"';
			$link_atts .= !empty($settings['link']['nofollow']) ? ' rel="nofollow"' : '';
			$link_atts .= !empty($settings['link']['custom_attributes']) ? ' ' . esc_attr($settings['link']['custom_attributes']) : '';
		}

		if ($settings['icon_type'] === 'text') {
			$el_class .= ' with-text';
		}

		if (isset($settings['icon']['value']) && !empty($settings['icon']['value']) || !empty($settings['icon_image_id']['id']) || $settings['icon_text'] != '') {
			$icon_html = '<div class="icon-wrapper">';
			$icon_html .= '<div class="module-icon" ' . $icon_style . '>';
			$icon_html .= '<div class="hover-layer"></div>';

			$icon_html .= dfd_elementor_icon_render($settings);

			if ($settings['icon_number'] === 'yes' && !empty($settings['icon_number_text'])) {
				$icon_html .= '<div class="info-box-icon-text">' . $settings['icon_number_text'] . '</div>';
			}
			$icon_html .= '</div>';

			$icon_html .= '</div>';
		}

		if (!empty($settings['title'])) {
			if ($settings['link'] && $settings['read_more'] === 'title') {
				$title_html .= '<' . $settings['title_html_tag'] . ' class="info-box-title feature-title"><a ' . $link_atts . '>' . esc_html($settings['title']) . '</a></' . $settings['title_html_tag'] . '>';
			} else {
				$title_html .= '<' . $settings['title_html_tag'] . ' class="info-box-title feature-title">' . esc_html($settings['title']) . '</' . $settings['title_html_tag'] . '>';
			}
		}

		if (!empty($settings['subtitle'])) {
			$subtitle_html .= '<' . $settings['subtitle_html_tag'] . ' class="info-box-subtitle subtitle">' . esc_html($settings['subtitle']) . '</' . $settings['subtitle_html_tag'] . '>';
		}

		if (!empty($settings['delimiter_style'])) {
			$delimiter_styles .= 'style="border-bottom-style:' . $settings['delimiter_style'] . '"';
		}

		if ($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter" ' . $delimiter_styles . '></div></div>';
		}
		
		$content_html .= '<div class="description">' . $settings['content'] . '</div>';

		if ($settings['readmore_show'] === 'yes') {
			if ($settings['readmore_style'] == 'read-more-09') {
				$readmore_class = 'chaffle';
				$readmore_data = 'data-lang="en"';
			}
			if (!empty($settings['link']) && $settings['read_more'] === 'more') {
				$more_open = '<div><div class="dfd-module-readmore"><a ' . $link_atts . ' class="' . $settings['readmore_style'] . ' ' . $readmore_class . '" ' . $readmore_data . '>';
				$more_close = '</a></div></div>';
			} else {
				$more_open = '<div><div class="dfd-module-readmore"><span class="' . $settings['readmore_style'] . '">';
				$more_close = '</span></div></div>';
			}
			if ($settings['readmore_style'] === 'read-more-01') {
				$read_more_html .= $more_open . $settings['readmore_text'] . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-02' || $settings['readmore_style'] === 'read-more-03' || $settings['readmore_style'] === 'read-more-04' || $settings['readmore_style'] === 'read-more-10') {
				$read_more_html .= $more_open . '<span></span><span></span><span></span>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-05') {
				$read_more_html .= $more_open . '<i class="dfd-icon-down_right"></i><span>' . $settings['readmore_text'] . '</span><i class="dfd-icon-down_right"></i>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-06') {
				$read_more_html .= $more_open . '<i class="dfd-icon-down_right"></i>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-07') {
				$read_more_html .= $more_open . '<i class="dfd-added-font-icon-right-open"></i>' . $more_close;
			} else {
				$read_more_html .= $more_open . $settings['readmore_text'] . $more_close;
			}
		}
		
		if ($settings['style'] === 'style-06') {
			$settings['layout'] = 'layout-01';
		}

		$output .= '<div id="' . $id . '" class="dfd-info-box clearfix ' . $settings['style'] . ' ' . $settings['layout'] . ' ' . $el_class . '">';
		$output .= '<div class="dfd-animate-container">';

		switch ($settings['layout']) {
			case 'layout-01':
				$output .= $icon_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'layout-02':
				$output .= $content_html;
				$output .= $delimiter_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $icon_html;
				$output .= $read_more_html;
				break;

			case 'layout-03':
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $icon_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'layout-04':
			case 'layout-05':
				$output .= $icon_html;
				$output .= '<div class="content-wrap ovh">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			case 'layout-06':
			case 'layout-07':
				$output .= $icon_html;
				$output .= '<div class="content-wrap ovh">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= '</div>';
				$output .= '<div class="clear ovh">';
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			default:

				$output .= $icon_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
		}

		if (!empty($settings['link']) && $settings['read_more'] === 'box') {
			$output .= '<a ' . $link_atts . ' class="full-box-link"></a>';
		}

		$output .= '</div>';
		$output .= '</div>';

		echo $output;
	}

}
