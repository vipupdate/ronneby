<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Rotate_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_rotate_box';
	}

	public function get_title() {
		return esc_html__('DFD Rotate box', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'rotate_box';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_rotate_box', [
				'label' => esc_html__('Rotate Box', 'dfd')
			]
		);

		$this->add_control(
			'main_style', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'to-left' => esc_html__('Rotate left', 'dfd'),
					'to-right' => esc_html__('Rotate right', 'dfd'),
					'to-bottom' => esc_html__('Rotate bottom', 'dfd'),
					'to-top' => esc_html__('Rotate top', 'dfd')
				],
				'default' => 'to-left'
			]
		);
		
		$this->add_control(
			'height_block', [
				'label' => esc_html__('Rotate item height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'link_box', [
				'label' => esc_html__('Link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'link', [
				'label' => esc_html__('Add link', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_front', [
				'label' => esc_html__('Front Side', 'dfd')
			]
		);
		
		$this->add_control(
			'bg_style', [
				'label' => esc_html__('Background style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'image' => esc_html__('Image', 'dfd'),
					'color' => esc_html__('Color', 'dfd')
				],
				'default' => 'color'
			]
		);
		
		$this->add_control(
			'image', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'bg_style' => 'image'
				]
			]
		);
		
		$this->add_control(
			'mask_background', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'bg_style' => 'color'
				]
			]
		);
		
		$this->add_control(
			'title_first', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Title', 'dfd')
			]
		);

		$this->add_control(
			'subtitle_first', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Subtitle', 'dfd')
			]
		);
		
		$this->add_control(
			'h_alignment', [
				'label' => esc_html__('Horizontal alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [ 
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-left'
			]
		);
		
		$this->add_control(
			'v_alignment', [
				'label' => esc_html__('Vertical alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'vertical-top' => esc_html__('Top', 'dfd'),
					'vertical-center' => esc_html__('Center', 'dfd'),
					'vertical-bottom' => esc_html__('Bottom', 'dfd')
				],
				'default' => 'vertical-center'
			]
		);
		
		$this->add_control(
			'front_content_vertical_offset', [
				'label' => esc_html__('Top/bottom offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'front_content_horizontal_offset', [
				'label' => esc_html__('Left/right offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'heading_decoration', [
				'label' => esc_html__('Heading decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'title_background', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title background', 'dfd'),
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_padding_top', [
				'label' => esc_html__('Padding top', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_padding_right', [
				'label' => esc_html__('Padding right', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_padding_bottom', [
				'label' => esc_html__('Padding bottom', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_padding_left', [
				'label' => esc_html__('Padding left', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_margin_top', [
				'label' => esc_html__('Margin top', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_margin_right', [
				'label' => esc_html__('Margin right', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_margin_bottom', [
				'label' => esc_html__('Margin bottom', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'title_margin_left', [
				'label' => esc_html__('Margin left', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'heading_decoration' => 'yes'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_back', [
				'label' => esc_html__('Back Side', 'dfd')
			]
		);
		
		$this->add_control(
			'bg_style_reverse', [
				'label' => esc_html__('Background style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'image' => esc_html__('Image', 'dfd'),
					'color' => esc_html__('Color', 'dfd')
				],
				'default' => 'color'
			]
		);
		
		$this->add_control(
			'image_id_reverse', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'bg_style_reverse' => 'image'
				]
			]
		);
		
		$this->add_control(
			'mask_bg_reverse', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'bg_style_reverse' => 'color'
				]
			]
		);
		
		$this->add_control(
			'desc_reverse', [
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA
			]
		);
		
		$this->add_control(
			'back_content_vertical_offset', [
				'label' => esc_html__('Top/bottom offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'back_content_horizontal_offset', [
				'label' => esc_html__('Left/right offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'add_info_section', [
				'label' => esc_html__('Additional info', 'dfd')
			]
		);
		
		$this->add_control(
			'block_number', [
				'label' => esc_html__('Additional info', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'number_text', [
				'label' => esc_html__('Info', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'number_alignment', [
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-left',
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'number_position', [
				'label' => esc_html__('Position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'number-before-content' => esc_html__('Top', 'dfd'),
					'number-after-content' => esc_html__('Bottom', 'dfd')
				],
				'default' => 'number-before-content',
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_typography_heading', [
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Title typography', 'dfd'),
			]
		);

		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block .title-first' => 'color: {{VALUE}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block .title-first'
			]
		);

		$this->add_control(
			'subtitle_typography_heading', [
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'separator' => 'before'
			]
		);

		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block .subtitle-first' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block .subtitle-first'
			]
		);

		$this->add_control(
			'content_typography_heading', [
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Description typography', 'dfd'),
				'separator' => 'before'
			]
		);

		$this->add_control(
			'content_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back .content-wrap .description-reverse' => 'color: {{VALUE}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'content-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-rotate-box-wrap .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back .content-wrap .description-reverse'
			]
		);
		
		$this->add_control(
			'number_t_heading', [
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Info typography', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);

		$this->add_control(
			'info_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-rotate-box-number' => 'color: {{VALUE}};'
				],
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'info-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-rotate-box-number',
				'condition' => [
					'block_number' => 'yes'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$uniqid = $el_class = $output = $link_css = $link_html = $image_url = $img_src = $title_html = $subtitle_html = '';
		$content_alignment = $desc_reverse_html = $before_title_html = $after_title_html = '';

		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-rotate-box-') . '-' . rand(1, 9999);

		$el_class .= ' ' . $settings['main_style'];

		if (isset($settings['number_position']) && $settings['number_position'] != '' && isset($settings['block_number']) && $settings['block_number'] = 'yes' && isset($settings['number_text']) && !empty($settings['number_text'])) {
			$el_class .= ' ' . $settings['number_position'];
		}

		if (isset($settings['heading_decoration']) && $settings['heading_decoration'] == 'yes') {
			$before_title_html = '<div class="title-decoration">';
			$after_title_html = '</div>';
			if (isset($settings['title_padding_top']) && $settings['title_padding_top'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {padding-top: ' . esc_js($settings['title_padding_top']) . 'px;}';
			}
			if (isset($settings['title_padding_right']) && $settings['title_padding_right'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {padding-right: ' . esc_js($settings['title_padding_right']) . 'px;}';
			}
			if (isset($settings['title_padding_bottom']) && $settings['title_padding_bottom'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {padding-bottom: ' . esc_js($settings['title_padding_bottom']) . 'px;}';
			}
			if (isset($settings['title_padding_left']) && $settings['title_padding_left'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {padding-left: ' . esc_js($settings['title_padding_left']) . 'px;}';
			}
			if (isset($settings['title_margin_top']) && $settings['title_margin_top'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {margin-top: ' . esc_js($settings['title_margin_top']) . 'px;}';
			}
			if (isset($settings['title_margin_right']) && $settings['title_margin_right'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {margin-right: ' . esc_js($settings['title_margin_right']) . 'px;}';
			}
			if (isset($settings['title_margin_bottom']) && $settings['title_margin_bottom'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {margin-bottom: ' . esc_js($settings['title_margin_bottom']) . 'px;}';
			}
			if (isset($settings['title_margin_left']) && $settings['title_margin_left'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {margin-left: ' . esc_js($settings['title_margin_left']) . 'px;}';
			}
			if (isset($settings['title_background']) && !empty($settings['title_background'])) {
				$link_css .= '#' . esc_js($uniqid) . ' .title-decoration {background: ' . esc_js($settings['title_background']) . ';}';
			}
		}

		// Height block
		if (isset($settings['height_block']) && !empty($settings['height_block'])) {
			$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front, #' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back {min-height: ' . $settings['height_block'] . 'px !important; }';
		}

		// Alignment
		if (isset($settings['v_alignment'])) {
			if ($settings['v_alignment'] == 'vertical-top') {
				$content_alignment .= 'dfd-rotate-content-top ';
			}
			if ($settings['v_alignment'] == 'vertical-center') {
				$content_alignment .= 'dfd-rotate-content-v_center ';
			}
			if ($settings['v_alignment'] == 'vertical-bottom') {
				$content_alignment .= 'dfd-rotate-content-bottom ';
			}
		}
		if (isset($settings['h_alignment'])) {
			if ($settings['h_alignment'] == 'text-left') {
				$content_alignment .= 'dfd-rotate-content-left ';
			}
			if ($settings['h_alignment'] == 'text-center') {
				$content_alignment .= 'dfd-rotate-content-h_center ';
			}
			if ($settings['h_alignment'] == 'text-right') {
				$content_alignment .= 'dfd-rotate-content-right ';
			}
		}

		if (isset($settings['front_content_vertical_offset']) && $settings['front_content_vertical_offset'] != '') {
			$link_css .= '#' . esc_js($uniqid) . ' .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block {padding-top: ' . esc_js($settings['front_content_vertical_offset']) . 'px; padding-bottom: ' . esc_js($settings['front_content_vertical_offset']) . 'px;}';
		}
		if (isset($settings['front_content_horizontal_offset']) && $settings['front_content_horizontal_offset'] != '') {
			$link_css .= '#' . esc_js($uniqid) . ' .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front .content-wrap .content-block {padding-left: ' . esc_js($settings['front_content_horizontal_offset']) . 'px; padding-right: ' . esc_js($settings['front_content_horizontal_offset']) . 'px;}';
		}
		if (isset($settings['back_content_vertical_offset']) && $settings['back_content_vertical_offset'] != '') {
			$link_css .= '#' . esc_js($uniqid) . ' .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back .content-wrap {padding-top: ' . esc_js($settings['back_content_vertical_offset']) . 'px; padding-bottom: ' . esc_js($settings['back_content_vertical_offset']) . 'px;}';
		}
		if (isset($settings['back_content_horizontal_offset']) && $settings['back_content_horizontal_offset'] != '') {
			$link_css .= '#' . esc_js($uniqid) . ' .rotate-box .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back .content-wrap {padding-left: ' . esc_js($settings['back_content_horizontal_offset']) . 'px; padding-right: ' . esc_js($settings['back_content_horizontal_offset']) . 'px;}';
		}

		$output .= '<div id="' . esc_attr($uniqid) . '" class="dfd-rotate-box-wrap ' . esc_attr($el_class) . '" >';
		$output .= '<div class="dfd-rotate-box-list">';

		// First Side
		if (isset($settings['title_first']) && !empty($settings['title_first'])) {
			$title_html = '<' . $settings['title_html_tag'] . ' class="title-first">' . wp_kses($settings['title_first'], array('br' => array())) . '</' . $settings['title_html_tag'] . '>';
		}
		if (isset($settings['subtitle_first']) && !empty($settings['subtitle_first'])) {
			$subtitle_html = '<' . $settings['subtitle_html_tag'] . ' class="subtitle-first ">' . wp_kses($settings['subtitle_first'], array('br' => array())) . '</' . $settings['subtitle_html_tag'] . '>';
		}

		if (isset($settings['bg_style']) && $settings['bg_style'] == 'image' && isset($settings['image']) && !empty($settings['image'])) {
			$image_url = wp_get_attachment_image_src($settings['image'], 'full');

			if (!empty($settings['image']['url'])) {
				$img_src = $image_url = $settings['image']['url'];
			}
			$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front {background-image: url(' . $img_src . '); }';
		} else {
			if (isset($settings['mask_background']) && !empty($settings['mask_background'])) {
				$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-front {background-color: ' . $settings['mask_background'] . '; }';
			}
		}
		// Reverse Side
		if (isset($settings['desc_reverse']) && !empty($settings['desc_reverse'])) {
			$desc_reverse_html = '<div class="description-reverse">' . wp_kses($settings['desc_reverse'], array('br' => array())) . '</div>';
		}

		if (isset($settings['bg_style_reverse']) && $settings['bg_style_reverse'] == 'image' && isset($settings['image_id_reverse']) && !empty($settings['image_id_reverse'])) {
			if (!empty($settings['image_id_reverse']['url'])) {
				$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back {background-image: url(' . $settings['image_id_reverse']['url'] . '); }';
			}
		} else {
			if (isset($settings['mask_bg_reverse']) && !empty($settings['mask_bg_reverse'])) {
				$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-item .thumb-wrap .thumb-wrap-back {background-color: ' . $settings['mask_bg_reverse'] . ' }';
			}
		}

		if (isset($settings['link_box']) && !empty($settings['link_box'])) {
			$link_atts .= 'href="' . (!empty($settings['link_box']['url']) ? esc_url($settings['link_box']['url']) : '#') . '"';
			$link_atts .= ' target="' . (!empty($settings['link_box']['is_external']) ? '_blank' : '_self' ) . '"';
			$link_atts .= !empty($settings['link_box']['nofollow']) ? ' rel="nofollow"' : '';
			$link_atts .= !empty($settings['link_box']['custom_attributes']) ? ' ' . esc_attr($settings['link_box']['custom_attributes']) : '';
			$link_html = '<a ' . $link_atts . ' class="full-box-link"></a>';
		} 

		$output .= '<div class="dfd-item-offset rotate-box">';
		$output .= '<div class="dfd-rotate-box-item ' . esc_attr($settings['main_style']) . '">';
		$output .= '<div class="thumb-wrap">';
		$output .= '<div class="thumb-wrap-front dfd-background-main">';
		$output .= '<div class="content-wrap">';
		$output .= '<div class="content-block ' . esc_attr($content_alignment) . '">';
		$output .= $before_title_html;
		$output .= $title_html;
		$output .= $subtitle_html;
		$output .= $after_title_html;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="thumb-wrap-back dfd-background-main">';
		$output .= '<div class="content-wrap">';
		$output .= $desc_reverse_html;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
		$output .= $link_html;
		$output .= '</div>';
		$output .= '</div>';

		if (isset($settings['block_number']) && $settings['block_number'] = 'yes' && isset($settings['number_text']) && !empty($settings['number_text'])) {
			if (isset($settings['number_font_size']) && $settings['number_font_size'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-number {font-size: ' . esc_js($settings['number_font_size']) . 'px;}';
				$link_css .= '#' . esc_js($uniqid) . '.number-before-content {padding-top: ' . (esc_js($settings['number_font_size']) / 2) . 'px;}';
				$link_css .= '#' . esc_js($uniqid) . '.number-after-content {padding-bottom: ' . (esc_js($settings['number_font_size']) / 2) . 'px;}';
			}

			if (isset($settings['block_number']) && $settings['block_number'] != '') {
				$link_css .= '#' . esc_js($uniqid) . ' .dfd-rotate-box-number ';
			}
			$output .= '<div class="dfd-rotate-box-number dfd-content-title-big ' . esc_attr($settings['number_alignment']) . '">' . esc_html($settings['number_text']) . '</div>';
		}

		$output .= '</div>';

		if (!empty($link_css)) {
			$output .= '<script type="text/javascript">'
							. '(function($) {'
								. '$("head").append("<style>' . $link_css . '</style>");'
							. '})(jQuery);'
						. '</script>';
		}

		$output .= '</div>';

		echo $output;
	}

}
