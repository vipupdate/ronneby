<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Icon_List extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_icon_list';
	}

	public function get_title() {
		return esc_html__('DFD Icon list', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_icon_list';
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'el_icon_list',
			[
				'label' => esc_html__('Icon list', 'dfd')
			]
		);
		
		$this->add_control(
			'main_style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Simple', 'dfd'),
					'style-2' => esc_html__('Separated', 'dfd'),
					'style-3' => esc_html__('Half-divided', 'dfd'),
					'style-4' => esc_html__('Underlined', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'icon_list_content',
			[
				'label' => esc_html__('Icon list content', 'dfd')
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon manager', 'dfd'),
					'custom' => esc_html__('Custom image', 'dfd'),
					'none' => esc_html__('Without icon', 'dfd')
				],
				'default' => 'selector'
			]
		);
		
		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__('Select icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector'
				]
			]
		);
		
		$repeater->add_control(
			'icon_img',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom'
				]
			]
		);
		
		$repeater->add_control(
			'link_box',
			[
				'label' => esc_html__('Link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$repeater->add_control(
			'link',
			[
				'label' => esc_html__('Add link', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'link_box' => 'yes'
				]
			]
		);
		
		$repeater->add_control(
			'content',
			[
				'label' => '',
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => '<p>' . esc_html__( 'Lorem ipsum dolor sit amet.', 'dfd' ) . '</p>',
			]
		);
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'icon_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Icon style', 'dfd'),
			]
		);
		
		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'font-size: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'icon_margin',
			[
				'label' => esc_html__('Space after icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 10
			]
		);
		
		$this->add_control(
			'icon_bottom_spase',
			[
				'label' => esc_html__('Space under list item', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'thumb_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Thumb style', 'dfd'),
			]
		);
		
		$this->add_control(
			'icon_dec_size',
			[
				'label' => esc_html__('Thumb size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'icon_border_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'icon_background',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'icon_border_style',
			[
				'label' => esc_html__('Thumb border style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'double' => esc_html__('Double', 'dfd'),
					'inset' => esc_html__('Inset', 'dfd'),
					'outset' => esc_html__('Outset', 'dfd')
				],
				'default' => 'none',
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'border-style: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'icon_border_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'icon_border_style!' => 'none'
				]
			]
		);
		
		$this->add_control(
			'icon_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'icon_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-list-icon-block' => 'border-color: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'delimiter_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Delimiter style', 'dfd'),
				'condition' => [
					'main_style!' => 'style-1'
				]
			]
		);
		
		$this->add_control(
			'del_height',
			[
				'label' => esc_html__('Delimiter height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style!' => 'style-1'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-icon-item-delimiter' => 'border-bottom-width: {{SCHEME}}px;'
				],
				'default' => 1
			]
		);
		
		$this->add_control(
			'del_style',
			[
				'label' => esc_html__('Delimiter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dotted' => esc_html__('Dotted', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd'),
					'double' => esc_html__('Double', 'dfd')
				],
				'condition' => [
					'main_style!' => 'style-1'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-icon-item-delimiter' => 'border-style: {{SCHEME}};'//VALUE
				],
				'default' => 'dotted'
			]
		);
		
		$this->add_control(
			'del_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'condition' => [
					'main_style!' => 'style-1'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-icon-item-delimiter' => 'border-color: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-icon-list .content',
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-icon-list .content' => 'color: {{VALUE}};'
				],
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'color_link',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color link on hover', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-icon-list li.with-link:hover .dfd-list-content .dfd-list-content-block' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $main_style_class = $link_css = $output_item_html = $cover_class = '';
		
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-icon-list-').'-'.rand(1,9999);

		if(!empty($settings['main_style']) && strcmp($settings['main_style'], 'style-1') !== 0) {
			if(strcmp($settings['main_style'], 'style-2') === 0) {
				$main_style_class = ' del-full-width';
			} elseif(strcmp($settings['main_style'], 'style-3') === 0) {
				$main_style_class = ' del-half-width';
			} elseif(strcmp($settings['main_style'], 'style-4') === 0) {
				$main_style_class = ' del-width-net-icon';
			}
		}

		$output .= '<div id="'.esc_attr($uniqid).'" class="dfd-icon-list-wrap '.$main_style_class.' '.esc_attr($settings['main_style']).'">';
			$output .= '<ul class="dfd-icon-list">';
			
				foreach($settings['list_fields'] as $fields) {
					$link_class = $link_atts = $link_html = $icon_content = $del_html = $thumb_size = $output_item = '';
					if(isset($fields['link_box']) && $fields['link_box'] == 'yes') {
						$link_class = 'with-link';
						if(!empty($fields['link'])) {
							$link_atts .= 'href="' . (!empty($fields['link']['url']) ? esc_url($fields['link']['url']) : '#') . '"';
							$link_atts .= ' target="' . (!empty($fields['link']['is_external']) ? '_blank' : '_self' ) . '"';
							$link_atts .= !empty($fields['link']['nofollow']) ? ' rel="nofollow"' : '';
							$link_atts .= !empty($fields['link']['custom_attributes']) ? ' ' . esc_attr($fields['link']['custom_attributes']) : '';
						}
						$link_html = '<a '.$link_atts.' class="item-link"></a>';
					}
			
					if($settings['icon_margin'] !== '' && is_rtl()) {
						$link_css .= '#'.esc_attr($uniqid).' .dfd-list-icon-block {margin-left:'.esc_attr($settings['icon_margin']).'px;}';
					} else if($settings['icon_margin'] !== '') {
						$link_css .= '#'.esc_attr($uniqid).' .dfd-list-icon-block {margin-right:'.esc_attr($settings['icon_margin']).'px;}';
					} else {
						$settings['icon_margin'] = 10;
					}

					if($settings['icon_bottom_spase'] !== '') {
						if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-1') === 0) {
							$link_css .= '#'.esc_attr($uniqid).' .dfd-list-content {padding-bottom:'.esc_attr($settings['icon_bottom_spase']).'px;}';
						}else{
							$link_css .= '#'.esc_attr($uniqid).' .dfd-list-content {padding:'.esc_attr($settings['icon_bottom_spase']).'px 0;}';
						}
					}

					if(isset($fields['icon']['value']) && !empty($fields['icon']['value'] && strcmp($fields['icon_type'], 'selector') == 0)) {
						$icon_content = '<i class = "' . esc_attr($fields['icon']['value']) . '"></i>';
					} else {
						$icon_content = '<i class = "none"></i>';
					}

					if(isset($settings['icon_dec_size']) && !empty($settings['icon_dec_size'])) {
						$link_css .= '#'.esc_attr($uniqid).' .dfd-list-icon-block {width:' . esc_attr($settings['icon_dec_size']) . 'px; height:' . esc_attr($settings['icon_dec_size']) . 'px;}';
					} else {
						$settings['icon_dec_size'] = 36;
					}

					if($settings['icon_border_width']) {
						if($settings['icon_border_width']) {
							$link_css .= '#'.esc_attr($uniqid).' .dfd-list-icon-block {border-width:' . esc_attr($settings['icon_border_width']) . 'px;}';
						}
					}

					if (isset($fields['icon_img']['url']) && !empty($fields['icon_img']['url']) && strcmp($fields['icon_type'], 'custom') == 0) {
						if(isset($settings['icon_border_width']) && !empty($settings['icon_border_width'])) {
							$thumb_size = $settings['icon_dec_size'] - $settings['icon_border_width'] * 2;
						} else {
							$thumb_size = $settings['icon_dec_size'];
						}

						$avatar = dfd_aq_resize( $fields['icon_img']['url'], $thumb_size, $thumb_size, true, true, true );

						$attr = Dfd_Theme_Helpers::get_image_attrs($avatar, $fields['icon_img']['url'], $thumb_size, $thumb_size);

						global $dfd_ronneby;
						if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
							$cover_class = 'dfd-img-lazy-load';
							$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $thumb_size $thumb_size'%2F%3E";
							$icon_content = '<img src="'.$loading_img_src.'" data-src="' . esc_url( $avatar ) . '" '.$attr.'/>';
						} else {
							$icon_content = '<img src="' . esc_url( $avatar ) . '" '.$attr.'/>';
						}
					}
			
					if((!empty($settings['main_style']) && strcmp($settings['main_style'], 'style-4') === 0) && (isset($fields['icon_type']) && strcmp($fields['icon_type'], 'none') !== 0)) {
						$del_offset = $settings['icon_margin'] + $settings['icon_dec_size'];
						$link_css .= '#'.esc_attr($uniqid).' .dfd-icon-item-delimiter {left: '.esc_attr($del_offset).'px;}';
					}

					if(!empty($settings['main_style']) && strcmp($settings['main_style'], 'style-1') !== 0) {
						$del_html .= '<span class="dfd-icon-item-delimiter"></span>';
					}
			
					$output_item .= '<div class="dfd-list-content clearfix '.$cover_class.'">';
					
						if(isset($fields['icon_type']) && strcmp($fields['icon_type'], 'none') !== 0) {
							$output_item .= '<div class="dfd-list-icon-block text-center">';
								$output_item .= $icon_content;
							$output_item .= '</div>';
						}

						$output_item .= '<div class="dfd-list-content-block content">';
							$output_item .= $fields['content'];
						$output_item .= '</div>';

					$output_item .= '</div>';
			
					$output_item .= $del_html;
					$output_item .= $link_html;

					$output_item_html .= '<li class="'.esc_attr($link_class).'">'.$output_item.'</li>';
				}
		
				$output .= $output_item_html;
			$output .= '</ul>';
		$output .= '</div>';

		if(!empty($link_css)) {
			$output .= '<script type="text/javascript">'
						. '(function($) {'
							. '$("head").append("<style>'.$link_css.'</style>");'
						. '})(jQuery);'
					. '</script>';
		}
		
		echo $output;
		
	}

}