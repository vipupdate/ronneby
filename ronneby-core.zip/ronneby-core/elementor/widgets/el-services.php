<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Services extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_services';
	}

	public function get_title() {
		return esc_html__('DFD Services', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_service_new';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_services',
				[
					'label' => esc_html__('Services', 'dfd')
				]
		);
		
		$this->add_control(
			'columns_width',
			[
				'label' => esc_html__('Element width', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'full-width-elements' => esc_html__('Inherit from container', 'dfd'),
					'half-size-elements' => esc_html__('Half size', 'dfd'),
					'one-third-width-elements' => esc_html__('1/3 of container width', 'dfd'),
					'quarter-width-elements' => esc_html__('1/4 of container width', 'dfd'),
					'fifth-width-elements' => esc_html__('1/5 of container width', 'dfd'),
					'sixth-width-elements' => esc_html__('1/6 of container width', 'dfd')
				],
				'default' => 'full-width-elements'
			]
		);
		
		$this->add_control(
			'vertical_content_offset', [
				'label' => esc_html__('Vertical content offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-service-description, {{WRAPPER}} .dfd-service-front' => 'padding: {{SCHEME}}px 50px;'
				]
			]
		);
		
		$this->add_control(
			'connector_style',
				[
					'label' => esc_html__('Border Style', 'dfd'),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'none' => esc_html__('None', 'dfd'),
						'solid' => esc_html__('Solid', 'dfd'),
						'dashed' => esc_html__('Dashed', 'dfd'),
						'dotted' => esc_html__('Dotted', 'dfd'),
						'double' => esc_html__('Double', 'dfd'),
						'inset' => esc_html__('Inset', 'dfd'),
						'outset' => esc_html__('Outset', 'dfd'),
					],
					'default' => 'none',
					'selectors' => [
						'{{WRAPPER}} .dfd-service-item  ' => 'border-style: {{SCHEME}};'
				]	
			]
		);
		
		$this->add_control(
			'connector_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border Color', 'dfd'),
				'condition' => [
					'connector_style!' => 'none'
				],
					'selectors' => [
						'{{WRAPPER}} .dfd-service-item  ' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'block_min_height', [
				'label' => esc_html__('Block min height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_con_services', [
				'label' => esc_html__('Service item', 'dfd')
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'style', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-01' => esc_html__('Simple', 'dfd'),
					'style-02' => esc_html__('Backround', 'dfd'),
					'style-03' => esc_html__('Bordered', 'dfd'),
					'style-04' => esc_html__('Overlay', 'dfd'),
					'style-05' => esc_html__('Top icon', 'dfd')
				],
				'default' => 'style-01'
			]
		);
		
		$repeater->add_control(
			'hover', [
				'label' => esc_html__('Hover Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'hover-01' => esc_html__('Slide left', 'dfd'),
					'hover-02' => esc_html__('Slide top', 'dfd'),
					'hover-03' => esc_html__('Slide bottom', 'dfd'),
					'hover-04' => esc_html__('Slide right', 'dfd'),
					'hover-05' => esc_html__('Slide in', 'dfd')
				],
				'default' => 'hover-01'
			]
		);
		
		$repeater->add_control(
			'dfd_service_link_apply', [
				'label' => esc_html__('Enable link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$repeater->add_control(
			'dfd_service_link', [
				'label' => esc_html__('Link URL', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'dfd_service_link_apply' => 'yes'
				]
			]
		);
		
		$repeater->add_control(
			'front_content_alignment', [
				'label' => esc_html__('Front content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					],
				],
				'default' => 'text-left',
				'condition' => [
					'style' => 'style-05'
				]
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Service title', 'dfd')
			]
		);
		
		$repeater->add_control(
			'subtitle', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Service subtitle', 'dfd')
			]
		);
		
		$repeater->add_control(
			'content', [
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('Service subtitle', 'dfd')
			]
		);
		
		$repeater->add_control(
			'desc_background', [
				'label' => esc_html__('Description background', 'dfd'),
				'type' => \Elementor\Controls_Manager::COLOR	
			]
		);
		$repeater->add_control(
			'icon', [
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				]
			]
		);

		$repeater->add_control(
			'icon_size', [
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$repeater->add_control(
			'icon_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd')
			]
		);
		
		$repeater->add_control(
			'icon_bg_size', [
				'label' => esc_html__('Icon background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['style-02', 'style-03', 'style-04']
				]
			]
		);
		
		$repeater->add_control(
			'border_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['style-01', 'style-02', 'style-03', 'style-04']
				]
			]
		);

		$repeater->add_control(
			'icon-backgroung', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'condition' => [
					'style' => ['style-02', 'style-03', 'style-04']
				],
			]
		);
		
		$repeater->add_control(
			'border_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'style' => 'style-03'
				]
			]
		);
		
		$repeater->add_control(
			'border_width', [
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => 'style-03'
				],
				'selectors' => [
					'{{{WRAPPER}} {{CURRENT_ITEM}} .module-icon' => 'border-width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'list_fields', [
				'label' => esc_html__('Service', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-banner-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .info-banner-title.feature-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-banner-subtitle.subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .info-banner-subtitle.subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'selector' => '{{WRAPPER}} .description'
			]
		);

		$this->add_control(
			'content_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .description' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$output = $desc_background_css = '';
		
		$settings = $this->get_settings_for_display();

		$output .= '<div class="dfd-service-module-wrap" > ';
		$output .= '<ul class="dfd-service-list dfd-mobile-keep-height ' . $settings['columns_width'] . ' " > ';
		
		foreach($settings['list_fields'] as $fields) {

			$title_html = $subtitle_html = $content_html = $icon_html = $desc_background_css = $icon_style = $icon_i_style = $link_atts = $front_class = '';
			if (!empty($fields['dfd_service_link'])) {
			$link_atts .= '<a class="abs-link"';
				$link_atts .= 'href="' . (!empty($fields['dfd_service_link']['url']) ? esc_url($fields['dfd_service_link']['url']) : '#') . '"';
				$link_atts .= ' target="' . (!empty($fields['dfd_service_link']['is_external']) ? '_blank' : '_self' ) . '"';
				$link_atts .= !empty($fields['dfd_service_link']['nofollow']) ? ' rel="nofollow"' : '';
				$link_atts .= !empty($fields['dfd_service_link']['custom_attributes']) ? ' ' . esc_attr($fields['dfd_service_link']['custom_attributes']) : '';
			$link_atts .= '></a>';
			}
			
			if(isset($fields['front_content_alignment']) && !empty($fields['front_content_alignment']) && $fields['style'] == 'style-05') {
				$front_class .= esc_attr($fields['front_content_alignment']);
			}

			$output .= '<li class="dfd-service-item" > ';
			$output .= '<div class="dfd-service-item  ' . $fields['style'] . '  ' . $fields['hover'] . '">';
			$output .= '<div class="dfd-service-front dfd-equalize-height">';

			$output .= '<div class="dfd-service-front-wrap dfd-vertical-aligned '.$front_class.'">';

			if (!empty($fields['title'])) {
				$title_html .= '<' . $settings['title_html_tag'] . ' class="info-banner-title feature-title">' . esc_html($fields['title']) . '</' . $settings['title_html_tag'] . '>';
			}
			if (!empty($fields['subtitle'])) {
				$subtitle_html .= '<' . $settings['subtitle_html_tag'] . ' class="info-banner-subtitle subtitle">' . esc_html($fields['subtitle']) . '</' . $settings['subtitle_html_tag'] . '>';
			}

			if ($fields['border_radius'] || $fields['border_color'] || isset($fields['border_width']) || $fields['icon_bg_size'] || $fields['icon-backgroung']) {

				$icon_style .= 'style="';
				if (!empty($fields['border_radius'])) {
					$icon_style .= 'border-radius:' . $fields['border_radius'] . 'px;';
				}
				if ($fields['border_color']) {
					$icon_style .= 'border-color:' . $fields['border_color'] . ';';
				}
				if (( 'style-03' === $fields['style'] ) && $fields['border_width']) {
					$icon_style .= 'border-width:' . $fields['border_width'] . 'px;';
				}
				if ($fields['icon_bg_size']) {
					$icon_style .= 'font-size:' . $fields['icon_bg_size'] . 'px;';
				}
				if (!empty($fields['icon-backgroung'])) {
					$icon_style .= 'background-color:' . $fields['icon-backgroung'] . ';';
				}
				$icon_style .= '"';
			}
			$icon_i_style .= 'style="';
			if (!empty($fields['opacity'])) {
				$icon_i_style .= 'opacity:' . $fields['opacity'] . '%;';
			}
			if(!empty($fields['icon_size'])) {
				$icon_i_style .= 'font-size:' . $fields['icon_size'] . 'px;';
			}
			if (!empty($fields['icon_color'])) {
				$icon_i_style .= 'color:' . $fields['icon_color'] . ';';
			}
			$icon_i_style .= '"';

			$icon_html .= '<div class="module-icon"' . $icon_style . '>';
			$icon_html .= '<i class="featured-icon ' . esc_attr($fields['icon']['value']) . '"' . $icon_i_style . '></i>';
			$icon_html .= '</div>';

			$content_html .= '<div class="description dfd-vertical-aligned" >' . $fields['content'] . '</div>';
			$content_html .= $link_atts;
			$desc_background_css .= 'style="';

			if (!empty($fields['desc_background'])) {
				$desc_background_css .= 'background:' . $fields['desc_background'] . '; ';
			}

			$desc_background_css .= '"';

			$output .= $icon_html;
			$output .= '<div class="content-wrapper">';
			$output .= $title_html;
			$output .= $subtitle_html;
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="dfd-service-description dfd-service-back dfd-equalize-height" ' . $desc_background_css . '>';
			$output .= $content_html;
			$output .= '</div>';
			$output .= '</li>';
		}
		$output .= '</ul>';
		
		$output .= '</div>';

		echo $output;
	}

}
