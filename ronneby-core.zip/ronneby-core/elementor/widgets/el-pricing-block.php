<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Pricing_block extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_pricing_block';
	}

	public function get_title() {
		return esc_html__('DFD Pricing block', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'pricing_block';
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'el_pricing_block',
			[
				'label' => esc_html__('Pricing block', 'dfd')
			]
		);
		
		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-01' => esc_html__('Classic', 'dfd'),
					'style-02' => esc_html__('Simple', 'dfd'),
					'style-03' => esc_html__('Main', 'dfd'),
					'style-04' => esc_html__('Colored', 'dfd')
				],
				'default' => 'style-01'
			]
		);
		
		$this->add_control(
			'slim',
			[
				'label' => esc_html__('Slim style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'currency_symbol',
			[
				'label' => esc_html__('Currency symbol', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'payment_amount',
			[
				'label' => esc_html__('Price', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'time_interval',
			[
				'label' => esc_html__('Recurring fee', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'show_icon',
			[
				'label' => esc_html__('Icon in header', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'header_icon',
			[
				'label' => esc_html__('Header icon', 'dfd'),
				'condition' => [
					'show_icon' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'icon_type',
			[
				'label' => esc_html__('Icon to display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'selector' => esc_html__('Icon', 'dfd'),
					'custom' => esc_html__('Image', 'dfd')
				],
				'condition' => [
					'show_icon' => 'yes'
				],
				'default' => 'selector'
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__('Opacity', 'dfd'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					]
				],
				'default' => [
					'size' => '100'
				],
				'condition' => [
					'icon_type' => 'custom',
					'show_icon' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'show_icon' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'icon_type' => 'selector',
					'show_icon' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'icon_type' => 'selector',
					'show_icon' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon_image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'icon_type' => 'custom',
					'show_icon' => 'yes'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__('Content', 'dfd')
			]
		);
		
		$this->add_control(
			'description',
			[
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'feature_style',
			[
				'label' => esc_html__('Type', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'text_icon' => esc_html__('Text with icon', 'dfd'),
					'text_only' => esc_html__('Only text', 'dfd'),
					'icon_only' => esc_html__('Only Icon', 'dfd'),
					'dot-enabled' => esc_html__('Dot Enabled', 'dfd'),
					'dot-disabled' => esc_html__('Dot Disabled', 'dfd'),
					'dot' => esc_html__('Dot Custom', 'dfd')
				],
				'default' => 'text_icon'
			]
		);
		
		$repeater->add_control(
			'label',
			[
				'label' => esc_html__('Label', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'feature_style' => ['text_icon', 'text_only']
				]
			]
		);
		
		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'dfd-icon-celsius',
					'library' => 'dfd_icons'
				],
				'condition' => [
					'feature_style' => ['text_icon', 'icon_only']
				]
			]
		);
		
		$repeater->add_control(
			'dot_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'feature_style' => 'dot'
				]
			]
		);
		
		$this->add_control(
			'values',
			[
				'label' => esc_html__('Features', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button link', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Main styles', 'dfd'),
			]
		);
		
		$this->add_control(
			'border_style',
			[
				'label' => esc_html__('Border style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-pricing-block' => 'border-style: {{VALUE}};'
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-pricing-block' => 'border-color: {{VALUE}};'
				],
				'condition' => [
					'border_style!' => ''
				]
			]
		);
		
		$this->add_control(
			'border_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-pricing-block' => 'border-width: {{VALUE}}px;'
				],
				'condition' => [
					'border_style!' => ''
				]
			]
		);
		
		$this->add_control(
			'head_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Heading background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .block-head' => 'background-color: {{SCHEME}};',
					'{{WRAPPER}} .dfd-pricing-block.style-01 .block-head:before' => 'background: linear-gradient(45deg, transparent 33.333%, {{SCHEME}} 33.333%, {{SCHEME}} 66.667%, transparent 66.667%), linear-gradient(-45deg, transparent 33.333%, {{SCHEME}} 33.333%, {{SCHEME}} 66.667%, transparent 66.667%);',
					'{{WRAPPER}} .dfd-pricing-block.style-01 .block-head:after' => 'background: linear-gradient(45deg, transparent 33.333%, #ffffff 33.333%, #ffffff 66.667%, transparent 66.667%), linear-gradient(-45deg, {{SCHEME}} 33.333%, transparent 33.333%, transparent 66.667%, {{SCHEME}} 66.667%);',
					'{{WRAPPER}} .dfd-pricing-block.style-01 .block-head:before, {{WRAPPER}} .dfd-pricing-block.style-01 .block-head:after' => 'background-size: 10px 20px;'
				],
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'desc_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Features background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .block-desc' => 'background-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'feat_mark',
			[
				'label' => esc_html__('Label', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'feat_mark_text',
			[
				'label' => esc_html__('Label text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'feat_mark' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'feat_mark_style',
			[
				'label' => esc_html__('Lebel style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-01' => esc_html__('Rounded', 'dfd'),
					'style-02' => esc_html__('Square', 'dfd')
				],
				'condition' => [
					'feat_mark' => 'yes'
				],
				'default' => 'style-01'
			]
		);
		
		$this->add_control(
			'feat_mark_text_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Label text color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .feat-mark' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'feat_mark_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Label backgrond', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .feat-mark' => 'background-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'price_sep',
			[
				'label' => esc_html__('Price delimiter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'price_sep' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .price-sep' => 'border-color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'line_width',
			[
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'price_sep' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} ..price-sep' => 'width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'price_sep' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .price-sep' => 'border-width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'price_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Currency, price & recurring fee color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .currency-symbol, {{WRAPPER}} .payment-amount,{{WRAPPER}} .time-interval' => 'color: {{VALUE}};'
				],
				'separator' => 'before',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'content_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Content settings', 'dfd'),
			]
		);
		
		$this->add_control(
			'content_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .desc-text' => 'color: {{VALUE}} !important;'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'button_style_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Button settings', 'dfd'),
			]
		);
		
		$this->add_control(
			'extended_button_settings',
			[
				'label' => esc_html__('Custom styles', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'button_border_style',
			[
				'label' => esc_html__('Border style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button' => 'border-style: {{SCHEME}};'
				],
				'condition' => [
					'extended_button_settings' => 'yes'
				],
				'default' => 'none'
			]
		);
		
		$this->add_control(
			'button_border_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'button_border_style!' => 'none',
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->start_controls_tabs(
			'dfd_button_styles', [
				'separator' => 'before',
				'condition' => [
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->start_controls_tab(
			'dfd_button_styles_normal',
			[
				'label' => esc_html__('Normal', 'dfd')
			]
		);
		
		$this->add_control(
			'button_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button' => 'border-color: {{VALUE}};'
				],
				'condition' => [
					'button_border_style!' => 'none'
				]
			]
		);
		
		$this->add_control(
			'button_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button' => 'background: {{VALUE}};'
				],
				'condition' => [
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'button_text_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Text color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button' => 'color: {{VALUE}};'
				],
				'condition' => [
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'dfd_button_styles_hover',
			[
				'label' => esc_html__('Hover', 'dfd')
			]
		);
		
		$this->add_control(
			'button_border_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button:hover' => 'border-color: {{VALUE}};'
				],
				'condition' => [
					'button_border_style!' => 'none'
				]
			]
		);
		
		$this->add_control(
			'button_background_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button:hover' => 'background: {{VALUE}};'
				],
				'condition' => [
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'button_text_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Text color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .pricing-button.button:hover' => 'color: {{VALUE}};'
				],
				'condition' => [
					'extended_button_settings' => 'yes'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);
		
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .feature-title'
			]
		);
		
		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'separator' => 'before',
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .subtitle'
			]
		);

		$this->add_control(
			'content_color_typography',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .price-feature' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-content-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'selector' => '{{WRAPPER}} .price-feature'
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $no_margin_class = $link_atts = $el_class = '';
		
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-pricing-block-') .'-'.rand(1,9999);
		
		if($settings['slim'] == 'yes') {
			$el_class .= ' slim-block';
		}

		if(empty($settings['description'])) {
			$el_class .= ' no-description ';
		}

		$output .= '<div id="'.$uniqid.'" class="dfd-pricing-block ' . $settings['style'] . ' ' . $el_class . '">';
			$output .= '<div class="block-head">';

			if($settings['feat_mark'] == 'yes') {
				$output .= '<span class="feat-mark '.$settings['feat_mark_style'].'">' . $settings['feat_mark_text'] . '</span>';
			}

			if(!empty($settings['show_icon'] == 'yes')) {
				$output .= '<div class="icon-wrap">' . dfd_elementor_icon_render($settings) . '</div>';
			}

			if(!empty($settings['title'])) {
				$output .= '<' . $settings['title_html_tag'] . ' class="feature-title">' . $settings['title'] . '</' . $settings['title_html_tag'] . '>';
			}

			if(!empty($settings['subtitle'])) {
				$output .= '<' . $settings['subtitle_html_tag'] . ' class="subtitle">' . $settings['subtitle'] . '</' . $settings['subtitle_html_tag'] . '>';
			}

			if($settings['price_sep'] == 'yes') {
				$output .= '<div class="delimiter-wrap"><span class="price-sep"></span></div>';
			}

				$output .= '<div class="price-wrap">';

					if(!empty($settings['currency_symbol'])) {
						$output .= '<span class="currency-symbol">' . $settings['currency_symbol'] . '</span>';
					}

					if(!empty($settings['payment_amount'])) {
						$output .= '<span class="payment-amount">' . $settings['payment_amount'] . '</span>';
					}

					if(!empty($settings['time_interval'])) {
						$output .= '<span class="time-interval"> / ' . $settings['time_interval'] . '</span>';
					}
				$output .= '</div>';

			$output .= '</div>';

			$output .= '<div class="block-desc">';

			if(!empty($settings['description'])) {
				$output .= '<' . $settings['subtitle_html_tag'] . ' class="desc-text subtitle">' . $settings['description'] . '</' . $settings['subtitle_html_tag'] . '>';
			}

			if(isset($settings['values']) && !empty($settings['values'])) {
				$output .= '<ul class="options-list">';

					foreach($settings['values'] as $single_feature) {
						
						$inner_icon = $dot_style = '';
						if($single_feature['feature_style'] == 'icon_only' || $single_feature['feature_style'] == 'text_icon') {
							$inner_icon = dfd_elementor_icon_render(array('icon_type' => 'selector', 'icon' => $single_feature['icon']));
						}
						
						$output .= '<li class="option">';

							if(($single_feature['feature_style'] !== 'text_icon') && ($single_feature['feature_style'] !== 'text_only') && ($single_feature['feature_style'] !== 'icon_only')) {
								if(!empty($single_feature['dot_color'])) {
									$dot_style = ' style="background-color: '.$single_feature['dot_color'].';"';
								}
								$output .= '<span class="price-block-dot ' . $single_feature['feature_style'] . '"'.$dot_style.'></span>';
							} else {
								if(!empty($inner_icon) && $single_feature['feature_style'] !== 'text_only') {
									if(($single_feature['feature_style'] == 'icon_only')) {
										$no_margin_class = 'no-margin';
									}
									
									$output .= '<span class="option-icon ' . $no_margin_class . '">'.$inner_icon.'</span>';
								}
								if(!empty($single_feature['label']) && ($single_feature['feature_style'] !== 'icon_only')) {
									$output .= '<div class="pricing-feature-description price-feature">' . $single_feature['label'] . '</div>';
								}
							}
						$output .= '</li>';
					}
				$output .= '</ul>';
			}
			
			if(!empty($settings['button_link'])) {
				$link_atts .= 'href="' . (!empty($settings['button_link']['url']) ? esc_url($settings['button_link']['url']) : '#') . '"';
				$link_atts .= ' target="' . (!empty($settings['button_link']['is_external']) ? '_blank' : '_self' ) . '"';
				$link_atts .= !empty($settings['button_link']['nofollow']) ? ' rel="nofollow"' : '';
				$link_atts .= !empty($settings['button_link']['custom_attributes']) ? ' ' . esc_attr($settings['button_link']['custom_attributes']) : '';
				$output .= '<a class="pricing-button button" ' . $link_atts . '>' . $settings['button_text'] . '</a>';
			}

			$output .= '</div>';

		$output .= '</div>';

		echo $output;
		
	}

}