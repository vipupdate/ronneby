<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Price_List extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_price_list';
	}

	public function get_title() {
		return esc_html__('DFD Pricing List', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'price_list';
	}
	

	protected function register_controls() {

		$this->start_controls_section(
			'el_price_list',
			[
				'label' => esc_html__('Pricing list', 'dfd')
			]
		);

		$this->add_control(
			'box_width',
			[
				'label' => esc_html__('Price List Size in %', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Image', 'dfd')
			]
		);
		
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Title'
			]
		);

		$repeater->add_control(
			'price',
			[
				'label' => esc_html__('Price', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Price'
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Subtitle'
			]
		);

		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('List content', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_price_list_settings',
			[
				'label' => esc_html__('Pricing list settings', 'dfd')
			]
		);
		
		$this->add_control(
			'delimeter_style',
			[
				'label' => esc_html__('Delimiter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'default' => 'none',
				'selectors' => [
					'{{WRAPPER}} .dfd-price-cover .price-delimeter' => 'border-bottom-style: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'delimeter_width',
			[
				'label' => esc_html__('Delimiter height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-price-cover .price-delimeter' => 'border-bottom-width: {{SCHEME}}px;'
				],
				'condition' => [
					'delimeter_style!' => 'none'
				]
			]
		);
		
		$this->add_control(
			'color_delim',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-price-cover .price-delimeter' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'delimeter_style!' => 'none'
				]
			]
		);
		
		$this->add_control(
			'img_width',
			[
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'img_height',
			[
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'img_radius',
			[
				'label' => esc_html__('Image radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'spacing_content',
			[
				'label' => esc_html__('Spacing between content', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-price-block' => 'margin-top: {{SCHEME}}px;'
				]
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .price-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .price-title.feature-title'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-price-typography',
				'label' => esc_html__('Price typography', 'dfd'),
				'selector' => '{{WRAPPER}} .amount-price.feature-title'
			]
		);

		$this->add_control(
			'price_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Price color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .amount-price.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $uniqid = $link_css = '';
		
		$settings = $this->get_settings_for_display();
		
		$uniqid = uniqid('dfd-price-wrap-').'-'.rand(1,9999);

		if(isset($settings['box_width']) && $settings['box_width'] !== '') {
			if($settings['box_width'] < 0) {
				$settings['box_width'] = 0;
			}
			if($settings['box_width'] > 100) {
				$settings['box_width'] = 100;
			}
			$link_css .= '#'. esc_js($uniqid).'.dfd-price-wrap {width: '.esc_js($settings['box_width']).'%;}';
		}
		
		if(!isset($settings['img_width']) || $settings['img_width'] == '') {
			$img_width = 80;
		} else {
			$img_width = $settings['img_width'];
		}
		if($settings['img_width'] < 0) {
			$img_width = 0;
		}
		if($settings['img_width'] > 100) {
			$img_width = 100;
		}
		$link_css .= '#'. esc_js($uniqid).' .thumb-wrap img {width: '.esc_js($img_width).'px;}';
				
		if(!isset($settings['img_height']) || $settings['img_height'] == '') {
			$img_height = 80;
		} else {
			$img_height = $settings['img_height'];
		}
		if($settings['img_height'] < 0) {
			$img_height = 0;
		}
		if($settings['img_height'] > 100) {
			$img_height = 100;
		}
		$link_css .= '#'. esc_js($uniqid).' .thumb-wrap img {height: '.esc_js($img_height).'px;}';
		
		if(isset($settings['img_radius']) && $settings['img_radius'] !== '') {
			$link_css .= '#'. esc_js($uniqid).' .thumb-wrap img {border-radius: '.esc_js($settings['img_radius']).'px;}';
		}

		$output .= '<div id="'.  esc_attr($uniqid).'" class="dfd-price-wrap">';

			if(isset($settings['list_fields']) && !empty($settings['list_fields'])) {
				foreach ($settings['list_fields'] as $fields) {
					$img_html = $img_src = $img_url = '';

					$output .= '<div class="dfd-price-block">';
						if(isset($fields['image_id']['id']) && !empty($fields['image_id']['id'])) {
							$image_url = wp_get_attachment_image_src($fields['image_id']['id'], 'full');
							$img_src = dfd_aq_resize($image_url[0], $img_width, $img_height, true, true, true);
							if(!$img_src) {
								$img_src = $image_url[0];
							}

							global $dfd_ronneby;
							$thumb_class = '';

							$img_atts = Dfd_Theme_Helpers::get_image_attrs($img_src, $fields['image_id']['id'], $img_width, $img_height, esc_html__('Pricing list', 'dfd'));

							if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
								$thumb_class = 'dfd-img-lazy-load';
								$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $img_width $img_height'%2F%3E";
								$img_html = '<img src="'.$loading_img_src.'" data-src="'.esc_url($img_src).'" width="'.esc_attr($img_width).'" height="'.esc_attr($img_height).'" '.$img_atts.' />';
							} else {
								$img_html = '<img src="'.esc_url($img_src).'" width="'.esc_attr($img_width).'" height="'.esc_attr($img_height).'" '.$img_atts.' />';
							}
							$output .= '<div class="thumb-wrap '.esc_attr($thumb_class).'">'.$img_html.'</div>';
						}
						$output .= '<div class="text-wrap">';
							$output .= '<div class="dfd-price-cover clearfix">';
								if(isset($fields['title']) && !empty($fields['title'])){
									$output .= '<'.esc_attr($settings['title_html_tag']).' class="price-title feature-title"> ' . esc_html($fields['title']) . ' </'.esc_attr($settings['title_html_tag']).'>';
								}
								$output .= '<div class="price-delimeter"></div>';
								if(isset($fields['price']) && !empty($fields['price'])){
									$output .= '<'.esc_attr($settings['title_html_tag']).' class="amount-price amount feature-title"> ' . esc_html($fields['price']) . ' </'.esc_attr($settings['title_html_tag']).'>';
								}
							$output .= '</div>';
							if(isset($fields['subtitle']) && !empty($fields['subtitle'])){
								$output .= '<div class="dfd-price-cover"><div class="subtitle"> ' . wp_kses( $fields['subtitle'], array('br' => array()) ) . ' </div></div>';
							}
						$output .= '</div>';	
					$output .= '</div>';	
				}

			}

			if(!empty($link_css)) {
				$output .= '<script type="text/javascript">'
								. '(function($) {'
									. '$("head").append("<style>'.$link_css.'</style>");'
								. '})(jQuery);'
							. '</script>';
			}

		$output .= '</div>';

		echo $output;
	}

}
