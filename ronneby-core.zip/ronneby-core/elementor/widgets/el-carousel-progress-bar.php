<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Carousel_Progress_Bar extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_carousel_progress_bar';
	}

	public function get_title() {
		return esc_html__('DFD Progress bar carousel', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_carousel';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_carousel_content', [
				'label' => esc_html__('Carousel content', 'dfd')
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'percent',
			[
				'label' => esc_html__('Progress value', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('Progress bars', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'progress_bar_section', [
				'label' => esc_html__('Progress bars styles', 'dfd')
			]
		);
		
		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Simple', 'dfd'),
					'layout-2' => esc_html__('Bordered', 'dfd'),
					'layout-3' => esc_html__('Diagonal', 'dfd'),
					'layout-4' => esc_html__('Tiled', 'dfd')
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'animate_progress',
			[
				'label' => esc_html__('Progress animation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'animate_lines',
			[
				'label' => esc_html__('Slanting lines decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [
					'main_layout' => 'layout-3'
				]
			]
		);
		
		$this->add_control(
			'text_position',
			[
				'label' => esc_html__('Title position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'top' => esc_html__('Top', 'dfd'),
					'bottom' => esc_html__('Bottom', 'dfd')
				],
				'default' => 'top'
			]
		);
		
		$this->add_control(
			'delim_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				],
				'condition' => [
					'main_layout' => 'layout-4'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_progress_line',
			[
				'label' => esc_html__('Progress line', 'dfd'),
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'progress_background_gradient',
				'label' => esc_html__('Background', 'dfd'),
				'types' => ['gradient'],
				'selector' => '{{WRAPPER}} .meter'
			]
		);
		
		$this->add_control(
			'height',
			[
				'label' => esc_html__('Progress line height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_progress_back',
			[
				'label' => esc_html__('Back line', 'dfd'),
			]
		);
		
		$this->add_control(
			'line_border',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3']
				]
			]
		);
		
		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				],
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3']
				]
			]
		);
		
		$this->add_control(
			'bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .progress-bar-line' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .progressbar-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .progressbar-title' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'number_html_tag',
			[
				'label' => esc_html__('Number HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'separator' => 'before',
				'default' => 'div',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-number-typography',
				'label' => esc_html__('Number typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .progressbar-number',
			]
		);
		
		$this->add_control(
			'number_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Number color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .progressbar-number' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		
		
		
		
		
		
		$this->start_controls_section(
			'el_carousel_image', [
				'label' => esc_html__('Carousel settings', 'dfd')
			]
		);

		$this->add_control(
			'slider_type', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'horizontal' => esc_html__('Horizontal', 'dfd'),
					'vertical' => esc_html__('Vertical', 'dfd')
				],
				'default' => 'horizontal'
			]
		);

		$this->add_control(
			'infinite_loop', [
				'label' => esc_html__('Loop', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode', [
				'label' => esc_html__('Center Mode', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode_scale', [
				'label' => esc_html__('Scale center element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'center_mode' => 'yes'
				]
			]
		);

		$this->add_control(
			'draggable', [
				'label' => esc_html__('Draggable Effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'touch_move', [
				'label' => esc_html__('Touch Move', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'adaptive_height', [
				'label' => esc_html__('Adaptive height', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_car_set', [
				'label' => esc_html__('Slideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'slides_to_show', [
				'label' => esc_html__('Slides to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'speed', [
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 300
			]
		);

		$this->add_control(
			'items_offset', [
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_slide_set', [
				'label' => esc_html__('Autoslideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'autoplay', [
				'label' => esc_html__('Autoplay', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'autoplay_speed', [
				'label' => esc_html__('Autoplay Speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5000,
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_resp_set', [
				'label' => esc_html__('Responsive settings', 'dfd')
			]
		);

		$this->add_control(
			'screen_normal_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1024
			]
		);

		$this->add_control(
			'screen_normal_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_tablet_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 800
			]
		);

		$this->add_control(
			'screen_tablet_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_mobile_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 480
			]
		);

		$this->add_control(
			'screen_mobile_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_set', [
				'label' => esc_html__('Navigation settings', 'dfd')
			]
		);

		$this->add_control(
			'arrows', [
				'label' => esc_html__('Navigation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'arrows_position', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'aside_offset' => esc_html__('Aside with offset', 'dfd'),
					'aside' => esc_html__('Aside', 'dfd'),
					'aside2' => esc_html__('Inside', 'dfd'),
					'top_left' => esc_html__('Top left', 'dfd'),
					'top_center' => esc_html__('Top center', 'dfd'),
					'top_right' => esc_html__('Top right', 'dfd'),
					'bottom_left' => esc_html__('Bottom left', 'dfd'),
					'bottom_center' => esc_html__('Bottom center', 'dfd'),
					'bottom_right' => esc_html__('Bottom right', 'dfd')
				],
				'default' => 'aside_offset',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_vertical_offset', [
				'label' => esc_html__('Navigation vertical offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'arrows' => 'yes',
				]
			]
		);

		$this->add_control(
			'arrow_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'default' => esc_html__('Pre-built', 'dfd'),
					'upload' => esc_html__('Upload', 'dfd')
				],
				'default' => 'default',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__('Simple arrows', 'dfd'),
					'style_2' => esc_html__('Arrows', 'dfd'),
					'style_3' => esc_html__('Arrows with rounded background', 'dfd'),
					'style_4' => esc_html__('Arrows with square background', 'dfd'),
					'style_5' => esc_html__('Simple arrows with square background', 'dfd'),
				],
				'default' => 'style_1',
				'condition' => [
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'arrows_bg', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows background', 'dfd'),
				'condition' => [
					'arrows_style' => ['style_3', 'style_4', 'style_5'],
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'left_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Left navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'right_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Right navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'enable_counter', [
				'label' => esc_html__('Slides counter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'counter_style', [
				'label' => esc_html__('Counter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'over_arrows' => esc_html__('Simple arrows', 'dfd'),
					'between_arrows' => esc_html__('Between arrows', 'dfd')
				],
				'default' => 'over_arrows',
				'condition' => [
					'enable_counter' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_always_show', [
				'label' => esc_html__('Always show arrows', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_hover_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows hover color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_dot_set', [
				'label' => esc_html__('Navigation dots settings', 'dfd')
			]
		);

		$this->add_control(
			'dots', [
				'label' => esc_html__('Dots Pagination', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		$this->add_control(
			'dots_style', [
				'label' => esc_html__('Pagination style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfdrounded' => esc_html__('Rounded dot', 'dfd'),
					'dfdfillrounded' => esc_html__('Filled rounded', 'dfd'),
					'dfdemptyrounded' => esc_html__('Transparent rounded', 'dfd'),
					'dfdfillsquare' => esc_html__('Filled square', 'dfd'),
					'dfdroundedold' => esc_html__('Rounded', 'dfd'),
					'dfdsquare' => esc_html__('Square', 'dfd'),
					'dfdemptysquare' => esc_html__('Transparent square', 'dfd'),
					'dfdline' => esc_html__('Line', 'dfd'),
					'dfdlineold' => esc_html__('Line hovered', 'dfd'),
					'dfdadvancesquare' => esc_html__('Advanced square', 'dfd'),
					'dfdemptyroundedold' => esc_html__('Transparent rounded small', 'dfd'),
					'dfdfillsquareold' => esc_html__('Filled square small', 'dfd'),
				],
				'default' => 'dfdrounded',
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dots_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Active dot color', 'dfd'),
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		if (is_rtl()) {
			$this->add_control(
				'rtl', [
					'label' => esc_html__('RTL Mode', 'dfd'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'condition' => [
						'slider_type' => 'horizontal'
					]
				]
			);
		}

		$this->end_controls_section();
	}

	protected function render() {
		$el_class = $css_rules = $setting = $counter_between_html = $cover_class = '';
		$left_arrow_html = $right_arrow_html = $counter_html = $content_bg = '';
		$icon_html = $delimiter_html = $el_testimonial_class = '';

		global $dfd_ronneby;
		
		if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
			$cover_class = 'dfd-img-lazy-load';
		}
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-carousel-');
			
		$setting .= 'arrows: false,';
		$setting .= 'dotsClass: \'dfd-slick-dots\',';
		$setting .= 'slidesToScroll: 1,';

		if($settings['autoplay'] == 'yes') {
			$setting .= 'autoplay: true,';
			if($settings['autoplay_speed'] != '') {
				$setting .= 'autoplaySpeed: '.esc_js($settings['autoplay_speed']).',';
			}
		}
		
		$el_class .= ' dfd-carousel-' . $settings['slider_type'];

		if(isset($settings['arrows_position'])) {
			$el_class .= ' dfd-arrows_'.$settings['arrows_position'];
		}
		
		if($settings['arrows_always_show'] == 'yes') {
			$el_class .= ' dfd-keep-arrows';
		}

		if(isset($settings['dots_style'])) {
			$el_class .= ' ' . $settings['dots_style'];
		}
		
		if($settings['arrow_style'] == 'default') {
			$el_class .= ' dfd-arrows-' . $settings['arrows_style'] . ' dfd-arrows-enabled';
			$left_arrow_html .= '<i class="dfd-added-font-icon-left-open2"></i>';
			$right_arrow_html .= '<i class="dfd-added-font-icon-right-open2"></i>';
		} elseif($settings['arrow_style'] == 'upload' && isset($settings['left_arrow']) && !empty($settings['left_arrow']) && isset($settings['right_arrow']) && !empty($settings['right_arrow'])) {
			$left_arrow_src = wp_get_attachment_image_src($settings['left_arrow']['id'], 'full');
			$right_arrow_src = wp_get_attachment_image_src($settings['right_arrow']['id'], 'full');

			if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 50 50'%2F%3E";
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			} else {
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			}

			$el_class .= ' dfd-arrows-enabled dfd-arrows-uploaded';
		}
			
		if($settings['slider_type'] == 'vertical') {
			$setting .= 'vertical: true,';
		}

		if($settings['dots'] == 'yes' && $settings['arrows_position'] != 'bottom_center') {
			$setting .= 'dots: true,';
			$setting .=	'customPaging: function(slider, i) {
								return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
							},';
			$el_class .= ' dfd-dots-enabled';
		} else {
			$setting .= 'dots: false,';
		}

		if($settings['infinite_loop'] == 'yes') {
			$setting .= 'infinite: true,';
		} else {
			$setting .= 'infinite: false,';
		}

		if($settings['center_mode'] == 'yes') {
			$setting .= 'centerMode: true,';
			if($settings['center_mode_scale'] == 'yes') {
				$el_class .= ' dfd-center-mode-scale';
			}
		}
		
		if($settings['slides_to_show'] != '') {
			$setting .= 'slidesToShow: '.esc_js($settings['slides_to_show']).',';
		}

		if($settings['speed'] != '') {
			$setting .= 'speed: '.esc_js($settings['speed']).',';
		}

		if($settings['draggable'] == 'yes') {
			$setting .= 'swipe: true,';
			$setting .= 'draggable: true,';
		} else {
			$setting .= 'swipe: false,';
			$setting .= 'draggable: false,';

			if($settings['touch_move'] == 'yes') {
				$setting .= 'touchMove: true,';
			}
		}

		if($settings['adaptive_height'] == 'yes') {
			$setting .= 'adaptiveHeight: true,';
		}

		if(isset($settings['rtl']) && $settings['rtl'] == 'yes') {
			$setting .= 'rtl: true,';
		}
			
		if($settings['screen_normal_resolution'] == '') {
			$settings['screen_normal_resolution'] = 1024;
		}

		if($settings['screen_tablet_resolution'] == '') {
			$settings['screen_tablet_resolution'] = 800;
		}

		if($settings['screen_mobile_resolution'] == '') {
			$settings['screen_mobile_resolution'] = 480;
		}

		if($settings['screen_normal_slides'] != '' || $settings['screen_tablet_slides'] != '' || $settings['screen_mobile_slides'] != '') {
			$setting .= 'responsive: [';
			if($settings['screen_normal_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_normal_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_normal_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_tablet_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_tablet_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_tablet_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_mobile_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_mobile_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_mobile_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			$setting .= ']';
		}

		if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {
			$counter_html .= '<span class="count"></span>';
		} else if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) {
			$el_class .= ' counter-between-arrows';
			$counter_between_html .= '<span class="dfd-slide-between-counter"><span class="current-slide"></span>/<span class="number-slides"></span></span>';
		}

		if($settings['arrows_bg'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_3 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_4 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control {background: '.esc_js($settings['arrows_bg']).'}';
		}
		
		if($settings['dots_color'] != '') {
			$css_rules .=	'#'.esc_js($uniqid).' .dfdrounded ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdsquare ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:after, #'.esc_js($uniqid).' .dfdroundedold ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).'}'
							.'#'.esc_js($uniqid).' .dfdfillrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquare ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdemptysquare ul.dfd-slick-dots li.slick-active span {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdline ul.dfd-slick-dots li.slick-active span:before {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span:before {border-bottom-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyroundedold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).';}';
		}
		
		if($settings['items_offset'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' > .dfd-carousel-module-wrapper > .dfd-carousel > .slick-list > .slick-track .dfd-progressbar {padding: '.esc_js($settings['items_offset']/2).'px;}'
						. '#'.esc_js($uniqid).' {margin: -'.esc_js($settings['items_offset']/2).'px;}';
		}
		
		if(isset($settings['arrows_vertical_offset']) && $settings['arrows_vertical_offset'] != '') {
			if($settings['arrows_position'] == 'aside_offset' || $settings['arrows_position'] == 'aside' || $settings['arrows_position'] == 'aside2') {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control {margin-top: '.esc_js($settings['arrows_vertical_offset']).'px;}';
			} else {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control, #'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slide-between-counter {'
								. '-webkit-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-moz-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-o-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. 'transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
							. '}';
			}
		}
		
		if(isset($settings['arrows_color']) && !empty($settings['arrows_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control i, #'.esc_js($uniqid).' .dfd-slider-control .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after {color: '.esc_js($settings['arrows_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:after {background: '.esc_js($settings['arrows_color']).';}';
		}
		if(isset($settings['arrows_hover_color']) && !empty($settings['arrows_hover_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control:hover i, #'.esc_js($uniqid).' .dfd-slider-control:hover .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after {color: '.esc_js($settings['arrows_hover_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:hover:after {background: '.esc_js($settings['arrows_hover_color']).';}';
		}
		
		/*Progress bar settings*/
		$progress_bar_el_class = $line_style = '';
		if ( $settings['bg_color'] || (  $settings['line_border'] !== '0' ) ||  $settings['line_color'] ||  $settings['delim_color'] || (  $settings['height'] !== '8' )) {
			$line_style .= 'style="';
			if ( $settings['bg_color']) {
				$line_style .= 'background:' .  $settings['bg_color'] . '; ';
			}

			$line_style .= 'height:' . ( intval( (int)$settings['height']) + intval( (int)$settings['line_border'] * 2) ) . 'px;';

			if ('layout-4' ===  $settings['main_layout'] &&  $settings['delim_color']) {
				$line_style .= ' color: ' . esc_attr( $settings['delim_color']) . '; ';
			}
			$line_style .= '"';
		}

		if ($settings['animate_progress'] !== 'yes') {
			$progress_bar_el_class .= ' no-animation ';
		}
		if ('yes' ===  $settings['animate_lines']) {
			$progress_bar_el_class .= ' move-lines ';
		}

		$css_rules .= '#' . $uniqid . '.dfd-progressbar.layout-2 .progress-bar-line:before, #' . $uniqid . '.dfd-progressbar.layout-3 .progress-bar-line:before { border-width: ' . esc_attr( $settings['line_border']) . 'px; border-color: ' . esc_attr( $settings['line_color']) . '}';
		
		/*End Progress bar settings*/
						
		echo '<div id="'.esc_attr($uniqid).'" class="dfd-carousel-wrapper">';
			echo '<div class="dfd-carousel-module-wrapper '.esc_attr($el_class).'" >';
				echo '<div class="dfd-carousel">';
					/*Progress bar HTML*/
					foreach ($settings['list_fields'] as $fields) {
						$output = $title_html = $progress_anim_data = $content_html = '';
						if (!empty($fields['title'])) {
							$title_html = '<div class="title-wrap"><' . $settings['title_html_tag'] . ' class="progressbar-title">' . esc_html($fields['title']) . '</' . $settings['title_html_tag'] . '><' . $settings['number_html_tag'] . ' class="progressbar-number">' . $fields['percent'] . '<span>%</span></' . $settings['number_html_tag'] . '></div>';
						} else {
							$title_html = '<div class="title-wrap"><' . $settings['number_html_tag'] . ' class="progressbar-number">' . $fields['percent'] . '<span>%</span></' . $settings['number_html_tag'] . '></div>';
						}

						if ('0' !==  $fields['percent']) {
							if ('layout-4' ===  $settings['main_layout']) {
								$fields['percent'] = ceil($fields['percent'] / 10) * 10;
							}
							$progress_anim_data = ' data-percentage-value="' . esc_attr(intval( $fields['percent'])) . '"';
						}
		
						$content_html .= '<div class="progress-bar-line" ' . $line_style . '>';
						if ('layout-4' === $settings['main_layout']) {
							for ($i = 1; $i <= 10; $i++) {
								$content_html .= '<span class="vertical-line"></span>';
							}
						}
						$content_html .= '<div  class="meter" ' . $progress_anim_data . '>';
						$content_html .= '</div></div>';

						$output .= '<div class="dfd-progressbar ' . $settings['main_layout'] . ' text-' . $settings['text_position'] . ' ' . esc_attr($progress_bar_el_class) . '">';

						if ('top' === $settings['text_position']) {
							$output .= $title_html;
							$output .= $content_html;
						} else {
							$output .= $content_html;
							$output .= $title_html;
						}

						$output .= '</div>';
						
						echo $output;
					}
					/*END Progress bar HTML*/
				echo '</div>';
				if($settings['arrows'] == 'yes') {
					echo '<a href="#" class="dfd-slider-control prev '.esc_attr($cover_class).'" title="'.esc_attr__('Previous slide','dfd').'">'.$counter_html.$left_arrow_html.'</a>';
					echo $counter_between_html;
					echo '<a href="#" class="dfd-slider-control next '.esc_attr($cover_class).'" title="'.esc_attr__('Next slide','dfd').'">'.$counter_html.$right_arrow_html.'</a>';
				}
			echo '</div>';
			?>
			<script type="text/javascript">
				(function($) {
					"use strict";
					var $carousel = $('#<?php echo esc_js($uniqid); ?>').find('.dfd-carousel');
					$(document).ready(function() {
						var $initialized = ($('body').hasClass('page-template-tmp-side-by-side')) ? $carousel.not('.slick-initialized') : $carousel;
						<?php if($settings['arrows'] == 'yes') {
							if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {  ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									var prev_slide_index, next_slide_index, current;
									var $prev_counter = $carousel.siblings('.dfd-slider-control.prev').find('.count');
									var $next_counter = $carousel.siblings('.dfd-slider-control.next').find('.count');
									total_slides = slick.slideCount;
									current = (currentSlide ? currentSlide : 0) + 1;
									prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
									next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
									$prev_counter.text(prev_slide_index + '/' + total_slides);
									$next_counter.text(next_slide_index + '/'+ total_slides);
								});
							<?php } elseif ($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) { ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									total_slides = slick.slideCount;
									var $current_slide = $carousel.siblings('.dfd-slide-between-counter').find('.current-slide'),
										$number_slides = $carousel.siblings('.dfd-slide-between-counter').find('.number-slides'),
										current;

										current = (currentSlide ? currentSlide : 0) + 1;

										$current_slide.text(current);
										$number_slides.text(total_slides);
								});
							<?php }
						} ?>
						$carousel.siblings('.dfd-slider-control.prev').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickPrev');
						});
						$carousel.siblings('.dfd-slider-control.next').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickNext');
						});
						$initialized.slick({<?php echo $setting; ?>});
						<?php if($css_rules != '') {
							echo '$("head").append("<style>' . $css_rules . '</style>")';
						}
						?>
					});
				})(jQuery);
			</script>
			<?php
		echo '</div>';
	}
}

