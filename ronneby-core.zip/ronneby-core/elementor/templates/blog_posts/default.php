<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
include(DFD_RONNEBY_PLUGIN_PATH.'elementor/templates/blog_posts/standard.php');