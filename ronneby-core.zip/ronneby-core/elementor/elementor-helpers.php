<?php

if (!defined('ABSPATH')) {
	exit;
}

if ( ! function_exists( 'dfd_elementor_icon_render' ) ) {
	/**
	 * Icon generator for Frontend
	 */
	function dfd_elementor_icon_render( $settings = array() ) {
		$output = $icon_hover = $icon_style = $img_style = '';

		if($settings['icon_type'] === 'custom') {

			$image_url = wp_get_attachment_image_src($settings['icon_image_id']['id'], 'full' );
			if(empty($image_url)) {
				return;
			}
			
			if(!empty($settings['icon_size'])){
				$image_src = dfd_aq_resize( $image_url[0], $settings['icon_size'] * 2, $settings['icon_size'] * 2, true, true, true );
				if(!$image_src) $image_src = $image_url[0];
			} else {
				$image_src = $image_url[0];
			}

			$alt = get_post_meta($settings['icon_image_id']['id'], '_wp_attachment_image_alt', true);

			if (!isset($alt) || empty($alt)) {
				$alt = esc_attr__('Image icon', 'dfd');
			}
			
			if(!empty($settings['icon_size']) || !empty($settings['opacity']['size'])) {
				$img_style .= 'style="';
				if(isset($settings['icon_size']) && !empty($settings['icon_size'])) {
					$img_style .= 'width: '.esc_attr($settings['icon_size']).'px;';
				}
				if(!empty($settings['opacity']['size'])) {
					$img_style .= 'opacity: '.esc_attr($settings['opacity']['size']) / 100 .';';
				}
				$img_style .= '"';
			}
			
			$output .= '<img src="' . esc_url($image_src) . '" alt="'.$alt.'" '.$img_style.' />';
			
		} elseif ($settings['icon_type'] === 'selector') {
			if(!empty($settings['icon_size']) || !empty($settings['icon_color']) || !empty($settings['opacity']['size']) ) {
				$icon_style .= 'style="';

				if(!empty( $settings['icon_size'])) {
					$icon_style .= 'font-size:' . $settings['icon_size'] . 'px; ';
				}

				if(!empty($settings['icon_color'])) {
					$icon_style .= 'color:' . $settings['icon_color'].'; ';
				}

				if(!empty($settings['opacity']['size'])) {
					$icon_style .= 'opacity:' . $settings['opacity']['size'] / 100 .';';
				}

				$icon_style .= '"';
			}

			if(isset($settings['icon_hover'])) {
				$icon_hover = 'data-hover="'.$settings['icon_hover'].'"';
			}
			
			$output .= '<i class="featured-icon '.$settings['icon']['value'].'" '.$icon_style.' '.$icon_hover.'></i>';
		} elseif ($settings['icon_type'] === 'text') {
			$output .= '<span class="icon-text dfd-text-icon-render">'.  esc_html($settings['icon_text']).'</span>';
		}

		return $output;
	}
}