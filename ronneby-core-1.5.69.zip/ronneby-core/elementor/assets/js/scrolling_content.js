(function($) {
	"use strict";
	$(window).load(function() {
		$('.dfd-scrolling-content-outer').each(function() {
			var width, height;
			var $wrap = $(this);
			var $carousel = $wrap.find('> .elementor-container > .elementor-column > .elementor-widget-wrap');
			$carousel.parents('.elementor-column').addClass('dfd-full-screen-scroll-content-wrapper');
			if (!Modernizr.touch) {
				$carousel.prepend('<div />');
				$carousel.append('<div />');
				$carousel.addClass('dfd-full-screen-scroll-content-second');
				$carousel.find('> * ').addClass('dfd-scrolling-content-slide');
				$carousel.slick({
					infinite: false,
					slidesToShow: 1,
					slidesToScroll: 1,
					arrows: false,
					dots: $wrap.data('dots'),
					draggable: false,
					autoplay: false,
					speed: 700,
					vertical: true
				});

				$carousel.on("afterChange", function(){
					$(window).trigger("resize");
				});

				$carousel.find(".slick-slide.dfd-scrolling-content-slide").wrapInner('<div class="dfd-vertical-aligned"></div>');

				var recalcValues = function() {
					var heightOffset = 0;
					var widthOffset = 0;

					if($(".dfd-custom-padding-html").length > 0) {
						var bodyOffset = $(".dfd-custom-padding-html").css("margin").replace("px", "");
						heightOffset += bodyOffset * 2;
						widthOffset = bodyOffset * 2;
					}
					width = $(window).width() - widthOffset;
					height = $(window).height() - heightOffset;
					$carousel.find("> .slick-list").css({
						height : height,
						maxHeight : height
					}).find(".slick-slide.dfd-scrolling-content-slide").css({
						maxWidth : width,
						height : height,
						maxHeight : height
					});
				};

				recalcValues();

				var mousewheelevt = (/Firefox/i.test(navigator.userAgent)) ? "DOMMouseScroll" : "mousewheel";
				$wrap.bind(mousewheelevt, function(e){
					var ev = window.event || e;
					ev = ev.originalEvent ? ev.originalEvent : ev;
					var delta = ev.detail ? ev.detail*(-40) : ev.wheelDelta;
					if(delta > 0) {
						if($carousel.find(".slick-slide.slick-active").prev(".slick-slide").length > 0) {
							ev.preventDefault();
							$(window).scrollTo($carousel.parents(".dfd-full-screen-scroll-content-wrapper"), {duration: "fast"});
							$carousel.eq(0).slick("slickPrev");
						}
					} else {
						if($carousel.find(".slick-slide.slick-active").next(".slick-slide").length > 0) {
							ev.preventDefault();
							$(window).scrollTo($carousel.parents(".dfd-full-screen-scroll-content-wrapper"), {duration: "fast"});
							$carousel.eq(0).slick("slickNext");
						}
					}
				});

				$(window).on("load resize", recalcValues);
			}
		});
	});
})(jQuery);