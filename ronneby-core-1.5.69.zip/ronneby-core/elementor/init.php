<?php

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('Dfd_Ronneby_Elementor')) {

	class Dfd_Ronneby_Elementor {

		public function __construct() {
			add_action('elementor/elements/categories_registered', [$this, 'dfd_set_categories']);
			add_filter('elementor/icons_manager/additional_tabs', [$this, 'set_icon_pack']);
			add_action('elementor/widgets/widgets_registered', [$this, 'dfd_set_widgets']);
			add_action('elementor/editor/before_enqueue_styles', [$this, 'dfd_elementor_register_script_admin']);
//			add_action('admin_enqueue_scripts', [$this, 'dfd_elementor_register_script_admin']);
			add_action('elementor/frontend/after_enqueue_styles', [$this, 'dfd_elementor_styles']);
			add_action('elementor/frontend/after_enqueue_scripts', [$this, 'dfd_elementor_scripts']);
			add_action('elementor/frontend/before_enqueue_scripts', [$this, 'dfd_enqueue_elementor_scripts']);
			add_action('elementor/controls/controls_registered', [$this, 'add_custom_font'], 10, 1);
			add_action('elementor/preview/enqueue_scripts', [$this, 'dfd_redactor_scripts']);
		}

		public function dfd_set_categories($elements_manager) {
			$elements_manager->add_category(
				'ronneby-category',
				[
					'title' => __('Ronneby', 'dfd'),
//					'icon' => '',
				]
			);
		}

		public function set_icon_pack() {
			global $dfd_ronneby;

			$dfd_icons = array(
				'icon-celsius', 'icon-clear_day', 'icon-clear_night', 'icon-cloud_thunder', 'icon-cloud_wind', 'icon-cloudy', 'icon-cloudy_rain', 'icon-compass_east', 'icon-compass_east_south', 'icon-compass_north', 'icon-compass_north_east', 'icon-compass_south', 'icon-compass_south_west', 'icon-compass_west', 'icon-compass_west_north', 'icon-fahrenheit', 'icon-hail', 'icon-hail_snow', 'icon-hail_warning', 'icon-heavy_rain', 'icon-heavy_rain_day', 'icon-heavy_rain_night', 'icon-heavy_rain_snow', 'icon-heavy_snow', 'icon-humidity', 'icon-light_rain', 'icon-light_rain_day', 'icon-light_rain_night', 'icon-light_snow', 'icon-mist', 'icon-moon_cloud', 'icon-moon_rain', 'icon-rain_thunder', 'icon-rain_warning', 'icon-rainbow', 'icon-sleet', 'icon-small_humidity', 'icon-small_mist', 'icon-snow', 'icon-sun_cloud', 'icon-sun_rain', 'icon-sunrise_1', 'icon-sunrise_2', 'icon-sunset_1', 'icon-sunset_2', 'icon-thermometer_0', 'icon-thermometer_25', 'icon-thermometer_50', 'icon-thermometer_100', 'icon-thunder', 'icon-thunder_warning', 'icon-wind', 'icon-wind_hail', 'icon-wind_rain', 'icon-axe', 'icon-bomb_1', 'icon-bomb_2', 'icon-brass_knuckle', 'icon-bullet', 'icon-catapult', 'icon-flail', 'icon-flashlight', 'icon-gas_mask', 'icon-grenade', 'icon-gun_1', 'icon-gun_2', 'icon-hammer', 'icon-knife_1', 'icon-knife_2', 'icon-mace', 'icon-molotov_cocktail', 'icon-noode', 'icon-nuclear_explosion', 'icon-nunchucks', 'icon-raygun', 'icon-razor_blade', 'icon-sai', 'icon-shuriken_1', 'icon-shuriken_2', 'icon-slingshot', 'icon-swiss_army_knife', 'icon-tank', 'icon-target', 'icon-tnt', 'icon-builder', 'icon-businessman', 'icon-chat', 'icon-contact', 'icon-diver', 'icon-doctor', 'icon-gardener', 'icon-group_1', 'icon-group_2', 'icon-judge', 'icon-mobile', 'icon-player', 'icon-policeman', 'icon-referee', 'icon-student', 'icon-transfer_1', 'icon-transfer_2', 'icon-user', 'icon-user_2', 'icon-user_3', 'icon-user_block', 'icon-user_check', 'icon-user_close', 'icon-user_downgrade', 'icon-user_like', 'icon-user_list', 'icon-user_location', 'icon-user_lock', 'icon-user_mail', 'icon-user_man', 'icon-user_minus', 'icon-user_money', 'icon-user_plus', 'icon-user_question', 'icon-user_search', 'icon-user_setting', 'icon-user_star', 'icon-user_upgrade', 'icon-user_woman', 'icon-users', 'icon-acropolis', 'icon-backpack', 'icon-baggage', 'icon-beach', 'icon-big_ben', 'icon-brandenburg_gate', 'icon-bush_al_arab', 'icon-Capitol', 'icon-castle_1', 'icon-castle_2', 'icon-castle_3', 'icon-christ_the_redeemer', 'icon-compass_1', 'icon-compass_2', 'icon-door_tag_1', 'icon-door_tag_2', 'icon-Eiffel_tower', 'icon-ferris_wheel', 'icon-grill', 'icon-hagia_sophia', 'icon-hotel', 'icon-jellyfish', 'icon-life_jacket', 'icon-lighthouse', 'icon-lounge_chair', 'icon-luggage_cart', 'icon-mesoamerican_pyramids', 'icon-mountains', 'icon-palm', 'icon-passport', 'icon-petronas_towers', 'icon-picnic_table', 'icon-pyramids', 'icon-reception-bell', 'icon-scuba_1', 'icon-scuba_2', 'icon-sheep_wheel', 'icon-shinto_shrine', 'icon-snorkel', 'icon-sphinx', 'icon-st_Basils_cathedral', 'icon-surf', 'icon-swimfin', 'icon-taj_mahal', 'icon-tent', 'icon-tipi', 'icon-towel', 'icon-tower_bridge', 'icon-trailer', 'icon-windsurf', 'icon-battery_car', 'icon-bicycle', 'icon-bicycle_retro', 'icon-bus_1', 'icon-bus_2', 'icon-cableway', 'icon-car_1', 'icon-car_2', 'icon-chassis', 'icon-cone', 'icon-helicopter', 'icon-hot-air', 'icon-light', 'icon-lorry', 'icon-pickup', 'icon-plane_1', 'icon-plane_2', 'icon-plane_landing', 'icon-plane_take-off', 'icon-road', 'icon-rocket', 'icon-sailboat', 'icon-satellite', 'icon-scooter_1', 'icon-scooter_2', 'icon-shift', 'icon-ship_1', 'icon-ship_2', 'icon-speedometer', 'icon-station_electric', 'icon-station_oil', 'icon-steering_wheel', 'icon-submarine', 'icon-train_1', 'icon-train_2', 'icon-truck_1', 'icon-truck_2', 'icon-trum_1', 'icon-trum_2', 'icon-unicycle', 'icon-alarm', 'icon-alarm_clock', 'icon-alarm_off', 'icon-alarm_snooze', 'icon-calendar', 'icon-calendar_date', 'icon-calendar_month', 'icon-clock_1', 'icon-clock_2', 'icon-clock_3', 'icon-cuckoo_clock', 'icon-hour_glass_1', 'icon-hour_glass_2', 'icon-mobile_clock', 'icon-watch_1', /* 'icon-watch_1_1 path1', 'icon-watch_1_1 path2', 'icon-watch_1_1 path3', 'icon-watch_1_1 path4', 'icon-watch_1_1 path5', 'icon-watch_1_1 path6', 'icon-watch_1_1 path7', 'icon-watch_1_1 path8', 'icon-watch_1_1 path9', 'icon-watch_1_4 path1', 'icon-watch_1_4 path2', 'icon-watch_1_4 path3', 'icon-watch_1_4 path4', 'icon-watch_1_4 path5', 'icon-watch_1_4 path6', 'icon-watch_1_4 path7', */ 'icon-watch_2', /* 'icon-watch_2_4 path1', 'icon-watch_2_4 path2', 'icon-watch_2_4 path3', 'icon-watch_2_4 path4', 'icon-watch_2_4 path5', */ 'icon-watch_3_4', 'icon-align_center', 'icon-align_left', 'icon-align_right', 'icon-all_caps', 'icon-baseline_shift', 'icon-columns_2', 'icon-columns_3', 'icon-decrease_indent', 'icon-grid_4', 'icon-grid_9', 'icon-increase_indent', 'icon-justify', 'icon-leading', 'icon-left_indent', 'icon-list_bulleted', 'icon-list_check', 'icon-list_numbered', 'icon-pilcrow', 'icon-right_indent', 'icon-small_caps', 'icon-strikethrough', 'icon-subscript', 'icon-superscript', 'icon-underline', 'icon-vertical_scale', 'icon-archery', 'icon-arena', 'icon-barbell', 'icon-barbell_2', 'icon-baseball', 'icon-basketball', 'icon-basketball_court', 'icon-basketball_hoop', 'icon-billiards', 'icon-billiards_ball', 'icon-bow_and_arrow', 'icon-bowling_ball', 'icon-bowling_pin', 'icon-cards_clubs', 'icon-cards_diamonds', 'icon-cards_hearts', 'icon-cards_spades', 'icon-champion', 'icon-champion_1_place', 'icon-champion_star', 'icon-chess_bishop', 'icon-chess_king', 'icon-chess_knight', 'icon-chess_pawn', 'icon-chess_queen', 'icon-chess_rook', 'icon-cleat', 'icon-cricket', 'icon-cup', 'icon-cup_1_place', 'icon-cup_star', 'icon-curling_stone', 'icon-dart', 'icon-fencing', 'icon-field_goal', 'icon-finish', 'icon-goal', 'icon-golf', 'icon-golf_bag', 'icon-golfing', 'icon-hockey', 'icon-ice_skate', 'icon-kayak', 'icon-medal', 'icon-medal_1_place', 'icon-medal_2', 'icon-medal_star', 'icon-paddles', 'icon-ping_pong', 'icon-player2', 'icon-podium', 'icon-pogo-stick', 'icon-punch_bag', 'icon-referee2', 'icon-ribbon', 'icon-ribbon_1_place', 'icon-ribbon_star', 'icon-rollerblade', 'icon-rugby_ball', 'icon-sailboat2', 'icon-scoreboard', 'icon-shuttlecocks', 'icon-skateboard', 'icon-skiing', 'icon-skipping', 'icon-soccer_ball', 'icon-soccer_field', 'icon-star', 'icon-start', 'icon-stopwatch_1', 'icon-stopwatch_2', 'icon-target2', 'icon-tennis_ball_1', 'icon-tennis_ball_2', 'icon-tennis_court', 'icon-tennis_raket', 'icon-time_clock', 'icon-water_bottle', 'icon-weight', 'icon-whistle', 'icon-hours', 'icon-airplane', 'icon-ATM_card', 'icon-ATM_money', 'icon-bag', 'icon-bank', 'icon-bank_card', 'icon-bank_card_security', 'icon-banknote', 'icon-banknotes', 'icon-bar_graph_1', 'icon-bar_graph_2', 'icon-bar_graph_drop', 'icon-bar_graph_growth', 'icon-bar_graph_horizontal', 'icon-bar_graph_vertical', 'icon-barcode', 'icon-barcode_search', 'icon-basket_1', 'icon-basket_2', 'icon-basket_3', 'icon-basket_4', 'icon-basket_5', 'icon-basket_6', 'icon-basket_full', 'icon-box_1', 'icon-box_2', 'icon-box_3', 'icon-box_isometric', 'icon-box_search', 'icon-briefcase', 'icon-buy', 'icon-calculator', 'icon-candlestick_chart', 'icon-car_24', 'icon-car_express', 'icon-case', 'icon-cash_register', 'icon-certificate', 'icon-check', 'icon-clipboard', 'icon-close', 'icon-coins', 'icon-coins_collect', 'icon-comb', 'icon-cut', 'icon-delivery_1', 'icon-delivery_2', 'icon-dollar', 'icon-dress', 'icon-euro', 'icon-eyeware', 'icon-gift_wrap', 'icon-graph', 'icon-graph_growth', 'icon-hanger', 'icon-hanger_clothing', 'icon-headphones', 'icon-heart', 'icon-high_heels', 'icon-insert_coin', 'icon-lipstick', 'icon-mascara', 'icon-moneybag', 'icon-moneybag_dollar', 'icon-moneybag_euro', 'icon-new', 'icon-open', 'icon-pants', 'icon-paper', 'icon-parfume', 'icon-pie_chart_1', 'icon-pie_chart_2', 'icon-pie_chart_3', 'icon-piggy_bank', 'icon-piggy_bank_add', 'icon-piggy_bank_coin', 'icon-piggy_bank_input', 'icon-piggy_bank_output', 'icon-piggy_bank_remove', 'icon-sale_1', 'icon-sale_2', 'icon-sale_3', 'icon-scales', 'icon-ship', 'icon-shoes', 'icon-shop', 'icon-shopping_bag_1', 'icon-shopping_bag_2', 'icon-star2', 'icon-storage_box', 'icon-strongbox', 'icon-suit', 'icon-tag', 'icon-trash', 'icon-trolley_1', 'icon-trolley_2', 'icon-trolley_3', 'icon-trolley_add', 'icon-trolley_check', 'icon-trolley_close', 'icon-trolley_full', 'icon-trolley_input', 'icon-trolley_like', 'icon-trolley_output', 'icon-trolley_remove', 'icon-trolley_settings', 'icon-t-shirt', 'icon-underware', 'icon-wallet_1', 'icon-wallet_2', 'icon-warehouse', 'icon-cloud', 'icon-cloud_block', 'icon-cloud_check', 'icon-cloud_close', 'icon-cloud_download', 'icon-cloud_edit', 'icon-cloud_lock', 'icon-cloud_minus', 'icon-cloud_plus', 'icon-cloud_refresh', 'icon-cloud_reload', 'icon-cloud_settings', 'icon-cloud_upload', 'icon-database', 'icon-database_block', 'icon-database_check', 'icon-database_clock', 'icon-database_close', 'icon-database_doengrade', 'icon-database_edit', 'icon-database_electric', 'icon-database_error', 'icon-database_lock', 'icon-database_minus', 'icon-database_plus', 'icon-database_repair', 'icon-database_search', 'icon-database_settings', 'icon-database_upgrade', 'icon-server_1', 'icon-server_2', 'icon-server_block', 'icon-server_computer', 'icon-server_downgrade', 'icon-server_lock', 'icon-server_repair', 'icon-server_search', 'icon-server_settings', 'icon-server_upgrade', 'icon-servers', 'icon-alien', 'icon-anemometer', 'icon-bacterium', 'icon-biohazard', 'icon-chemical_weapon', 'icon-deuterium', 'icon-evolution', 'icon-hydrogen', 'icon-molecule', 'icon-mouse', 'icon-observatory_1', 'icon-observatory_2', 'icon-Petri_dish', 'icon-planet', 'icon-quadcopter', 'icon-robot', 'icon-skeleton', 'icon-telescope', 'icon-ufo', 'icon-water_molecule', 'icon-area_1', 'icon-area_2', 'icon-armchair', 'icon-axe2', 'icon-bank2', 'icon-bath', 'icon-bed', 'icon-brush', 'icon-building_1', 'icon-building_2', 'icon-building_office', 'icon-bulb', 'icon-cabinet', 'icon-chair', 'icon-church', 'icon-crane', 'icon-curtains', 'icon-director_chair', 'icon-door', 'icon-downstairs', 'icon-factory', 'icon-fence', 'icon-floor_plan', 'icon-fridge', 'icon-hammer2', 'icon-hanger_floor', 'icon-hard_hat', 'icon-height', 'icon-house_1', 'icon-house_2', 'icon-house_lock', 'icon-house_love', 'icon-house_plan', 'icon-house_sale', 'icon-house_search', 'icon-house_sell', 'icon-house_window', 'icon-lamp_1', 'icon-lamp_2', 'icon-mail_box', 'icon-mirror', 'icon-moving', 'icon-office_table', 'icon-paint_roller', 'icon-rent', 'icon-sale', 'icon-saw', 'icon-screwdriver', 'icon-shop2', 'icon-shovel', 'icon-sofa', 'icon-sold', 'icon-swiming_pool', 'icon-table', 'icon-table_chair', 'icon-tape_line', 'icon-toilet', 'icon-toilet_paper', 'icon-tree', 'icon-trowel', 'icon-TV', 'icon-upstairs', 'icon-warehouse2', 'icon-washer', 'icon-clipboard2', 'icon-clipboard_block', 'icon-clipboard_check', 'icon-clipboard_close', 'icon-clipboard_favorite', 'icon-clipboard_minus', 'icon-clipboard_money', 'icon-clipboard_plus', 'icon-clipboard_question', 'icon-clipboard_settings', 'icon-note', 'icon-note_block', 'icon-note_check', 'icon-note_close', 'icon-note_favorite', 'icon-note_minus', 'icon-note_money', 'icon-note_plus', 'icon-note_question', 'icon-note_settings', 'icon-ambulance', 'icon-atom', 'icon-band_aid_1', 'icon-band_aid_2', 'icon-blister_pack', 'icon-blood_minus', 'icon-blood_plus', 'icon-blood_pressure_meter', 'icon-book_med', 'icon-bottle_1', 'icon-bottle_2', 'icon-cardiograph', 'icon-case_med', 'icon-chemistry', 'icon-clipboard3', 'icon-clipboard_pulse', 'icon-cross', 'icon-crutch', 'icon-DNA', 'icon-doctor2', 'icon-dropper', 'icon-eye', 'icon-female', 'icon-flask', 'icon-glasses', 'icon-heart_pulse', 'icon-hospital_1', 'icon-hospital_2', 'icon-hospital_3', 'icon-hospital_bed', 'icon-IV_bag_1', 'icon-IV_bag_2', 'icon-male', 'icon-med_monitor', 'icon-microscope', 'icon-nurse', 'icon-pill', 'icon-round_flask', 'icon-scales2', 'icon-stethoscope', 'icon-stretcher', 'icon-syringe_1', 'icon-syringe_2', 'icon-tablet', 'icon-test_tube', 'icon-thermometer', 'icon-tooth', 'icon-toothbrush', 'icon-wheelchair_1', 'icon-wheelchair_2', 'icon-aperture', 'icon-cassette', 'icon-clapperboard', 'icon-dj_1', 'icon-dj_2', 'icon-drum', 'icon-eject', 'icon-eject2', 'icon-equalizer', 'icon-film', 'icon-film_strip', 'icon-first', 'icon-first2', 'icon-gramophone', 'icon-guitar', 'icon-headphones2', 'icon-ipod_1', 'icon-ipod_2', 'icon-last', 'icon-last2', 'icon-metronome', 'icon-microphone_1', 'icon-microphone_2', 'icon-microphone_3', 'icon-next', 'icon-next2', 'icon-note_1', 'icon-note_2', 'icon-note_3', 'icon-note_4', 'icon-palaroid', 'icon-pan_flute', 'icon-pause', 'icon-pause2', 'icon-phone_note', 'icon-photo', 'icon-photo_block', 'icon-photo_center', 'icon-photo_download', 'icon-photo_flower', 'icon-photo_landscape', 'icon-photo_man', 'icon-photo_trio', 'icon-photo_upload', 'icon-photocamera_1', 'icon-photocamera_2', 'icon-photocamera_3', 'icon-photocamera_4', 'icon-photocamera_light', 'icon-photocamera_tripod', 'icon-photocamera_upload', 'icon-photos', 'icon-piano_1', 'icon-piano_2', 'icon-piano_chair', 'icon-play', 'icon-play2', 'icon-play_film', 'icon-play_presentation', 'icon-player3', 'icon-previous', 'icon-previous2', 'icon-record', 'icon-recorder', 'icon-speaker_1', 'icon-speaker_2', 'icon-stop', 'icon-ticket', 'icon-trumpet', 'icon-tuning_fork', 'icon-TV2', 'icon-videocamera_1', 'icon-videocamera_2', 'icon-videocamera_3', 'icon-videocamera_4', 'icon-volume', 'icon-volume_check', 'icon-volume_max', 'icon-volume_middle', 'icon-volume_min', 'icon-volume_minus', 'icon-volume_mute', 'icon-volume_off', 'icon-volume_plus', 'icon-compass', 'icon-directions_1', 'icon-directions_2', 'icon-earth', 'icon-flag', 'icon-flag_location_1', 'icon-flag_location_2', 'icon-globe', 'icon-map', 'icon-map_marker', 'icon-map_pin', 'icon-map_way', 'icon-marker', 'icon-marker_close', 'icon-marker_location_1', 'icon-marker_location_2', 'icon-marker_location_3', 'icon-marker_minus', 'icon-marker_plus', 'icon-marker_star', 'icon-navigation', 'icon-near_me', 'icon-pin', 'icon-pin_location_1', 'icon-pin_location_2', 'icon-signpost_1', 'icon-signpost_2', 'icon-signpost_3', 'icon-target3', 'icon-user_location2', 'icon-anchor', 'icon-ankh', 'icon-attention', 'icon-ban', 'icon-battery', 'icon-battery_average', 'icon-battery_full', 'icon-battery_low', 'icon-block', 'icon-book', 'icon-bookmark', 'icon-briefcase2', 'icon-brouser_cursor', 'icon-browser', 'icon-browser_404', 'icon-browser_favorite', 'icon-browser_html', 'icon-browser_search', 'icon-browser_settings', 'icon-browser_website', 'icon-bulb_1', 'icon-bulb_2', 'icon-calculator2', 'icon-calendar2', 'icon-calendar_date2', 'icon-call_end', 'icon-call_incoming', 'icon-call_outgoing', 'icon-cigarette', 'icon-circle_check', 'icon-circle_delete', 'icon-circle_division', 'icon-circle_down', 'icon-circle_equal', 'icon-circle_left', 'icon-circle_minus', 'icon-circle_plus', 'icon-circle_right', 'icon-circle_up', 'icon-click', 'icon-clip', 'icon-code', 'icon-coding', 'icon-compasses', 'icon-computer_1', 'icon-computer_2', 'icon-computer_analytics', 'icon-computer_key', 'icon-computer_music', 'icon-computer_network', 'icon-computer_phone', 'icon-computer_search', 'icon-computer_settings', 'icon-condom_1', 'icon-condom_2', 'icon-contacts', 'icon-controller', 'icon-court', 'icon-cross2', 'icon-diamond', 'icon-diamond_ring', 'icon-diod', 'icon-domino', 'icon-earphones', 'icon-earphones_microphone', 'icon-eye2', 'icon-film2', 'icon-funnel', 'icon-graduation_cap', 'icon-image', 'icon-input', 'icon-key_1', 'icon-key_2', 'icon-key_3', 'icon-laptop', 'icon-lifebuoy', 'icon-lock', 'icon-lock_open', 'icon-magnet', 'icon-mail_inbox', 'icon-mail_outbox', 'icon-megaphone', 'icon-menorah', 'icon-microphone', 'icon-mouse2', 'icon-network', 'icon-newspaper', 'icon-no_smoking', 'icon-open_book', 'icon-output', 'icon-peace', 'icon-pen', 'icon-pencil_1', 'icon-pencil_2', 'icon-phone', 'icon-photo2', 'icon-pin2', 'icon-presentation_1', 'icon-presentation_2', 'icon-presentation_3', 'icon-price_tag', 'icon-printer', 'icon-printer_check', 'icon-printer_error', 'icon-radio', 'icon-rook', 'icon-school_bus', 'icon-settings_1', 'icon-settings_2', 'icon-star_of_David', 'icon-strategy', 'icon-tablet2', 'icon-target4', 'icon-targeting', 'icon-umbrella', 'icon-user2', 'icon-yin_yang', 'icon-zoom', 'icon-zoom_in', 'icon-zoom_out', 'icon-bleach_any', 'icon-chlorine_allowed', 'icon-do_not_bleach', 'icon-do_not_dry', 'icon-do_not_dry_clean', 'icon-do_not_iron', 'icon-do_not_steam', 'icon-do_not_tumble_dry', 'icon-do_not_wash', 'icon-do_not_wring', 'icon-drip_dry', 'icon-dry', 'icon-dry_clean', 'icon-dry_clean_any_solvent', 'icon-dry_clean_any_solvent_exept_tetrachloroethylene', 'icon-dry_clean_any_solvent_exept_tetrachloroethylene_gentle', 'icon-dry_clean_petroleum_solvet_only', 'icon-dry_clean_petroleum_solvet_only_gentle', 'icon-dry_flat', 'icon-dry_in_shade', 'icon-hand_wash', 'icon-iron_any_temperature_steam_or_dry', 'icon-iron_high_heat', 'icon-iron_low_heat', 'icon-iron_medium_heat', 'icon-line_dry', 'icon-machine_wash', 'icon-machine_wash_30', 'icon-machine_wash_40', 'icon-machine_wash_50', 'icon-machine_wash_60', 'icon-machine_wash_70', 'icon-machine_wash_95', 'icon-machine_wash_cold', 'icon-machine_wash_gentle', 'icon-machine_wash_hot_1', 'icon-machine_wash_hot_2', 'icon-machine_wash_hot_3', 'icon-machine_wash_hot_4', 'icon-machine_wash_permanent_press', 'icon-machine_wash_warm', 'icon-non-chlorine_bleach', 'icon-tumble_dry_gentle', 'icon-tumble_dry_normal', 'icon-tumble_dry_normal_high_heat', 'icon-tumble_dry_normal_low_heat', 'icon-tumble_dry_normal_medium_heat', 'icon-tumble_dry_normal_no_heat', 'icon-tumble_dry_permanent_press', 'icon-wet_cleaning', 'icon-baby_mobile', 'icon-baby_monitor', 'icon-ballon', 'icon-bottle_12', 'icon-bottle_22', 'icon-crib', 'icon-diaper_1', 'icon-diaper_2', 'icon-kid', 'icon-kid_crying', 'icon-kid_happy_1', 'icon-kid_happy_2', 'icon-kid_sad', 'icon-onesie', 'icon-pacifier_1', 'icon-pacifier_2', 'icon-rattle', 'icon-safety_pin', 'icon-stroller', 'icon-tricycle', 'icon-american_flag', 'icon-american_hat', 'icon-angel', 'icon-angel_heart', 'icon-balloon', 'icon-barrel', 'icon-basket', 'icon-bat', 'icon-bible', 'icon-bow', 'icon-bow_and_arrow2', 'icon-broken_heart', 'icon-broken_heart_couple', 'icon-broom', 'icon-camera', 'icon-candle_1', 'icon-candle_2', 'icon-candy', 'icon-candy_cane_1', 'icon-candy_cane_2', 'icon-cauldron', 'icon-cemetery', 'icon-christmas_tree_1', 'icon-christmas_tree_2', 'icon-church2', 'icon-clover', 'icon-coffin', 'icon-couple', 'icon-death', 'icon-devil_heart', 'icon-dinner', 'icon-dove', 'icon-drumstick', 'icon-egg_1', 'icon-egg_2', 'icon-egg_3', 'icon-elf', 'icon-email', 'icon-firework', 'icon-fish_symbol', 'icon-Frankensteins_monster', 'icon-ghost_1', 'icon-ghost_2', 'icon-gift', 'icon-gift_2', 'icon-gift_3', 'icon-gift_4', 'icon-gift_5', 'icon-gift_6', 'icon-gingerbread_man', 'icon-grave', 'icon-heart2', 'icon-heart_arrow', 'icon-heart_block', 'icon-heart_connecting', 'icon-heart_couple', 'icon-heart_price', 'icon-heart_search', 'icon-hockey_mask', 'icon-horseshoe', 'icon-inlove_couple', 'icon-leprechaun_hat', 'icon-lock_heart', 'icon-lollipop', 'icon-love_calendar', 'icon-love_couple', 'icon-love_flower', 'icon-love_key', 'icon-love_man', 'icon-love_ring', 'icon-love_search', 'icon-love_woman', 'icon-marker_love', 'icon-mistletoe', 'icon-mittens', 'icon-note2', 'icon-ornament_1', 'icon-ornament_2', 'icon-ornament_3', 'icon-ornament_4', 'icon-ornament_5', 'icon-phone2', 'icon-photo3', 'icon-pilgrim_hat', 'icon-presents', 'icon-price_tag2', 'icon-pumpkin_1', 'icon-pumpkin_2', 'icon-rabbit', 'icon-reindeer', 'icon-rings', 'icon-romantic_movie', 'icon-rose', 'icon-sad_heart', 'icon-santa_hat', 'icon-sants_claus', 'icon-skull', 'icon-sleigh_1', 'icon-sleigh_2', 'icon-smile_heart', 'icon-snow_globe', 'icon-snowflake_1', 'icon-snowflake_2', 'icon-snowflake_3', 'icon-snowflake_4', 'icon-snowflake_5', 'icon-snowman', 'icon-stemware', 'icon-stocking', 'icon-tulip', 'icon-user_heart', 'icon-vampire', 'icon-wings_heart', 'icon-witch_hat', 'icon-wreath', 'icon-zombie', 'icon-aluminum_can', 'icon-apple', 'icon-avocado', 'icon-beaker', 'icon-beer', 'icon-blender', 'icon-bottle', 'icon-bread', 'icon-burger', 'icon-cake', 'icon-carrot', 'icon-champagne', 'icon-cheese', 'icon-chef_hat', 'icon-cherry', 'icon-chicken', 'icon-cleaver', 'icon-cocktail', 'icon-coffee', 'icon-coffee_grains', 'icon-coffee_grinder', 'icon-coffee_pot', 'icon-coffee_to_go', 'icon-corkscrew', 'icon-croissant', 'icon-cupcake', 'icon-cutlery', 'icon-drink', 'icon-fish', 'icon-french_press', 'icon-fridge2', 'icon-fried_egg', 'icon-fry_pan', 'icon-gingerbread_man2', 'icon-glass', 'icon-grape', 'icon-grater', 'icon-grinding_bowl', 'icon-ice_cream', 'icon-ice_cream_2', 'icon-juicer', 'icon-kettle', 'icon-ladle', 'icon-lemon', 'icon-martini', 'icon-microwave', 'icon-mixer', 'icon-mushroom', 'icon-onion', 'icon-orange', 'icon-piece_of_cake', 'icon-pizza', 'icon-plate', 'icon-platter', 'icon-pot', 'icon-rolling_pin', 'icon-salt_and_pepper', 'icon-sausage_1', 'icon-sausage_2', 'icon-scale', 'icon-shaker', 'icon-skewers', 'icon-slice_of_orange', 'icon-stove', 'icon-strawberry', 'icon-tea', 'icon-toaster', 'icon-wheat', 'icon-whiskey', 'icon-wine', 'icon-angry', 'icon-angry_2', 'icon-child', 'icon-confused', 'icon-crying', 'icon-cyclopes', 'icon-dead', 'icon-funny', 'icon-greedy', 'icon-happy_1', 'icon-happy_2', 'icon-happy_3', 'icon-lips_sealed', 'icon-love', 'icon-relax', 'icon-sad_1', 'icon-sad_2', 'icon-sad_3', 'icon-sad_4', 'icon-shock', 'icon-silence', 'icon-sleepy', 'icon-smart', 'icon-speechless', 'icon-star3', 'icon-surprised', 'icon-tongue_1', 'icon-tongue_2', 'icon-wink', 'icon-zombie2', 'icon-email_1', 'icon-email_2', 'icon-email_3', 'icon-email_attention', 'icon-email_block', 'icon-email_check', 'icon-email_clock', 'icon-email_close', 'icon-email_doc', 'icon-email_download', 'icon-email_edit', 'icon-email_like', 'icon-email_lock', 'icon-email_minus', 'icon-email_open', 'icon-email_plus', 'icon-email_reload', 'icon-email_search', 'icon-email_send', 'icon-email_settings', 'icon-email_star', 'icon-email_upload', 'icon-mailbox_1', 'icon-mailbox_2', 'icon-send_mail', 'icon-barrel_1', 'icon-barrel_2', 'icon-battery_1', 'icon-battery_2', 'icon-bulb_fluorescent', 'icon-bulb_fluorescent_2', 'icon-bulb_leaf', 'icon-bulb_sun', 'icon-chemistry_leaf', 'icon-CO2', 'icon-eco', 'icon-faucet_1', 'icon-faucet_2', 'icon-faucet_3', 'icon-flower_1', 'icon-flower_2', 'icon-flower_energy', 'icon-green_home_1', 'icon-green_home_2', 'icon-hand_globe', 'icon-hand_leaf', 'icon-hand_leafs', 'icon-hands_leaf', 'icon-jerrycan', 'icon-leaf', 'icon-leaf_energy', 'icon-leafs', 'icon-oil_rig', 'icon-outlet_1', 'icon-outlet_2', 'icon-power_plant_1', 'icon-power_plant_2', 'icon-radiation', 'icon-solar_energy', 'icon-sun_energy', 'icon-transmission_tower', 'icon-trash_eco', 'icon-tree2', 'icon-watering_can', 'icon-windmill', 'icon-check_folder', 'icon-close_folder', 'icon-cloud_folder', 'icon-deleted_folder', 'icon-favorite_folder', 'icon-film_folder', 'icon-folder', 'icon-HTML_folder', 'icon-image_folder', 'icon-incoming_folder', 'icon-lock_folder', 'icon-love_folder', 'icon-minus_folder', 'icon-music_folder', 'icon-outgoing_folder', 'icon-plus_folder', 'icon-search_folder', 'icon-settings_folder', 'icon-trash_folder', 'icon-unlock_folder', 'icon-audio_doc', 'icon-contact_doc', 'icon-copy_doc', 'icon-deleted_doc', 'icon-diagram_doc', 'icon-doc_check', 'icon-doc_close', 'icon-doc_minus', 'icon-doc_money', 'icon-doc_plus', 'icon-document', 'icon-favorite_doc', 'icon-film_doc', 'icon-HTML_doc', 'icon-image_doc', 'icon-info_doc', 'icon-key_doc', 'icon-link_doc', 'icon-list_doc', 'icon-lock_doc', 'icon-love_doc', 'icon-play_doc', 'icon-search_doc', 'icon-settings_doc', 'icon-table_doc', 'icon-unknown_doc', 'icon-unlock_doc', 'icon-warning_doc', 'icon-watch_doc', 'icon-zip_doc', 'icon-audio_doc2', 'icon-contact_doc2', 'icon-copy_doc2', 'icon-deleted_doc2', 'icon-diagram_doc2', 'icon-doc_check2', 'icon-doc_close2', 'icon-doc_minus2', 'icon-doc_money2', 'icon-doc_plus2', 'icon-document2', 'icon-favorite_doc2', 'icon-film_doc2', 'icon-HTML_doc2', 'icon-image_doc2', 'icon-info_doc2', 'icon-key_doc2', 'icon-link_doc2', 'icon-list_doc2', 'icon-lock_doc2', 'icon-love_doc2', 'icon-play_doc2', 'icon-search_doc2', 'icon-settings_doc2', 'icon-table_doc2', 'icon-unknown_doc2', 'icon-unlock_doc2', 'icon-warning_doc2', 'icon-watch_doc2', 'icon-zip_doc2', 'icon-anchor_add', 'icon-anchor_delete', 'icon-bounding_box_1', 'icon-bounding_box_2', 'icon-circle', 'icon-crop', 'icon-distribute_bottom', 'icon-distribute_center', 'icon-distribute_top', 'icon-flip_horizontal', 'icon-flip_vertical', 'icon-magic_wand_1', 'icon-magic_wand_2', 'icon-palette', 'icon-pen2', 'icon-pencil', 'icon-resize', 'icon-ruler_1', 'icon-ruler_2', 'icon-scale_down', 'icon-scale_up', 'icon-spray_1', 'icon-spray_2', 'icon-stamp', 'icon-vector_1', 'icon-vector_2', 'icon-vector_3', 'icon-vertical_align_bottom', 'icon-vertical_align_center', 'icon-vertical_align_top', 'icon-bluetooth', 'icon-ethernet', 'icon-folder_network', 'icon-hard_drive', 'icon-link', 'icon-link_broken', 'icon-microchip_1', 'icon-microchip_2', 'icon-network2', 'icon-notebook_network', 'icon-PC_connection_1', 'icon-PC_connection_2', 'icon-PC_connection_3', 'icon-PC_network', 'icon-PC_no_connection', 'icon-PC_phone_connection', 'icon-pc_wifi', 'icon-phone_wifi_1', 'icon-phone_wifi_2', 'icon-plug_1', 'icon-plug_2', 'icon-projector_1', 'icon-projector_2', 'icon-ram', 'icon-remote_control_1', 'icon-remote_control_2', 'icon-router_1', 'icon-router_2', 'icon-router_network', 'icon-satellite_1', 'icon-satellite_2', 'icon-satellite_dish_1', 'icon-satellite_dish_2', 'icon-satellite_PC_connection', 'icon-satellite_phone_connection', 'icon-settings_12', 'icon-settings_22', 'icon-signal_1', 'icon-signal_2', 'icon-signal_3', 'icon-signal_4', 'icon-signal_strength_1', 'icon-signal_strength_2', 'icon-signal_strength_3', 'icon-signal_strength_4', 'icon-signal_strength_5', 'icon-USB', 'icon-USB_flash_drive', 'icon-walkie_talkie', 'icon-wifi', 'icon-apron', 'icon-babydoll', 'icon-bag2', 'icon-bathrobe', 'icon-beanie', 'icon-belt', 'icon-boots', 'icon-bow_tie', 'icon-bowler', 'icon-bra', 'icon-briefs', 'icon-cloche', 'icon-coat_1', 'icon-coat_2', 'icon-dress2', 'icon-dress_long_sleeves', 'icon-glasses_1', 'icon-glasses_2', 'icon-high_heel', 'icon-hoodi', 'icon-jacket', 'icon-jersey', 'icon-long_sleeve', 'icon-mexican_hat', 'icon-mittens2', 'icon-pants2', 'icon-polo', 'icon-ranger_hat', 'icon-scarf', 'icon-shirt_1', 'icon-shirt_2', 'icon-shirt_tie', 'icon-shorts_1', 'icon-shorts_2', 'icon-skirt_pleat', 'icon-skirt_round', 'icon-sneaker', 'icon-sock', 'icon-strapless', 'icon-sunglasses', 'icon-sweatshirt', 'icon-tank_top', 'icon-teddy', 'icon-tie', 'icon-top_hat', 'icon-trapper', 'icon-umbrella2', 'icon-undergarments', 'icon-waistcoat', 'icon-wallet', 'icon-chat_1', 'icon-chat_2', 'icon-chat_3', 'icon-chat_alert', 'icon-chat_attention', 'icon-chat_block', 'icon-chat_bubbles', 'icon-chat_check', 'icon-chat_close', 'icon-chat_edit', 'icon-chat_info', 'icon-chat_like', 'icon-chat_minus', 'icon-chat_plus', 'icon-chat_question', 'icon-chat_quote', 'icon-chat_smile', 'icon-chat_star', 'icon-cloud_chat_1', 'icon-cloud_chat_2', 'icon-comment_1', 'icon-comment_2', 'icon-comment_3', 'icon-comment_alert', 'icon-comment_attention', 'icon-comment_block', 'icon-comment_check', 'icon-comment_close', 'icon-comment_edit', 'icon-comment_info', 'icon-comment_like', 'icon-comment_minus', 'icon-comment_plus', 'icon-comment_question', 'icon-comment_quote', 'icon-comment_smile', 'icon-comment_star', 'icon-comments_1', 'icon-comments_2', 'icon-talking', 'icon-blind', 'icon-brain_1', 'icon-brain_2', 'icon-eay', 'icon-eye3', 'icon-eye_closed', 'icon-finger', 'icon-fingerprint', 'icon-fingerprint_block', 'icon-fingerprint_check', 'icon-fingerprint_cross', 'icon-fingerprint_minus', 'icon-fingerprint_plus', 'icon-fingerprint_settings', 'icon-foot', 'icon-footprint', 'icon-hand', 'icon-hand_middle_finger', 'icon-hand_rock', 'icon-kidneys', 'icon-lips', 'icon-liver', 'icon-lungs', 'icon-moustache_1', 'icon-moustache_2', 'icon-nose_1', 'icon-nose_2', 'icon-penis', 'icon-stomach', 'icon-uterus', 'icon-aquarius', 'icon-aries', 'icon-cancer', 'icon-capricorn', 'icon-ceres', 'icon-chiron', 'icon-earth2', 'icon-gemini', 'icon-juno', 'icon-jupiter', 'icon-leo', 'icon-libra', 'icon-mars', 'icon-mercury', 'icon-moon', 'icon-neptune', 'icon-node_north', 'icon-node_south', 'icon-pallas', 'icon-pisces', 'icon-pluto', 'icon-sagittarius', 'icon-saturn', 'icon-scorpio', 'icon-sun', 'icon-taurus', 'icon-uranus', 'icon-venus', 'icon-vesta', 'icon-vigro', 'icon-actual_size', 'icon-back_to_finish', 'icon-back_to_start', 'icon-big_1', 'icon-big_2', 'icon-down_1', 'icon-down_2', 'icon-down_3', 'icon-down_4', 'icon-down_5', 'icon-down_6', 'icon-down_left', 'icon-down_right', 'icon-download_1', 'icon-download_2', 'icon-download_3', 'icon-exit', 'icon-expand', 'icon-fork', 'icon-full_screen', 'icon-infinity', 'icon-left_1', 'icon-left_2', 'icon-left_3', 'icon-left_4', 'icon-left_5', 'icon-left_6', 'icon-left_down_1', 'icon-left_down_2', 'icon-left_right_1', 'icon-left_right_2', 'icon-left_up_1', 'icon-left_up_2', 'icon-merge', 'icon-move_1', 'icon-move_2', 'icon-move_3', 'icon-move_4', 'icon-move_5', 'icon-move_6', 'icon-move_7', 'icon-narrow', 'icon-recycle', 'icon-refresh', 'icon-reload', 'icon-repeat_1', 'icon-repeat_2', 'icon-right_1', 'icon-right_2', 'icon-right_3', 'icon-right_4', 'icon-right_5', 'icon-right_6', 'icon-right_down_1', 'icon-right_down_2', 'icon-right_up_1', 'icon-right_up_2', 'icon-rotate_1', 'icon-rotate_2', 'icon-shuffle', 'icon-small_1', 'icon-small_2', 'icon-swith', 'icon-transfer_12', 'icon-transfer_22', 'icon-up_1', 'icon-up_2', 'icon-up_3', 'icon-up_4', 'icon-up_5', 'icon-up_6', 'icon-up_down_1', 'icon-up_down_2', 'icon-up_left_1', 'icon-up_left_2', 'icon-up_right_1', 'icon-up_right_2', 'icon-upload_1', 'icon-upload_2', 'icon-upload_3', 'icon-ant', 'icon-bear', 'icon-beaver', 'icon-bee', 'icon-birdcage', 'icon-bone', 'icon-butterfly', 'icon-cat', 'icon-cock', 'icon-cow', 'icon-crab', 'icon-dog', 'icon-fish2', 'icon-fishbowl', 'icon-goat', 'icon-ladybug', 'icon-lion', 'icon-lizard_1', 'icon-lizard_2', 'icon-mouse3', 'icon-panda', 'icon-paw_print', 'icon-pig_1', 'icon-pig_2', 'icon-scorpion', 'icon-sheep', 'icon-shrimp', 'icon-snake', 'icon-spider', 'icon-turtle', 'added-icon-twitter-x-logo'
			);

			$return_icons['dfd_icons'] = array(
				'name' => 'dfd_icons',
				'label' => esc_html__('Theme Default Icons', 'dfd'),
				'prefix' => 'dfd-',
				'displayPrefix' => 'dfd',
				'url' => get_template_directory_uri() . '/assets/fonts/dfd_icon_set/dfd_icon_set.css',
				'icons' => $dfd_icons,
				'ver' => '1.0.0',
			);

			if (!empty($dfd_ronneby['icon_param']) && is_string($dfd_ronneby['icon_param'][0]) ) {
				$custom_icons_pack = json_decode($dfd_ronneby['icon_param'][0], true);
				foreach ($custom_icons_pack as $font => $info) {
					if (!isset($info["active"]) || $info["active"] == false) {
						continue;
					}
					$icon_set = array();
					$icons = array();
					$style = $style_file_name = '';
					if (isset($info["is_default"])) {
						$upload_dir['basedir'] = DFD_RONNEBY_PLUGIN_URL;
					} else {
						$upload_dir = wp_upload_dir();
					}
					$path = trailingslashit($upload_dir['basedir']);
					$file = $path . $info['include'] . '/' . $info['config'];
					
					if(file_exists($file)) {
						include($file);
					}

					$style_file_name = str_replace(array($font, '/'), '', $info['style']);
					$style = $upload_dir['baseurl'] . '/' . $info['include'] . '/' . $font . $style_file_name;

					if (!empty($icons)) {
						$icon_set = array_merge($icon_set, $icons);
					}
					if (isset($info["is_default"])) {
						$set_name = esc_html__('Default Icons', 'dfd');
					} else {
						$set_name = ucfirst($font);
					}
					if (!empty($icon_set)) {
						$icons_names = array();
						foreach ($icon_set as $icons) {
							foreach ($icons as $icon) {
								array_push($icons_names, esc_attr($icon['class']));
							}
						}
						$return_icons[$font] = array(
							'name' => $set_name,
							'label' => $font,
							'prefix' => $font . '-',
							'displayPrefix' => $font,
							'url' => $style,
							'icons' => $icons_names,
							'ver' => '1.0.0',
						);
					}
				}
			}


			return $return_icons;
		}

		public function get_custom_fonts() {
			$font_list = array();

			if(method_exists('Custom_Font_Validator', 'font_list')) {
				$font_list = Custom_Font_Validator::font_list();
			}

			return $font_list;
		}
		
		public function add_custom_font($controls_registry) {
			$custom_fonts = $this->get_custom_fonts();
			$fonts = array();
			if($custom_fonts) {
				foreach($custom_fonts as $key => $value) {
					$fonts[$value['name']] = 'system';
				}
				$new_fonts = array_merge(
					$fonts,
					$controls_registry->get_control('font')->get_settings('options')
				);
				$controls_registry->get_control('font')->set_settings('options', $new_fonts);
			}
		}

		public function dfd_set_widgets() {
			$widgets = array(
				'el_animated_text' => 'el-animated-text',
				'el_blog_module' => 'el-blog-module',
				'el_button_module' => 'el-button-module',
				'el_carousel_image' => 'el-carousel-image',
				'el_carousel_progress_bar' => 'el-carousel-progress-bar',
				'el_carousel_team_member' => 'el-carousel-team-member',
				'el_carousel_testimonials' => 'el-carousel-testimonials',
				'el_countdown' => 'el-countdown',
				'el_facts' => 'el-facts',
				'el_dfd_gallery_module' => 'el-gallery-module',
				'el_icon_list' => 'el-icon-list',
				'el_image_layers' => 'el-image-layers',
				'el_info_banner' => 'el-info-banner',
				'el_info_box' => 'el-info-box',
				'el_milestone' => 'el-milestone',
				'el_piechart' => 'el-piechart',
				'el_portfolio_module' => 'el-portfolio-module',
				'el_price_list' => 'el-price-list',
				'el_pricing_block' => 'el-pricing-block',
				'el_progress_bar' => 'el-progress-bar',
				'el_rotate_box' => 'el-rotate-box',
				'el_services' => 'el-services',
				'el_share' => 'el-share',
				'el_social_accounts' => 'el-social-accounts',
				'el_team_member' => 'el-team-member',
				'el_testimonial' => 'el-testimonial',
				'el_testimonials_slider' => 'el-testimonials-slider',
				'el_timeline' => 'el-timeline',
				'el_dfd_videoplayer' => 'el-video-module',
			);
			
			if(defined('WOOCOMMERCE_VERSION') && class_exists('WooCommerce')) {
				$widgets['el_product_grid'] = 'el-product-grid';
			}

			foreach ($widgets as $name => $file) {
				// Include Widget files
				require_once( DFD_RONNEBY_PLUGIN_PATH . '/elementor/widgets/' . $file . '.php' );

				// Register widget
				\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new $name);
			}
		}

		public function dfd_elementor_styles() {
			wp_register_style('dfd_elementor_style', DFD_RONNEBY_PLUGIN_URL . 'elementor/assets/css/elementor-styles.css');
			wp_enqueue_style('dfd_elementor_style');
		}

		public function dfd_redactor_scripts() {
			wp_register_script('dfd_timeline_elementor', DFD_RONNEBY_PLUGIN_URL . 'elementor/assets/js/timeline.min.js', true, null, true);
		}
		
		public function dfd_elementor_scripts() {
			wp_register_script('dfd_scrolling_content_elementor', DFD_RONNEBY_PLUGIN_URL . 'elementor/assets/js/scrolling_content.min.js', array('jquery'), null, true);
		}

		public function dfd_enqueue_elementor_scripts() {
			wp_enqueue_script('dfd_scrolling_content_elementor');
		}
		
		public function dfd_elementor_register_script_admin() {
			wp_register_style('dfd_elementor_admin_style', DFD_RONNEBY_PLUGIN_URL . 'elementor/assets/css/admin.css');
			wp_enqueue_style('dfd_elementor_admin_style');
		}
		
	}

	$Dfd_Ronneby_Elementor = new Dfd_Ronneby_Elementor();
}
