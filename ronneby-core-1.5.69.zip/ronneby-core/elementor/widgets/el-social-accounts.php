<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Social_Accounts extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_social_accounts';
	}

	public function get_title() {
		return esc_html__('DFD Social Accounts', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_new_social_accounts';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_social_accounts', [
				'label' => esc_html__('Social Accounts', 'dfd')
			]
		);

		$this->add_control(
			'main_style', [
				'label' => esc_html__('Select Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Sliding icon', 'dfd'),
					'style-2' => esc_html__('Sliding background', 'dfd'),
					'style-3' => esc_html__('Rotate icon', 'dfd'),
					'style-4' => esc_html__('Fade', 'dfd'),
					'style-5' => esc_html__('Appear out', 'dfd'),
					'style-6' => esc_html__('General shadow', 'dfd'),
					'style-7' => esc_html__('Round to square', 'dfd'),
					'style-8' => esc_html__('Animated cube', 'dfd'),
					'style-9' => esc_html__('Retro disco', 'dfd'),
					'style-10' => esc_html__('Long shadow', 'dfd'),
					'style-11' => esc_html__('General border', 'dfd'),
					'style-12' => esc_html__('Flying line', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'dfd_social_networks_sel', [
				'label' => esc_html__('Select social networks', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('None', 'dfd'),
					'soc_icon-deviantart' => esc_html__('Deviantart', 'dfd'),
					'soc_icon-digg' => esc_html__('Digg', 'dfd'),
					'soc_icon-dribbble' => esc_html__('Dribbble', 'dfd'),
					'soc_icon-dropbox' => esc_html__('Dropbox', 'dfd'),
					'soc_icon-evernote' => esc_html__('Evernote', 'dfd'),
					'soc_icon-facebook' => esc_html__('Facebook', 'dfd'),
					'soc_icon-flickr' => esc_html__('Flickr', 'dfd'),
					'soc_icon-foursquare_2' => esc_html__('Foursquare', 'dfd'),
					'soc_icon-instagram' => esc_html__('Instagram', 'dfd'),
					'soc_icon-last_fm' => esc_html__('LastFM', 'dfd'),
					'soc_icon-linkedin' => esc_html__('LinkedIN', 'dfd'),
					'soc_icon-livejournal' => esc_html__('Livejournal', 'dfd'),
					'soc_icon-picasa' => esc_html__('Picasa', 'dfd'),
					'soc_icon-pinterest' => esc_html__('Pinterest', 'dfd'),
					'soc_icon-rss' => esc_html__('RSS', 'dfd'),
					'soc_icon-tumblr' => esc_html__('Tumblr', 'dfd'),
					'dfd-added-icon-twitter-x-logo' => esc_html__('Twitter', 'dfd'),
					'soc_icon-vimeo' => esc_html__('Vimeo', 'dfd'),
					'soc_icon-wordpress' => esc_html__('Wordpress', 'dfd'),
					'soc_icon-youtube' => esc_html__('YouTube', 'dfd'),
					'dfd-added-font-icon-px-icon' => esc_html__('500px', 'dfd'),
					'dfd-added-font-icon-vb' => esc_html__('ViewBug', 'dfd'),
					'soc_icon-mail' => esc_html__('Mail', 'dfd'),
					'dfd-added-font-icon-b_Xing-icon_bl' => esc_html__('Xing', 'dfd'),
					'dfd-added-font-icon-c_spotify-512-black' => esc_html__('Spotify', 'dfd'),
					'dfd-added-font-icon-houzz-dark-icon' => esc_html__('Houzz', 'dfd'),
					'dfd-added-font-icon-skype' => esc_html__('Skype', 'dfd'),
					'dfd-added-font-icon-slideshare' => esc_html__('Slideshare', 'dfd'),
					'dfd-added-font-icon-bandcamp-logo' => esc_html__('Bandcamp', 'dfd'),
					'dfd-added-font-icon-soundcloud-logo' => esc_html__('Soundcloud', 'dfd'),
					'dfd-added-font-icon-Meerkat-color' => esc_html__('Meerkat', 'dfd'),
					'dfd-added-font-icon-periscope-logo' => esc_html__('Periscope', 'dfd'),
					'dfd-added-font-icon-Snapchat-logo' => esc_html__('Snapchat', 'dfd'),
					'dfd-added-font-icon-the-city' => esc_html__('The City', 'dfd'),
					'soc_icon-behance' => esc_html__('Behance', 'dfd'),
					'dfd-added-font-icon-pinpoint' => esc_html__('Microsoft Pinpoint', 'dfd'),
					'dfd-added-font-icon-viadeo' => esc_html__('Viadeo', 'dfd'),
					'dfd-added-font-icon-tripadvisor' => esc_html__('TripAdvisor', 'dfd')
				],
				'default' => ''
			]
		);
		
		$repeater->add_control(
			'soc_url', [
				'label' => esc_html__('URL', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL
			]
		);
		
		$this->add_control(
			'dfd_social_networks', [
				'label' => esc_html__('Social networks', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->add_control(
			'info_alignment', [
				'label' => esc_html__('Icon alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-center'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'styles_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Styles', 'dfd')
			]
		);
		
		$this->add_control(
			'icon_font_size', [
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'icon_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'condition' => [
					'main_style' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-8', 'style-11', 'style-12']
				]
			]
		);
				
		$this->add_control(
			'icon_background_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon background color', 'dfd'),
				'condition' => [
					'main_style' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-8', 'style-11', 'style-12']
				]
			]
		);
		
		$this->add_control(
			'border_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'icon_margin', [
				'label' => esc_html__('Space between icons', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'icon_border', [
				'label' => esc_html__('Border', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'border_width', [
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'icon_border' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'border_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'icon_border' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'sliding_direction', [
				'label' => esc_html__('Sliding direction', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'left_to_right' => esc_html__('Left to right', 'dfd'),
					'top_to_bottom' => esc_html__('Top to bottom', 'dfd'),
					'right_to_left' => esc_html__('Right to left', 'dfd'),
					'bottom_to_top' => esc_html__('Bottom to top', 'dfd')
				],
				'default' => 'left_to_right',
				'condition' => [
					'main_style' => ['style-1', 'style-2', 'style-3', 'style-8']
				]
			]
		);
		
		$this->add_control(
			'general_border_width', [
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => 'style-11'
				]
			]
		);
		
		$this->add_control(
			'general_border_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'main_style' => 'style-11'
				]
			]
		);
		
		$this->add_control(
			'customizable_hover_colors', [
				'label' => esc_html__('Customizable hover colors', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'icon_hover_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon hover color', 'dfd'),
				'condition' => [
					'customizable_hover_colors' => 'yes'
				]
			]
		);

		$this->add_control(
			'icon_hover_background_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon background hover color', 'dfd'),
				'condition' => [
					'customizable_hover_colors' => 'yes'
				]
			]
		);
		
		$this->end_controls_section();
	}

	protected function render() {
		$output = $line_height_height = $a_style = $a_before_style = $line_height_ofset = $i_style = $link_css = '';
		
		$settings = $this->get_settings_for_display();
		
		$uniqid = uniqid('dfd-soc-icon-') .'-'.rand(1,9999);
			
		$general_class = esc_attr($settings['main_style']).' ';
		if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-1') === 0 || strcmp($settings['main_style'], 'style-2') === 0 || strcmp($settings['main_style'], 'style-3') === 0 || strcmp($settings['main_style'], 'style-8') === 0) {
			$general_class .= esc_attr($settings['sliding_direction']).' ';
		}
		if(isset($settings['icon_font_size']) && !empty($settings['icon_font_size'])) {
			$a_style .= 'font-size: '.esc_attr($settings['icon_font_size']).'px; ';
			$line_height_height = esc_attr($settings['icon_font_size']) * 3;
		}else{
			$line_height_height = 60;
		}
		if(isset($settings['border_radius']) && !empty($settings['border_radius'])) {
			$a_style .= 'border-radius: '.esc_attr($settings['border_radius']).'px; ';
		}
		if(isset($settings['icon_margin']) && $settings['icon_margin'] != '') {
			$a_style .= 'margin-right: '.esc_attr($settings['icon_margin']).'px; ';
		}
		if(isset($settings['icon_border']) && strcmp($settings['icon_border'], 'yes') === 0) {
			$general_class .= 'with-border ';
			if(isset($settings['border_width']) && !empty($settings['border_width'])) {
				$a_before_style .= 'border-width: '.esc_attr($settings['border_width']).'px; ';
				$line_height_ofset = esc_attr($settings['border_width']) * 2;
			}
			if(isset($settings['border_color']) && !empty($settings['border_color'])) {
				$a_before_style .= 'border-color: '.esc_attr($settings['border_color']).'; ';
			}
//			$line_height = (int)$line_height_height - (int)$line_height_ofset;
			$a_before_style .= 'line-height: '. ( (int)$line_height_height - (int)$line_height_ofset ) .'px; ';
		}
		if(isset($settings['icon_color']) && !empty($settings['icon_color'])) {
			$a_style .= 'color: '.esc_attr($settings['icon_color']).'; ';
			$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-12 a:after {background: '.esc_attr($settings['icon_color']).';}';
		}
		if(isset($settings['icon_background_color']) && !empty($settings['icon_background_color'])) {
			if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-8') === 0) {
				$a_before_style .= 'background: '.esc_attr($settings['icon_background_color']).'; ';
			} else {
				$a_style .= 'background: '.esc_attr($settings['icon_background_color']).'; ';
			}
		}
		if(isset($settings['customizable_hover_colors']) && strcmp($settings['customizable_hover_colors'], 'yes') === 0) {
			if(isset($settings['icon_hover_color']) && !empty($settings['icon_hover_color'])) {
				$i_style .= 'color: '.esc_attr($settings['icon_hover_color']).'; ';
				$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-2 a:hover {color: '.esc_attr($settings['icon_hover_color']).';}';
				$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-5 a:hover {color: '.esc_attr($settings['icon_hover_color']).';}';
				$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-12 a:hover {color: '.esc_attr($settings['icon_hover_color']).';}';
				$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-12 a:hover:after {background: '.esc_attr($settings['icon_hover_color']).';}';
			}
			if(isset($settings['icon_hover_background_color']) && !empty($settings['icon_hover_background_color'])) {
				$i_style .= 'background: '.esc_attr($settings['icon_hover_background_color']).'; ';
				$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-12 a:hover {background: '.esc_attr($settings['icon_hover_background_color']).';}';
			}
		}
		if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-2') === 0 && empty($settings['icon_hover_color'])) {
			$link_css .= '#'.$uniqid.'.dfd-new-soc-icon.style-2 a:hover {color: #ffffff;}';
		}
		if(!empty($a_style) || !empty($a_before_style) || !empty($i_style)) {
			$link_css .= '#'.$uniqid.'.dfd-new-soc-icon a {'.$a_style.'}';
			$link_css .= '#'.$uniqid.'.dfd-new-soc-icon a:before {'.$a_before_style.'}';
			$link_css .= '#'.$uniqid.'.dfd-new-soc-icon a i {'.$i_style.'}';
		}
		if(isset($settings['general_border_width']) && $settings['general_border_width'] != '') {
			$link_css .= '#'.$uniqid.'.style-11 .soc-icon-container {border-width: '.$settings['general_border_width'].'px;}';
		}
		if(isset($settings['general_border_color']) && $settings['general_border_color'] != '') {
			$link_css .= '#'.$uniqid.'.style-11 .soc-icon-container {border-color: '.$settings['general_border_color'].';}';
		}

		$output .= '<div id="'.esc_attr($uniqid).'" class="dfd-new-soc-icon '.esc_attr($settings['info_alignment']). ' ' .$general_class. '">';
			$output .= '<div class="soc-icon-container clearfix">';

				foreach($settings['dfd_social_networks'] as $network) {
					$link_atts = '';
					if(isset($network['dfd_social_networks_sel']) && isset($network['soc_url'])) {
						if(isset($network['dfd_social_networks_sel'])) {
							$single_icon = $network['dfd_social_networks_sel'];
						}
						if(!empty($network['soc_url'])) {
							$link_atts .= 'href="' . (!empty($network['soc_url']['url']) ? esc_url($network['soc_url']['url']) : '#') . '"';
							$link_atts .= ' target="' . (!empty($network['soc_url']['is_external']) ? '_blank' : '_self' ) . '"';
							$link_atts .= !empty($network['soc_url']['nofollow']) ? ' rel="nofollow"' : '';
							$link_atts .= !empty($network['soc_url']['custom_attributes']) ? ' ' . esc_attr($network['soc_url']['custom_attributes']) : '';
						}
						if(isset($settings['main_style']) && strcmp($settings['main_style'], 'style-9') === 0) {
							$icon_style_html = '<span class="line-top-left '.esc_attr($single_icon).'"></span><span class="line-top-center '.esc_attr($single_icon).'"></span><span class="line-top-right '.esc_attr($single_icon).'"></span><span class="line-bottom-left '.esc_attr($single_icon).'"></span><span class="line-bottom-center '.esc_attr($single_icon).'"></span><span class="line-bottom-right '.esc_attr($single_icon).'"></span>';
						} else {
							$icon_style_html = '<i class="'.esc_attr($single_icon).'"></i>';
						}
						$output .= '<a '.$link_atts.' class="'.esc_attr($single_icon).'">'.$icon_style_html.'</a>';
					}
				}

			$output .= '</div>';
		$output .= '</div>';

		$output .= '<script type="text/javascript">
						(function($) {
							$("head").append("<style>'. esc_js($link_css) .'</style>");
						})(jQuery);
					</script>';
		
		echo $output;
	}

}
