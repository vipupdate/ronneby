<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Countdown extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_countdown';
	}

	public function get_title() {
		return esc_html__('DFD Countdown', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'countdown';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_countdown_content',
			[
				'label' => esc_html__('Countdown content', 'dfd')
			]
		);
		
		$this->add_control(
			'main_layout',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Simple', 'dfd'),
					'layout-2' => esc_html__('Bordered', 'dfd'),
					'layout-3' => esc_html__('Underlined', 'dfd'),
					'layout-4' => esc_html__('Background', 'dfd')
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'datetime',
			[
				'label' => esc_html__('Target time for countdown', 'dfd'),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);
		
		$this->add_control(
			'countdown_opt_syear',
			[
				'label' => esc_html__('Years', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_smonth',
			[
				'label' => esc_html__('Months', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_sweek',
			[
				'label' => esc_html__('Weeks', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_sday',
			[
				'label' => esc_html__('Days', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_shr',
			[
				'label' => esc_html__('Hours', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_smin',
			[
				'label' => esc_html__('Minutes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'countdown_opt_ssec',
			[
				'label' => esc_html__('Seconds', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'countdown_style_section', [
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'label' => esc_html__('Design style', 'dfd')
			]
		);
		
		$this->add_control(
			'radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3', 'layout-4']
				],
				'selectors' => [
					'{{WRAPPER}} .number-wrap' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'main_layout' => ['layout-2', 'layout-3', 'layout-4']
				],
				'selectors' => [
					'{{WRAPPER}} .number-wrap' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background', 'dfd'),
				'condition' => [
					'main_layout' => 'layout-4'
				],
				'selectors' => [
					'{{WRAPPER}} .number-wrap' => 'background: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'delim_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .period' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'shadow',
			[
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'disable_dividers',
			[
				'label' => esc_html__('Disable dividers', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'countdown_typography_section', [
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			'label' => esc_html__('Design style', 'dfd')
			]
		);
		
		$this->add_control(
			'divider_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Divider color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .period' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'divider-typography',
				'label' => esc_html__('Divider typography', 'dfd'),
				'selector' => '{{WRAPPER}} .period'
			]
		);
		
		$this->add_control(
			'number_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Number color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .number' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'number-typography',
				'label' => esc_html__('Number typography', 'dfd'),
				'selector' => '{{WRAPPER}} .number'
			]
		);
		
		$this->add_control(
			'time_units_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Time Units color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dot' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'time_units-typography',
				'label' => esc_html__('Time Units typography', 'dfd'),
				'selector' => '{{WRAPPER}} .dot'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$output = $count_frmt = $el_class = $dot_html = $shadow = '';
		
		$settings = $this->get_settings_for_display();

		if($settings['shadow'] === 'yes' ) {
			$shadow = 'shadow';
		}
		
		if($settings['disable_dividers'] == 'yes') {
			$el_class .= 'disable-dividers';
		} else {
			$dot_html = '<span class="dot"><table class="table_vert_align_dot"><tr><td class="table_cell_align_dot">:</td></tr></table></span>';
		}
		
		$syear = $smonth = $sweek = $sday = $shr = $smin = $ssec = '';
		if($settings['countdown_opt_syear'] == 'yes') {
			$syear = 'syear';
		}
		if($settings['countdown_opt_smonth'] == 'yes') {
			$smonth = 'smonth';
		}
		if($settings['countdown_opt_sweek'] == 'yes') {
			$sweek = 'sweek';
		}
		if($settings['countdown_opt_sday'] == 'yes') {
			$sday = 'sday';
		}
		if($settings['countdown_opt_shr'] == 'yes') {
			$shr = 'shr';
		}
		if($settings['countdown_opt_smin'] == 'yes') {
			$smin = 'smin';
		}
		if($settings['countdown_opt_ssec'] == 'yes') {
			$ssec = 'ssec';
		}

		if('syear' === $syear) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-Y</span><span class="period">' . esc_html__( 'Years', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}

		if('smonth' === $smonth && 'syear' === $syear) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-z</span><span class="period">' . esc_html__( 'Months', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}elseif('smonth' === $smonth && '' === $syear) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-m</span><span class="period">' . esc_html__( 'Months', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}

		if('sweek' === $sweek && 'smonth' === $smonth) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-W</span><span class="period">' . esc_html__( 'Weeks', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}elseif('sweek' === $sweek && '' === $syear && '' === $smonth) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-w</span><span class="period">' . esc_html__( 'Weeks', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}

		if('sday' === $sday && 'sweek' === $sweek) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-d</span><span class="period">' . esc_html__( 'Days', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}elseif('sday' === $sday && '' === $syear && '' === $smonth && '' === $sweek) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-D</span><span class="period">' . esc_html__( 'Days', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}
		if('shr' === $shr) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-H</span><span class="period">' . esc_html__( 'Hours', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}
		if('smin' === $smin) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-M</span><span class="period">' . esc_html__( 'Minutes', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}
		if('ssec' === $ssec) {
			$count_frmt .= '<span class="number-wrap ' . $shadow . '"><span class="number">%-S</span><span class="period">' . esc_html__( 'Seconds', 'dfd' ) . '</span><i></i><b></b>'.$dot_html.'</span>';
		}

		$output .= '<div class="dfd-countdown ' . $settings['main_layout'] . ' '.esc_attr($el_class).'">';
		
		if($settings['datetime'] != ''){
			$output .= '<div class="dfd-countdown-wrap" data-date="'.esc_attr($settings['datetime']).'" data-finish-text="'.esc_attr__('Event already pass','dfd').'">';
				$output .= '<div class="hide dfd-countdown-html">'.wp_kses($count_frmt, array('span' => array('class' => array(), 'style' => array()), 'i' => array(), 'b' => array())).'</div>';
			$output .= '</div>';
		}
		$output .='</div>';

		echo $output;
	}
}

