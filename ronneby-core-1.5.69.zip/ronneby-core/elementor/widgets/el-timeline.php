<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Timeline extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_timeline';
	}

	public function get_title() {
		return esc_html__('DFD Timeline', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_timeline';
	}
	
	public function get_script_depends() {
		return ['dfd_timeline_elementor'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_timeline',
			[
				'label' => esc_html__('Timeline', 'dfd')
			]
		);
		
		$this->add_control(
			'columns',
			[
				'label' => esc_html__('Columns', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					1 => esc_html__('1', 'dfd'),
					2 => esc_html__('2', 'dfd'),
					3 => esc_html__('3', 'dfd'),
					4 => esc_html__('4', 'dfd'),
					5 => esc_html__('5', 'dfd')
				],
				'default' => 5
			]
		);
		
		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					],
				],
				'default' => 'text-center'
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'block_date',
			[
				'label' => esc_html__('Date', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$repeater->add_control(
			'block_title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$repeater->add_control(
			'block_subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$repeater->add_control(
			'block_content',
			[
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA
			]
		);
		
		$repeater->add_control(
			'completed_action',
			[
				'label' => esc_html__('Completed action', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('Timeline content', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->add_control(
			'main_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Main line color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .timeline--horizontal .timeline__item.completed .timeline__item__inner:before, {{WRAPPER}} .timeline__item.completed:before, {{WRAPPER}} .timeline__item.completed:after' => 'background: {{VALUE}};',
					'{{WRAPPER}} .timeline-nav-button:hover:before' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->add_control(
			'back_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Back line color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .timeline--horizontal .timeline__item .timeline__item__inner:before, {{WRAPPER}} .timeline--horizontal .timeline__item .timeline__item__inner:after, {{WRAPPER}} .timeline__item:before, {{WRAPPER}} .timeline__item:after' => 'background: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_control(
			'date_html_tag',
			[
				'label' => esc_html__('Date HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-date-typography',
				'label' => esc_html__('Date typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-timeline-date',
			]
		);

		$this->add_control(
			'date_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Date color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-timeline-date' => 'color: {{VALUE}};'
				],
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-timeline-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-timeline-title' => 'color: {{VALUE}};'
				],
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-timeline-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-timeline-subtitle' => 'color: {{VALUE}};'
				],
				'separator' => 'after'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-description-typography',
				'label' => esc_html__('Description typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-timeline-description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Description color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-timeline-description' => 'color: {{VALUE}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'responcive_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Responcive', 'dfd'),
			]
		);
		
		$this->add_control(
			'desktop_columns',
			[
				'label' => esc_html__('Columns for width 1024-1279', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					1 => esc_html__('1', 'dfd'),
					2 => esc_html__('2', 'dfd'),
					3 => esc_html__('3', 'dfd'),
					4 => esc_html__('4', 'dfd'),
					5 => esc_html__('5', 'dfd')
				],
				'default' => 5
			]
		);
		
		$this->add_control(
			'tablet_columns',
			[
				'label' => esc_html__('Columns for width 1024-1279', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					1 => esc_html__('1', 'dfd'),
					2 => esc_html__('2', 'dfd'),
					3 => esc_html__('3', 'dfd'),
					4 => esc_html__('4', 'dfd'),
					5 => esc_html__('5', 'dfd')
				],
				'default' => 5
			]
		);
		
		$this->add_control(
			'mobile_columns',
			[
				'label' => esc_html__('Columns for less than 800', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					1 => esc_html__('1', 'dfd'),
					2 => esc_html__('2', 'dfd'),
					3 => esc_html__('3', 'dfd'),
					4 => esc_html__('4', 'dfd'),
					5 => esc_html__('5', 'dfd')
				],
				'default' => 5
			]
		);
		
		$this->end_controls_section();
	}

	protected function render() {
		$output = $data_attr = $el_class = $item_html = '';
		
		$settings = $this->get_settings_for_display();

		wp_enqueue_script('dfd-timeline');

		$uniqid = uniqid('dfd-timeline-').'-'.rand(1,9999);

		$el_class = ' number-col-'.$settings['columns'];
		$el_class = ' '.$settings['content_alignment'];

		$data_attr .= ' data-columns="'.(int)$settings['columns'].'"';
		$data_attr .= ' data-columns-desktop="'.(int)$settings['desktop_columns'].'"';
		$data_attr .= ' data-columns-tablet="'.(int)$settings['tablet_columns'].'"';
		$data_attr .= ' data-columns-mobile="'.(int)$settings['mobile_columns'].'"';

		if(isset($settings['list_fields']) && !empty($settings['list_fields'])) {
			foreach($settings['list_fields'] as $field) {
				$item_class = '';
				if(isset($field['completed_action']) && $field['completed_action'] == 'yes') {
					$item_class .= 'completed';
				}

				$item_html .= '<div class="timeline__item '.esc_attr($item_class).'">';
					$item_html .= '<div class="timeline__content">';
						if(isset($field['block_date']) && !empty($field['block_date'])) {
							$item_html .= '<'.$settings['date_html_tag'].' class="dfd-timeline-date box-name">'.esc_attr($field['block_date']).'</'.$settings['date_html_tag'].'>';
						}
						if(isset($field['block_title']) && !empty($field['block_title'])) {
							$item_html .= '<'.$settings['title_html_tag'].' class="dfd-timeline-title box-name">'.esc_attr($field['block_title']).'</'.$settings['title_html_tag'].'>';
						}
						if(isset($field['block_subtitle']) && !empty($field['block_subtitle'])) {
							$item_html .= '<'.$settings['title_html_tag'].' class="dfd-timeline-subtitle subtitle">'.esc_attr($field['block_subtitle']).'</'.$settings['title_html_tag'].'>';
						}
						if(isset($field['block_content']) && !empty($field['block_content'])) {
							$item_html .= '<div class="dfd-timeline-description">'.esc_attr($field['block_content']).'</div>';
						}
					$item_html .= '</div>';
				$item_html .= '</div>';
			}

			$output .= '<div id="'.esc_attr($uniqid).'" class="dfd-timeline-wrap dfd-elementor-widget timeline '.esc_attr($el_class).'" '.$data_attr.'>';
				$output .= '<div class="timeline__wrap">';
					$output .= '<div class="timeline__items">';
						$output .= $item_html;
					$output .= '</div>';
				$output .= '</div>';
			$output .= '</div>';
		}

		echo $output;
		
	}

}