<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Product_Grid extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_product_grid';
	}

	public function get_title() {
		return esc_html__('DFD Product grid', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'woocomposer_grid';
	}

	/**
	 * Get product categories.
	 * */
	private function get_dfd_product_category() {
		$options = array();

		$terms = get_terms(
			array(
				'taxonomy' => 'product_cat',
				'hide_empty' => true,
			)
		);
		foreach($terms as $term) {
			if(isset($term)) {
				if(isset($term->slug) && isset($term->name)) {
					$options[$term->slug] = $term->name;
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		global $dfd_ronneby;
		
		$this->start_controls_section(
			'el_product_grid',
			[
				'label' => esc_html__('Product grid', 'dfd')
			]
		);

		$this->add_control(
			'display_type',
			[
				'label' => esc_html__('Display', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'recent_products' => esc_html__('Recent products', 'dfd'),
					'featured_products' => esc_html__('Featured Products', 'dfd'),
					'top_rated_products' => esc_html__('Top Rated Products', 'dfd'),
					'product_categories' => esc_html__('Product Categories', 'dfd'),
					'sale_products' => esc_html__('Products on Sale', 'dfd'),
					'best_selling_products' => esc_html__('Best Selling Products', 'dfd')
				],
				'default' => 'recent_products'
			]
		);

		$this->add_control(
			'per_page',
			[
				'label' => esc_html__('Items to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 12
			]
		);
		
		$this->add_control(
			'columns',
			[
				'label' => esc_html__('Columns', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 4
			]
		);
		
		$this->add_control(
			'order_by',
			[
				'label' => esc_html__('Order By', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'date' => esc_html__('Date', 'dfd'),
					'title' => esc_html__('Title', 'dfd'),
					'ID' => esc_html__('Product ID', 'dfd'),
					'name' => esc_html__('Name', 'dfd'),
					'price' => esc_html__('Price', 'dfd'),
					'sales' => esc_html__('Sales', 'dfd'),
					'rand' => esc_html__('Random', 'dfd')
				],
				'default' => 'date'
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__('Loop Order', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'asc' => esc_html__('Ascending', 'dfd'),
					'desc' => esc_html__('Descending', 'dfd')
				],
				'default' => 'asc'
			]
		);
		
		if(!empty($this->get_dfd_product_category())) {
		
			$this->end_controls_section();

			$this->start_controls_section(
				'el_post_items_settings',
				[
					'label' => esc_html__('Post items settings', 'dfd'),
					'condition' => [
						'display_type' => 'product_categories'
					]
				]
			);
			
			foreach ($this->get_dfd_product_category() as $slug => $name) {
				$this->add_control(
					'product_category_' . $slug,
					[
						'label' => $name,
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'condition' => [
							'display_type' => 'product_categories'
						]
					]
				);
			}
		}
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_product_settings',
			[
				'label' => esc_html__('Product settings', 'dfd')
			]
		);
			
		$this->add_control(
			'products_style',
			[
				'label' => esc_html__('Select Products Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Simple', 'dfd'),
					'style-2' => esc_html__('Advanced', 'dfd'),
					'style-3' => esc_html__('Full', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->add_control(
			'excerpt_length',
			[
				'label' => esc_html__('Excerpt length', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'products_style' => ['style-2', 'style-3']
				]
			]
		);
		
		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Information Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-center'
			]
		);
		
		$this->add_control(
			'enable_category',
			[
				'label' => esc_html__('Show Category', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'mask_style',
			[
				'label' => esc_html__('Mask style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Theme default', 'dfd'),
					'colored' => esc_html__('Colored', 'dfd')
				],
				'default' => '',
				'condition' => [
					'products_style' => ['style-2', 'style-3']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'mask_color',
				'label' => esc_html__('Mask background', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => 
					'{{WRAPPER}} .products .woo-cover a.link'
				,
				'condition' => [
					'mask_style' => 'colored'
				]
			]
		);
		
		$this->add_control(
			'sale_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Sale label settings', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sale_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .onsale',
			]
		);

		$this->start_controls_tabs(
			'sale_color_background'
		);
		
		$this->start_controls_tab(
			'sale_color_background_normal',
			[
				'label' => esc_html__('Normal', 'dfd')
			]
		);
		
		$this->add_control(
			'sale_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .onsale' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'sale_bg_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .onsale' => 'background: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'sale_color_background_hover',
			[
				'label' => esc_html__('Hover', 'dfd')
			]
		);
		
		$this->add_control(
			'sale_color_hover',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .product:hover .onsale' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'sale_bg_color_hover',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .product:hover .onsale' => 'background: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

		$this->add_control(
			'price_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Price', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .product .woo-title-wrap .price-wrap .amount',
			]
		);

		$this->add_control(
			'price_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .product .woo-title-wrap .price-wrap .amount' => 'color: {{SCHEME}};'
				]
			]
		);
		
		if((!isset($dfd_ronneby['dfd_woocommerce_templates_path']) || $dfd_ronneby['dfd_woocommerce_templates_path'] != '_old')) {
			$this->add_control(
				'buttons_t_heading',
				[
					'type' => \Elementor\Controls_Manager::HEADING,
					'label' => esc_html__('Buttons', 'dfd'),
					'separator' => 'before'
				]
			);
			
			$this->add_control(
				'buttons_color_scheme',
				[
					'label' => esc_html__('Buttons color scheme', 'dfd'),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'' => esc_html__('Inherit from theme options', 'dfd'),
						'dfd-buttons-dark' => esc_html__('Dark', 'dfd'),
						'dfd-buttons-light' => esc_html__('Light', 'dfd')
					],
					'default' => ''
				]
			);
		}

		$this->end_controls_section();
		
	}

	protected function render() {
		global $woocommerce, $dfd_ronneby;
		
		$output = $buttons_wrap_class = $heading_class = '';
		
		$settings = $this->get_settings_for_display();

		if(!isset($settings['columns'])) : $settings['columns'] = 4; endif;

		$col = $settings['columns'];
		if($settings['columns'] == 2) {
			$settings['columns'] = 6;
		} elseif($settings['columns'] == 3) {
			$settings['columns'] = 4;
		} elseif($settings['columns'] == 4) {
			$settings['columns'] = 3;
		}
		$meta_query = '';
		if($settings['display_type'] == "recent_products"){
			$meta_query = WC()->query->get_meta_query();
		}
		if($settings['display_type'] == "top_rated_products"){
			$args['no_found_rows'] = 1;
			$args['meta_key'] = '_wc_average_rating';
			$orderby = 'meta_value_num';
			$order = 'DESC';
			$meta_query = WC()->query->get_meta_query();
			$args['tax_query'] = WC()->query->get_tax_query();
		}
		$args = array(
			'post_type'             => 'product',
			'post_status'           => 'publish',
			'ignore_sticky_posts'   => 1,
			'posts_per_page'        => $settings['per_page'],
			'orderby'               => $settings['order_by'],
			'order'                 => $settings['order'],
			'meta_query'            => $meta_query
		);
		if($settings['display_type'] == "featured_products") {
			if(function_exists('wc_get_product_visibility_term_ids')) {
				$product_visibility_term_ids = wc_get_product_visibility_term_ids();
				$args['tax_query'][] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['featured'],
				);
			} else {
				$args['meta_query'] = array(
					array(
						'key' 		=> '_visibility',
						'value' 	  => array('catalog', 'visible'),
						'compare'	=> 'IN'
					),
					array(
						'key' 		=> '_featured',
						'value' 	  => 'yes'
					)
				);
			}
		}
		if($settings['display_type'] == "sale_products"){
			if(function_exists('wc_get_product_ids_on_sale')) {
				$product_ids_on_sale = wc_get_product_ids_on_sale();
			} else {
				$product_ids_on_sale = woocommerce_get_product_ids_on_sale();
			}
			$meta_query = array();
			$meta_query[] = $woocommerce->query->visibility_meta_query();
			$meta_query[] = $woocommerce->query->stock_status_meta_query();
			$args['meta_query'] = $meta_query;
			$args['post__in'] = $product_ids_on_sale;
		}
		if($settings['display_type'] == "best_selling_products"){
			$args['meta_key'] = 'total_sales';
			$args['orderby'] = 'meta_value_num';
			$args['meta_query'] = array(
				array(
					'key' 		=> '_visibility',
					'value' 	=> array( 'catalog', 'visible' ),
					'compare' 	=> 'IN'
				)
			);
		}
		if($settings['display_type'] == "product_categories"){
			$product_categories = array();
			foreach ($this->get_dfd_product_category() as $slug => $name) {
				if($settings['product_category_' . $slug] == 'yes') {
					$product_categories[] = $slug;
				}
			}
			$args['tax_query'] = array(
				array(
					'taxonomy' 	 => 'product_cat',
					'terms' 		=> $product_categories,
					'field' 		=> 'slug',
					'operator' 	 => 'IN'
				)
			);
		}

		if($settings['buttons_color_scheme'] != '') {
			$buttons_wrap_class .= $settings['buttons_color_scheme'];
		} elseif(!isset($dfd_ronneby['dfd_woocommerce_templates_path']) || $dfd_ronneby['dfd_woocommerce_templates_path'] != '_old') {
			if(isset($dfd_ronneby['woo_products_buttons_color_scheme']) && !empty($dfd_ronneby['woo_products_buttons_color_scheme'])) {
				$buttons_wrap_class .= $dfd_ronneby['woo_products_buttons_color_scheme'];
			}
		}

		if(isset($dfd_ronneby['woo_category_content_alignment']) && !empty($dfd_ronneby['woo_category_content_alignment'])) {
			$heading_class .= ' '.str_replace('dfd-buttons', 'text',$dfd_ronneby['woo_category_content_alignment']);
		}

		$catalogue_mode = (isset($dfd_ronneby['woocommerce_catalogue_mode']) && $dfd_ronneby['woocommerce_catalogue_mode']);

		$column_class = 'columns dfd-loop-shop-responsive product ';
		$column_class .= Dfd_Ronneby_Front_Helpers::numToString($col);
		$column_class .= ' '.$settings['products_style'];

		$uniq_id = uniqid('dfd-products-grid-');

		$output .= '<div class="woocommerce columns-'.esc_attr($settings['columns']).'">';
			$output .= '<div id="'.esc_attr($uniq_id).'" class="products row">';
			$query = new WP_Query( $args );
				ob_start();
				if($query->have_posts()):
					while ( $query->have_posts() ) : $query->the_post();
					$subtitle = get_post_meta(get_the_ID(), 'dfd_product_product_subtitle', true);
					$post = get_post(get_the_id());
					$product_desc = $post->post_excerpt;

					if(isset($settings['excerpt_length']) && $settings['excerpt_length'] != '') {
						$product_desc = wp_trim_words($product_desc, $settings['excerpt_length'], '');
					}
					?>
						<div <?php post_class($column_class); ?>>
							<div class="prod-wrap <?php echo esc_attr($settings['content_alignment']) ?>">

								<?php echo do_action('woocommerce_before_shop_loop_item'); ?>
								<div class="woo-cover">
									<div class="prod-image-wrap woo-entry-thumb">
										<?php
										if(function_exists('woocommerce_show_product_loop_sale_flash')) {
											woocommerce_show_product_loop_sale_flash();
										}
										if(function_exists('woocommerce_template_loop_product_thumbnail')) {
											woocommerce_template_loop_product_thumbnail($settings['buttons_color_scheme'], $settings['content_alignment']);
										}
										?>
										<a href="<?php the_permalink(); ?>" class="link"></a>
									</div>
								</div>
								<?php if(!$catalogue_mode): ?>
									<div class="woo-title-wrap <?php echo esc_attr($heading_class) ?>">
										<div class="heading">
											<?php if(isset($settings['enable_category']) && $settings['enable_category'] == 'yes') { ?>
												<div class="dfd-folio-categories">
													<?php get_template_part('templates/woo', 'term'); ?>
												</div>
											<?php } ?>
											<div class="box-name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
											<?php if(!empty($subtitle)) : ?>
												<div class="subtitle"><?php echo $subtitle; ?></div>
											<?php endif; ?>
											<div class="woo-price-cart-wrap">
												<div class="price-wrap">
													<?php echo do_action('woocommerce_after_shop_loop_item_title'); ?>
												</div>
											</div>
											<div class="rating-section">
												<?php wc_get_template('loop/rating.php'); ?>
											</div>
										</div>
										<?php if(strcmp($settings['products_style'] , 'style-1') !== 0 && $product_desc != '') : ?>
											<div class="description">
												<?php echo $product_desc ?>
											</div>
										<?php endif; ?>
									</div>
									<?php if(strcmp($settings['products_style'] , 'style-2') === 0) : ?>
										<div class="additional-price <?php echo esc_attr($buttons_wrap_class . ' ' . $settings['content_alignment']) ?>">
											<div>
												<?php echo do_action('woocommerce_after_shop_loop_item_title') ?>
											</div>
										</div>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
					<?php endwhile;
				endif;
				$output .= ob_get_clean();

			$output .= '</div>';
			if(!empty($css_rules)) : ?>
				<script type="text/javascript">
					(function($) {
						"use strict";
						$('head').append('<style><?php echo $css_rules; ?></style>');
					})(jQuery);
				</script>
			<?php endif;
		$output .= '</div>';
		wp_reset_postdata();

		echo $output;
		
	}

}
