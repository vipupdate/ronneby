<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Testimonial extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_testimonial';
	}

	public function get_title() {
		return esc_html__('DFD Testimonial', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'new_testimonials';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_testimonial', [
				'label' => esc_html__('Testimonial', 'dfd')
			]
		);

		$this->add_control(
			'main_style', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Simple', 'dfd'),
					'style-2' => esc_html__('Decorated', 'dfd'),
					'style-3' => esc_html__('Background', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->add_control(
			'main_layout', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Middle line', 'dfd'),
					'layout-2' => esc_html__('Top line', 'dfd'),
					'layout-3' => esc_html__('Big quotes', 'dfd'),
					'layout-4' => esc_html__('Bottom line', 'dfd'),
					'layout-5' => esc_html__('Top info', 'dfd'),
					'layout-6' => esc_html__('Top image', 'dfd'),
					'layout-7' => esc_html__('Bottom quotes', 'dfd'),
					'layout-8' => esc_html__('Top quotes', 'dfd'),
					'layout-9' => esc_html__('Left image', 'dfd'),
					'layout-10' => esc_html__('Right image', 'dfd'),
					'layout-11' => esc_html__('Bottom title', 'dfd'),
					'layout-12' => esc_html__('Combined info', 'dfd'),
				],
				'default' => 'layout-1'
			]
		);
		
		$this->add_control(
			'align',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'main_layout!' => ['layout-9', 'layout-10', 'layout-11'],
				],
				'default' => 'text-center'
			]
		);

		$this->add_control(
			'image', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Author Image', 'dfd')
			]
		);

		$this->add_control(
			'author', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Author name', 'dfd')
			]
		);

		$this->add_control(
			'subtitle', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Subtitle', 'dfd')
			]
		);

		$this->add_control(
			'description', [
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('Description', 'dfd')
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_im_style', [
				'label' => esc_html__('Author thumbnail', 'dfd'),
			]
		);
		
		$this->add_control(
			'thumb_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .team-member-photo' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'thumb_border_width', [
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'thumb_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
			]
		);
		
		$this->add_control(
			'thumb_size', [
				'label' => esc_html__('Image size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'image_offset', [
				'label' => esc_html__('Image offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_layout' => ['layout-9', 'layout-10']
				],
				'selectors' => [
					'{{WRAPPER}} .layout-9 .image-wrap' => 'margin-right: {{SCHEME}}px;',
					'{{WRAPPER}} .layout-10 .image-wrap' => 'margin-left: {{SCHEME}}px;'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_del_style', [
				'label' => esc_html__('Delimiter style', 'dfd'),
			]
		);
		
		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_cont_style',
			[
				'label' => esc_html__('Content style', 'dfd'),
				'condition' => [
					'main_style!' => 'style-1'
				]
			]
		);
		
		$this->add_control(
			'bg_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd')
			]
		);
		
		$this->add_control(
			'bg_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_quot_style', [
				'label' => esc_html__('Quote symbol', 'dfd')
			]
		);
		
		$this->add_control(
			'quote_hide', [
				'label' => esc_html__('Disable quote', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'quote_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'quote_hide!' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'quote_size', [
				'label' => esc_html__('Size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'quote_hide!' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'quote_margin', [
				'label' => esc_html__('Margin from testimonial content', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'quote_hide!' => 'yes',
					'main_layout' => ['layout-1', 'layout-2', 'layout-4']
				]
			]
		);
		
		$this->add_control(
			'enabled_bg_decor', [
				'label' => esc_html__('Background decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'quote_hide!' => 'yes',
					'main_layout' => ['layout-1', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'bg_size', [
				'label' => esc_html__('Background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'quote_hide!' => 'yes',
					'enabled_bg_decor' => 'yes',
					'main_layout' => ['layout-1', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'bg_border_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'quote_hide!' => 'yes',
					'enabled_bg_decor' => 'yes',
					'main_layout' => ['layout-1', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'bg_background', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'condition' => [
					'quote_hide!' => 'yes',
					'enabled_bg_decor' => 'yes',
					'main_layout' => ['layout-1', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'icon_offset_bottom', [
				'label' => esc_html__('Bottom offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'quote_hide!' => 'yes',
					'enabled_bg_decor' => 'yes',
					'main_layout' => ['layout-1', 'layout-11']
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('Title HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('Subtitle HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .testimonial-content'
			]
		);

		$this->add_control(
			'content_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-content' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		
		$thumb_size = $avatar_html = $avatar_style = $subtitle_html = $output = $el_class =  '';
		$delimiter_html = $delimiter_style = $content_bg = $quote_style = $icon_html = $content_html = $css_rules = '';

		$settings = $this->get_settings_for_display();
		
		$uniqid = uniqid('dfd-testimonial-') . rand(1, 9999);
		$el_class .= ' '.esc_attr($uniqid);
		
		if (!empty($settings['image']['id'])) {
			if (empty($settings['thumb_size'])) {
				$settings['thumb_size'] = 80;
			}
			$image_src = wp_get_attachment_image_src($settings['image']['id'], 'full');
			$avatar = dfd_aq_resize($image_src[0], $settings['thumb_size'], $settings['thumb_size'], true, true, true);
			if ((!empty($settings['thumb_radius']) ) || (!empty($settings['thumb_border_width']) )) {
				$avatar_style .= 'style="';
				if (!empty($settings['thumb_radius'])) {
					$avatar_style .= 'border-radius:' . esc_html($settings['thumb_radius']) . 'px; ';
				}
				if (!empty($settings['thumb_border_width'])) {
					$avatar_style .= 'border:' . esc_html($settings['thumb_border_width']) . 'px solid ';
				}
				if (!empty($settings['thumb_color'])) {
					$avatar_style .= esc_html($settings['thumb_color']) . '; ';
				}
				$avatar_style .= '"';
			}
			$thumb_size = $settings['thumb_size'];
			$attr = Dfd_Theme_Helpers::get_image_attrs($avatar, $settings['image']['id'], $thumb_size, $thumb_size);
			global $dfd_ronneby;
			$cover_class = '';
			if (isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$cover_class = 'dfd-img-lazy-load';	
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $thumb_size $thumb_size'%2F%3E";
				$img_html = '<img ' . $avatar_style . ' src="' . $loading_img_src . '" data-src="' . esc_url($avatar) . '" width="' . $thumb_size . '" height="' . $thumb_size . '" ' . $attr . ' />';
			} else {
				$img_html = '<img ' . $avatar_style . ' src="' . esc_url($avatar) . '" width="' . $thumb_size . '" height="' . $thumb_size . '" ' . $attr . ' />';
			}

			$avatar_html = '<div class="image-wrap ' . $cover_class . '">';
			$avatar_html .= $img_html;
			$avatar_html .= '</div>';
		}

		$author_html = '<' . $settings['title_html_tag'] . ' class="testimonial-title" >' . esc_html($settings['author']) . '</' . $settings['title_html_tag'] . '>';

		$subtitle_html = '<' . $settings['subtitle_html_tag'] . ' class="subtitle testimonial-subtitle">' . esc_html($settings['subtitle']) . '</' . $settings['subtitle_html_tag'] . '>';

		if (( 'style-1' !== $settings['main_style'] && !empty($settings['bg_radius']) ) || ( 'style-1' !== $settings['main_style'] && !empty($settings['bg_color']) ) || ( '80' !== $settings['thumb_size'] )) {
			$content_bg .= 'style=" position: absolute;';
			if (!empty($settings['bg_radius'])) {
				$content_bg .= 'border-radius:' . $settings['bg_radius'] . 'px;';
			}
			if (!empty($settings['bg_color'])) {
				$content_bg .= 'background-color: ' . $settings['bg_color'] . ';';
			}
			if ('style-2' === $settings['main_style']) {
				if ('80' !== $settings['thumb_size']) {
					if ('layout-1' === $settings['main_layout']) {
						$margin = 21;
					} else {
						$margin = 0;
					}
					if ('80' !== $settings['thumb_size']) {
						if ('layout-1' === $settings['main_layout'] || 'layout-2' === $settings['main_layout'] || 'layout-3' === $settings['main_layout'] || 'layout-4' === $settings['main_layout']) {
							$bottom = ( intval((int) $settings['thumb_size'] / 2) + intval((int) $margin) );
							if (!empty($settings['thumb_border_width'])) {
								$bottom = intval((int) $settings['thumb_border_width']) + intval((int) $bottom);
							}
							$content_bg .= 'bottom:-' . $bottom . 'px;';
						} elseif ('layout-5' === $settings['main_layout'] || 'layout-6' === $settings['main_layout'] || 'layout-7' === $settings['main_layout'] || 'layout-8' === $settings['main_layout']) {
							$top = ( intval((int) $settings['thumb_size'] / 2) + intval((int) $margin) );
							if (!empty($settings['thumb_border_width'])) {
								$top = intval((int) $settings['thumb_border_width']) + intval((int) $top);
							}
							$content_bg .= 'top:' . $top . 'px;';
						}
					}
				}
			}
			$content_bg .= '"';
		}
		
		if ('style-1' !== $settings['main_style']) {
			$content_html .= '<div class="content-wrap-bg" ' . $content_bg . '></div>';
		}
		$content_html .= '<div class="dfd-testimonial-content testimonial-content">';
		$content_html .= wp_kses($settings['description'], array('br' => array()));
		$content_html .= '</div>';

		if ($settings['line_width'] || $settings['line_border'] || $settings['line_color']) {
			$delimiter_style .= 'style="';
			if ($settings['line_width']) {
				$delimiter_style .= 'width:' . $settings['line_width'] . 'px;';
			}
			if ($settings['line_border']) {
				$delimiter_style .= 'height:' . $settings['line_border'] . 'px;';
			}
			if ($settings['line_color']) {
				$delimiter_style .= 'background:' . $settings['line_color'];
			}
			$delimiter_style .= '"';
		}
		if ($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="testimonial-delimiter" ' . $delimiter_style . '></div></div>';
		}

		if ($settings['quote_color'] || $settings['quote_size'] || $settings['quote_margin']) {
			$quote_style .= 'style="';
			if (!empty($settings['quote_color'])) {
				$quote_style .= 'color:' . $settings['quote_color'] . '; ';
			}
			if (!empty($settings['quote_size'])) {
				$quote_style .= 'font-size:' . $settings['quote_size'] . 'px; ';
			}
			if (!empty($settings['quote_margin'])) {
				$quote_style .= 'margin-bottom:' . $settings['quote_margin'] . 'px; display: inline-block;';
			}
			$quote_style .= '"';
		}
		if ('yes' !== $settings['quote_hide']) {
			$icon_html .= '<div class="icon-wrap">';
			$icon_html .= '<i class="navicon-quote-right" ' . $quote_style . '></i>';
			$icon_html .= '</div>';
		}
		if ('layout-9' === $settings['main_layout'] || 'layout-10' === $settings['main_layout']) {
			$settings['align'] = '';
		}

		if ($settings['main_style'] === 'style-1' && $settings['main_layout'] === 'layout-12') {
			$settings['align'] = '';
		}

		if (isset($settings['enabled_bg_decor']) && $settings['enabled_bg_decor'] == 'yes') {
			$el_class .= ' simbol-with-bg';
			if (isset($settings['bg_size']) && $settings['bg_size'] != '') {
				$css_rules .= '.' . $uniqid . '.simbol-with-bg .icon-wrap i {width: ' . $settings['bg_size'] . 'px; height: ' . $settings['bg_size'] . 'px; line-height: ' . $settings['bg_size'] . 'px;}';
			}
			if (isset($settings['bg_border_radius']) && $settings['bg_border_radius'] != '') {
				$css_rules .= '.' . $uniqid . '.simbol-with-bg .icon-wrap i {border-radius: ' . $settings['bg_border_radius'] . 'px;}';
			}
			if (isset($settings['bg_background']) && !empty($settings['bg_background'])) {
				$css_rules .= '.' . $uniqid . '.simbol-with-bg .icon-wrap i {background: ' . $settings['bg_background'] . ';}';
			}
			if (isset($settings['icon_offset_bottom']) && $settings['icon_offset_bottom'] != '') {
				$css_rules .= '.' . $uniqid . '.simbol-with-bg .icon-wrap {padding-bottom: ' . $settings['icon_offset_bottom'] . 'px;}';
			}
		}

		/*		 * ************************
		 * Module Generation.
		 * *********************** */
		$output .= '<div id=' . esc_attr($uniqid) . ' class="dfd-testimonial-item ' . $settings['main_style'] . ' ' . $settings['main_layout'] . ' ' . $settings['align'] . ' ' . $el_class . '">';

		switch ($settings['main_layout']) {
			case 'layout-1':
				$output .= $icon_html;
				$output .= '<div class="pos-rel">';
				$output .= $content_html;
				$output .= '</div>';
				$output .= '<div class="centered-line">';
				$output .= $delimiter_html;
				$output .= $avatar_html;
				$output .= '</div>';
				$output .= $author_html;
				$output .= $subtitle_html;

				break;
			case 'layout-2':
			case 'layout-3':

				$output .= $icon_html;
				$output .= '<div class="pos-rel">';
				$output .= $content_html;
				if ('style-2' === $settings['main_style']) {
					$output .= $delimiter_html;
					$output .= '</div>';
				} else {
					$output .= '</div>';
					$output .= $delimiter_html;
				}
				$output .= $avatar_html;
				$output .= $author_html;
				$output .= $subtitle_html;

				break;
			case 'layout-4':
				$output .= $icon_html;
				$output .= '<div class="pos-rel">';
				$output .= $content_html;
				$output .= '</div>';
				$output .= $avatar_html;
				$output .= $author_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;

				break;
			case 'layout-5':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $author_html;
					$output .= $subtitle_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= $author_html;
					$output .= $subtitle_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $icon_html;

				break;
			case 'layout-6':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $author_html;
				$output .= $subtitle_html;
				$output .= $icon_html;

				break;
			case 'layout-7':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $delimiter_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= $delimiter_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $author_html;
				$output .= $subtitle_html;
				$output .= $icon_html;

				break;
			case 'layout-8':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $icon_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= $icon_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $author_html;
				$output .= $subtitle_html;

				break;
			case 'layout-9':
			case 'layout-10':
				$output .= $avatar_html;
				$output .= '<div class="content-wrap">';
				$output .= '<div class="pos-rel">';
				$output .= $content_html;
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= '<div class="title-wrap">';
				$output .= $icon_html;
				$output .= $author_html;
				$output .= '<br/>' . $subtitle_html;
				$output .= '</div>';
				$output .= '</div>';

				break;
			case 'layout-11':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $delimiter_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= $delimiter_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $icon_html;
				$output .= $author_html;
				$output .= $subtitle_html;

				break;
			case 'layout-12':
				if ('style-2' === $settings['main_style']) {
					$output .= '<div class="pos-rel">';
					$output .= $avatar_html;
					$output .= $content_html;
				} else {
					$output .= $avatar_html;
					$output .= '<div class="pos-rel">';
					$output .= $content_html;
				}
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $author_html;
				$output .= $subtitle_html;
				$output .= $icon_html;

				break;
		}

		$output .= '</div>';

		if ($css_rules != '') {
			$output .= '<script type="text/javascript">'
							. '(function($) {'
								. '$("head").append("<style>' . $css_rules . '</style>");'
							. '})(jQuery);'
					. '</script>';
		}
		echo $output;
	}

}
