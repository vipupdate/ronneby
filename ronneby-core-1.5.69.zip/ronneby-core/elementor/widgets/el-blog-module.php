<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Blog_Module extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_blog_module';
	}

	public function get_title() {
		return esc_html__('DFD Blog module', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_blog_posts';
	}

	/**
	 * Get single portfolio item.
	 * */
	private function get_dfd_single_post_item() {
		$options = array();

		$terms = array(
			'post_status' => 'publish',
			'post_type' => 'post',
			'posts_per_page' => -1
		);
		
		$query = new WP_Query($terms);
		
		foreach($query->posts as $post) {
			if(isset($post->ID) && isset($post->post_title)) {
				$options[$post->ID] = $post->post_title;
			}
		}

		return $options;
	}
	
	/**
	 * Get portfolio categories.
	 * */
	private function get_dfd_post_category() {
		$options = array();

		$terms = get_terms(
			array(
				'taxonomy' => 'category',
				'hide_empty' => true,
			)
		);
		foreach($terms as $term) {
			if(isset($term)) {
				if(isset($term->slug) && isset($term->name)) {
					$options[$term->slug] = $term->name;
				}
			}
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'dfd_blog_posts',
			[
				'label' => esc_html__('Blog posts', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'advanced' => esc_html__('Advanced', 'dfd'),
					'default' => esc_html__('Default', 'dfd'),
					'deployed' => esc_html__('Deployed', 'dfd'),
					'excerpts-overlay' => esc_html__('Excerpts overlay', 'dfd'),
					'featured' => esc_html__('Featured', 'dfd'),
					'hovered' => esc_html__('Hovered', 'dfd'),
					'masonry' => esc_html__('Masonry', 'dfd'),
					'recent' => esc_html__('Recent', 'dfd'),
					'simple' => esc_html__('Simple', 'dfd'),
					'standard' => esc_html__('Standard', 'dfd')
				],
				'default' => 'advanced'
			]
		);

		$this->add_control(
			'layout_type_grid_carousel',
			[
				'label' => esc_html__('Layout', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'fitRows' => esc_html__('Grid', 'dfd'),
					'carousel' => esc_html__('Carousel', 'dfd')
				],
				'condition' => [
					'style' => ['default', 'standard', 'advanced']
				],
				'default' => 'fitRows'
			]
		);
		
		$this->add_control(
			'items',
			[
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'loop' => esc_html__('Loop', 'dfd'),
					'single' => esc_html__('Single item', 'dfd')
				],
				'condition' => [
					'style' => ['masonry', 'simple', 'default', 'standard', 'advanced', 'hovered', 'deployed']
				],
				'default' => 'loop'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_post_items',
			[
				'label' => esc_html__('Select items', 'dfd')
			]
		);
		
		$this->add_control(
			'single_custom_post_item',
			[
				'label' => esc_html__('Item to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $this->get_dfd_single_post_item(),
				'condition' => [
					'items' => ['single']
				]
			]
		);
		
		if (!empty($this->get_dfd_post_category())) {
			foreach ($this->get_dfd_post_category() as $slug => $name) {
				$this->add_control(
					'post_categories_' . $slug,
					[
						'label' => $name,
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'default' => 'no',
						'condition' => [
							'items' => ['loop']
						]
					]
				);
			}
		}
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_post_items_settings',
			[
				'label' => esc_html__('Post items settings', 'dfd')
			]
		);
		
		$this->add_control(
			'posts_to_show',
			[
				'label' => esc_html__('Items to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'items' => ['loop']
				],
				'default' => 6
			]
		);
		
		$this->add_control(
			'items_offset',
			[
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced']
				]
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Content alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced', 'hovered']
				],
				'default' => 'text-left'
			]
		);
		
		$this->add_control(
			'content_full_width',
			[
				'label' => esc_html__('Content width', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html('50%', 'dfd'),
					'hovered-full-width' => esc_html('100%', 'dfd')
				],
				'condition' => [
					'style' => 'hovered'
				]
			]
		);
		
		$this->add_control(
			'content_effect',
			[
				'label' => esc_html__('Content visibility', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'desc-hover' => esc_html__('On hover', 'dfd'),
					'' => esc_html__('Permanent', 'dfd')
				],
				'condition' => [
					'style' => ['simple', 'advanced']
				],
				'default' => 'desc-hover'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'layout_settings_heading',
			[
				'label' => esc_html__('Layout settings', 'dfd'),
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced']
				],
			]
		);
		
		$this->add_control(
			'columns',
			[
				'label' => esc_html__('Number of columns', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced']
				]
			]
		);
		
		$this->add_control(
			'enabled_autoslideshow',
			[
				'label' => esc_html__('Auto slideshow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'layout_type_grid_carousel' => 'carousel'
				],
			]
		);

		$this->add_control(
			'carousel_slideshow_speed',
			[
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_autoslideshow' => 'yes',
					'layout_type_grid_carousel' => 'carousel'
				],
				'default' => 5000
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'el_post_thumbs_settings',
			[
				'label' => esc_html__('Thumbs settings', 'dfd')
			]
		);
		
		$this->add_control(
			'image_width',
			[
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['default', 'standard', 'advanced']
				],
				'default' => 900
			]
		);

		$this->add_control(
			'image_height',
			[
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'style' => ['default', 'standard', 'advanced']
				],
				'default' => 600
			]
		);
		
		$this->start_controls_tabs(
			'post_mask_background', [
				'condition' => [
					'style' => ['simple', 'advanced']
				]
			]
		);
		
		$this->start_controls_tab(
			'post_mask_background_normal',
			[
				'label' => esc_html__('Normal', 'dfd'),
				'condition' => [
					'style' => ['simple', 'advanced']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'post_mask_background_style',
				'label' => esc_html__('Mask background', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => 
					'{{WRAPPER}} .dfd-blog-posts-module.dfd-blog-loop.advanced .post .cover .entry-media .entry-thumb:before'
				,
				'condition' => [
					'style' => 'advanced'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'post_mask_background_hover',
			[
				'label' => esc_html__('Hover', 'dfd'),
				'condition' => [
					'style' => ['simple', 'advanced']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'hover_post_mask_background_style',
				'label' => esc_html__('Hover mask background', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => 
					'{{WRAPPER}} .dfd-blog-posts-module.dfd-blog-loop.advanced .post .cover .entry-media:hover .entry-thumb:before'
				,
				'condition' => [
					'style' => 'advanced'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_portfolio_content_elements',
			[
				'label' => esc_html__('Content elements', 'dfd')
			]
		);
		
		$this->add_control(
			'sort_panel',
			[
				'label' => esc_html__('Sort Panel', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'terms' => [
								['name' => 'style', 'operator' => '===', 'value' => 'masonry'],
								['name' => 'items', 'operator' => '===', 'value' => 'loop']
							]
						],
						[
							'terms' => [
								['name' => 'style', 'operator' => 'in', 'value' => ['default', 'standard', 'advanced']],
								['name' => 'layout_type_grid_carousel', 'value' => 'fitRows'],
								['name' => 'items', 'operator' => '===', 'value' => 'loop']
							]
						]
					]
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_category',
			[
				'label' => esc_html__('Category', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced', 'recent', 'featured', 'excerpts-overlay', 'simple', 'hovered', 'deployed']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_title',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'default', 'standard', 'advanced', 'recent', 'featured', 'excerpts-overlay', 'deployed']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_numeric_title',
			[
				'label' => esc_html__('Number decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => 'deployed'
				]
			]
		);
		
		$this->add_control(
			'enabled_meta',
			[
				'label' => esc_html__('Meta', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'advanced', 'recent', 'featured', 'excerpts-overlay', 'deployed']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_excerpt',
			[
				'label' => esc_html__('Excerpt', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'advanced', 'recent', 'featured', 'excerpts-overlay', 'deployed']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'dropcap_excerpt',
			[
				'label' => esc_html__('Dropcap for excerpt', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => 'excerpts-overlay'
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_read_more',
			[
				'label' => esc_html__('Read more button', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'recent', 'featured', 'excerpts-overlay', 'hovered', 'deployed']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'read_more_word',
			[
				'label' => esc_html__('Read More Word', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'enabled_read_more' => 'yes'
				],
				'default' => 'Read more'
			]
		);
		
		$this->add_control(
			'enabled_share',
			[
				'label' => esc_html__('Share buttons', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'recent', 'featured', 'excerpts-overlay', 'deployed']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'enabled_comments',
			[
				'label' => esc_html__('Comments', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'advanced', 'featured', 'recent', 'deployed']
				],
				'default' => 'yes'
			]
		);

		$this->add_control(
			'enabled_likes',
			[
				'label' => esc_html__('Likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'advanced', 'featured', 'recent', 'deployed']
				],
				'default' => 'yes'
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_element_settings_options',
			[
				'label' => esc_html__('Element settings', 'dfd')
			]
		);
		
		$this->add_control(
			'enabled_anim_com_like',
			[
				'label' => esc_html__('Animate comments and likes', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'style' => ['masonry', 'standard', 'default', 'advanced', 'featured', 'excerpts-overlay', 'recent', 'deployed']
				],
				'default' => 'yes'
			]
		);
		
		$this->add_control(
			'sort_alignment',
			[
				'label' => esc_html__('Sort panel alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'sort_panel' => 'yes'
				],
				'default' => 'text-center'
			]
		);
		
		$this->add_control(
			'heading_position',
			[
				'label' => esc_html__('Heading position', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'bottom' => esc_html__('Under media', 'dfd'),
					'top' => esc_html__('Above media', 'dfd')
				],
				'condition' => [
					'style' => ['masonry', 'featured', 'recent', 'deployed']
				],
				'default' => 'bottom'
			]
		);
		
		$this->add_control(
			'share_style',
			[
				'label' => esc_html__('Share style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'animated' => esc_html__('Animated', 'dfd'),
					'simple' => esc_html__('Simple', 'dfd')
				],
				'condition' => [
					'enabled_share' => 'yes'
				],
				'default' => 'animated'
			]
		);
		
		$this->add_control(
			'read_more_style',
			[
				'label' => esc_html__('Read more style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'simple' => esc_html__('Simple', 'dfd'),
					'chaffle' => esc_html__('Shuffle', 'dfd'),
					'slide-up' => esc_html__('Slide up', 'dfd')
				],
				'condition' => [
					'enabled_read_more' => 'yes'
				],
				'default' => 'simple'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);
		
		$this->add_control(
			'title_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Title', 'dfd')
			]
		);
		
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-title.widget-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-blog-title.widget-title',
			]
		);

		$this->add_control(
			'additional_news_title_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Additional news title', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'style' => ['featured', 'excerpts-overlay', 'recent', 'deployed']
				],
			]
		);
		
		$this->add_control(
			'additional_news_title_html_tag',
			[
				'label' => esc_html__('HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'condition' => [
					'style' => ['featured', 'excerpts-overlay', 'recent', 'deployed']
				],
				'default' => 'div'
			]
		);
		
		$this->add_control(
			'additional_news_title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition' => [
					'style' => ['featured', 'excerpts-overlay', 'recent', 'deployed']
				],
				'selectors' => [
					'{{WRAPPER}} .box-name.widget-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'additional_news_title_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'condition' => [
					'style' => ['featured', 'excerpts-overlay', 'recent', 'deployed']
				],
				'selector' => '{{WRAPPER}} .box-name.widget-title',
			]
		);
		
		$this->add_control(
			'number_title_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Number with title', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'enabled_numeric_title' => 'yes'
				],
			]
		);
		
		$this->add_control(
			'number_title_font_options_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition' => [
					'enabled_numeric_title' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop.with-number-decor .dfd-number-decor' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'number_title_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'condition' => [
					'enabled_numeric_title' => 'yes'
				],
				'selector' => '{{WRAPPER}} .dfd-blog-loop.with-number-decor .dfd-number-decor',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'post_styles_options',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Styles', 'dfd')
			]
		);
		
		$this->add_control(
			'readmore_share_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Read more & share block styles', 'dfd')
			]
		);
		
		$this->add_control(
			'readmore_share_before_offset',
			[
				'label' => esc_html__('Offset before block', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-read-share' => 'margin-top: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'readmore_share_border_style',
			[
				'label' => esc_html__('Border style', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html('None', 'dfd'),
					'solid' => esc_html('Solid', 'dfd'),
					'dotted' => esc_html('Dotted', 'dfd'),
					'dashed' => esc_html('Dashed', 'dfd'),
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'readmore_share_border_width',
			[
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'readmore_share_border_style!' => ''
				]
			]
		);
							
		$this->add_control(
			'readmore_share_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'condition' => [
					'readmore_share_border_style!' => ''
				]
			]
		);
		
		$this->start_controls_tabs(
			'post_readmore_color', [
				'separator' => 'before',
				'condition' => [
					'style' => ['advanced', 'default', 'featured', 'excerpts-overlay', 'hovered', 'masonry', 'recent', 'standard', 'deployed']
				]
			]
		);
		
		$this->start_controls_tab(
			'post_readmore_color_normal',
			[
				'label' => esc_html__('Normal', 'dfd'),
				'condition' => [
					'style' => ['advanced', 'default', 'featured', 'excerpts-overlay', 'hovered', 'masonry', 'recent', 'standard', 'deployed']
				]
			]
		);
		
		$this->add_control(
			'readmore_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Read more color', 'dfd'),
				'condition' => [
					'style' => ['advanced', 'default', 'featured', 'excerpts-overlay', 'hovered', 'masonry', 'recent', 'standard', 'deployed']
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'post_readmore_color_hover',
			[
				'label' => esc_html__('Hover', 'dfd'),
				'condition' => [
					'style' => ['advanced', 'default', 'featured', 'excerpts-overlay', 'hovered', 'masonry', 'recent', 'standard', 'deployed']
				]
			]
		);
		
		$this->add_control(
			'readmore_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Read more color', 'dfd'),
				'condition' => [
					'style' => ['advanced', 'default', 'featured', 'excerpts-overlay', 'hovered', 'masonry', 'recent', 'standard', 'deployed']
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_control(
			'share_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Share block backgrount', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-share-cover .dfd-blog-share-popup-wrap .dfd-share-title' => 'background-color: {{SCHEME}};'
				],
				'condition' => [
					'share_style' => 'animated'
				],
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'share_block_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Share block color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-share-cover .dfd-blog-share-popup-wrap .dfd-share-title' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'share_style' => 'animated'
				]
			]
		);
		
		$this->add_control(
			'share_border_width',
			[
				'label' => esc_html__('Share block border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'share_style' => 'animated'
				]
			]
		);
		
		$this->add_control(
			'share_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Share block border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-share-cover .dfd-blog-share-popup-wrap .dfd-share-title:before' => 'border-color: {{SCHEME}};'
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
						'terms' => [
								['name' => 'share_border_width', 'operator' => '!=', 'value' => ''],
							]
						],
						[
						'terms' => [
								['name' => 'share_border_width', 'operator' => '!=', 'value' => 0]
							]
						],
					]
				]
			]
		);
		
		$this->add_control(
			'category_label_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Category label styling', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'category_padding',
			[
				'label' => esc_html__('Padding', 'dfd'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a, {{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->start_controls_tabs(
			'category_colors', [
				'separator' => 'before',
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->start_controls_tab(
			'category_colors_normal',
			[
				'label' => esc_html__('Normal', 'dfd'),
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'category_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a, {{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a' => 'background-color: {{SCHEME}};'
				],
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'category_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a, {{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'category_colors_hover',
			[
				'label' => esc_html__('Hover', 'dfd'),
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'category_background_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a:hover, {{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a:hover' => 'background-color: {{SCHEME}};'
				],
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'category_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a:hover, {{WRAPPER}} .dfd-blog-loop .dfd-blog-wrap .post .cover .dfd-news-categories .byline.category a:hover' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'enabled_category' => 'yes'
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $el_class = $css_rules = $js_scripts = $data_atts = $article_data_atts = $extra_class_name = '';
		
		$sort_panel = false;
		
		$settings = $this->get_settings_for_display();

		$el_class .= ' ' . $settings['style'];

		$uniqid = uniqid('dfd-blog-module-');

		$el_class .= ' '.$uniqid;

		if(isset($settings['readmore_share_border_style']) && $settings['readmore_share_border_style'] != '') {
			$css_rules .= '#'.$uniqid.' .dfd-read-share {border-top-style: '.esc_js($settings['readmore_share_border_style']).'; border-bottom-style: '.esc_js($settings['readmore_share_border_style']).';}';
			$css_rules .= '#'.$uniqid.'.dfd-blog-loop.simple .post .cover {border-bottom-style: '.esc_js($settings['readmore_share_border_style']).';}';
		} else {
			$css_rules .= '#'.$uniqid.' .dfd-read-share, #'.$uniqid.'.dfd-blog-loop.simple .post .cover {border-style: none;}';
		}
		if(isset($settings['readmore_share_border_width']) && $settings['readmore_share_border_width'] != '') {
			$css_rules .= '#'.$uniqid.' .dfd-read-share {border-top-width: '.esc_js($settings['readmore_share_border_width']).'px; border-bottom-width: '.esc_js($settings['readmore_share_border_width']).'px;}';
			$css_rules .= '#'.$uniqid.'.dfd-blog-loop.simple .post .cover {border-bottom-width: '.esc_js($settings['readmore_share_border_width']).'px;}';
		}
		if(isset($settings['readmore_share_border_color']) && !empty($settings['readmore_share_border_color'])) {
			$css_rules .= '#'.$uniqid.' .dfd-read-share {border-top-color: '.esc_js($settings['readmore_share_border_color']).'; border-bottom-color: '.esc_js($settings['readmore_share_border_color']).';}';
			$css_rules .= '#'.$uniqid.'.dfd-blog-loop.simple .post .cover {border-bottom-color: '.esc_js($settings['readmore_share_border_color']).';}';
		}
		if(isset($settings['read_more_style']) && $settings['read_more_style'] != 'slide-up') {
			if(isset($settings['readmore_color']) && !empty($settings['readmore_color'])) {
				$css_rules .= '#'.$uniqid.' .dfd-read-share .read-more-wrap a:not(.slide-up) {color: '.esc_js($settings['readmore_color']).';}';
			}
			if(isset($settings['readmore_hover_color']) && !empty($settings['readmore_hover_color'])) {
				$css_rules .= '#'.$uniqid.' .dfd-read-share .read-more-wrap a:not(.slide-up):hover {color: '.esc_js($settings['readmore_hover_color']).';}';
			}
		}else{
			if(isset($settings['readmore_color']) && !empty($settings['readmore_color']) && isset($settings['readmore_hover_color']) && !empty($settings['readmore_hover_color'])) {
				$css_rules .= '#'.$uniqid.' .more-button.slide-up {text-shadow: 0 0 '.esc_js($settings['readmore_color']).', 0 16px '.esc_js($settings['readmore_hover_color']).';}';
				$css_rules .= '#'.$uniqid.' .more-button.slide-up:hover {text-shadow: 0 -16px '.esc_js($settings['readmore_color']).', 0 0 '.esc_js($settings['readmore_hover_color']).';}';
			}
		}
		if(isset($settings['share_border_width']) && $settings['share_border_width'] != '') {
			$css_rules .= '#'.$uniqid.' .dfd-share-cover .dfd-blog-share-popup-wrap .dfd-share-title:before {content: \"\"; border-style: solid; border-width: '.esc_js($settings['share_border_width']).'px;}';
		}
		$el_class .= ' '.$settings['style'];
		if(isset($settings['content_full_width']) && $settings['content_full_width'] != '') {
			$el_class .= ' '.$settings['content_full_width'];
		}
		if(isset($settings['enabled_numeric_title']) && $settings['enabled_numeric_title'] == 'yes') {
			$el_class .= ' with-number-decor';
		}
		
		if($settings['items'] == 'single' && isset($settings['single_custom_post_item']) && !empty($settings['single_custom_post_item'])) {
			$args = array(
				'p' => $settings['single_custom_post_item']
			);
			$columns = 1;
		} else {
			$sticky = get_option('sticky_posts');
			$post_categories = array();
			foreach ($this->get_dfd_post_category() as $slug => $name) {
				if($settings['post_categories_' . $slug] == 'yes') {
					$post_categories[] = $slug;
				}
			}
			if(!empty($post_categories)){
				$args = array(
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field' => 'slug',
						'terms' => $post_categories,
					)
				);
			} else {
				$args = array(
					'posts_per_page' => $settings['posts_to_show'],
					'ignore_sticky_posts' => 1,
					'post__not_in' => $sticky,
				);
			}
		}
		
		$enable_cat = ($settings['enabled_category'] == 'yes') ? true : false;

		$enable_title = ($settings['enabled_title'] == 'yes') ? true : false;

		$enable_meta = ($settings['enabled_meta'] == 'yes') ? true : false;

		$enable_excerpt = ($settings['enabled_excerpt'] == 'yes') ? true : false;

		$dropcap_excerpt = ($settings['dropcap_excerpt'] == 'yes') ? true : false;

		$read_more = ($settings['enabled_read_more'] == 'yes') ? true : false;

		$share = ($settings['enabled_share'] == 'yes') ? true : false;

		$comments = ($settings['enabled_comments'] == 'yes') ? true : false;

		$likes = ($settings['enabled_likes'] == 'yes')? true : false;

		$read_more_word = !empty($settings['read_more_word']) ? esc_html($settings['read_more_word']) : __('More', 'dfd');

		$media_class = ($settings['enabled_anim_com_like'] == 'yes') ? 'comments-like-hover' : '';
		
		$wp_query = new WP_Query($args);
		
		$output .= '<div class="dfd-module-wrapper dfd-elementor-widget">';

			ob_start();
			
			include(DFD_RONNEBY_PLUGIN_PATH .'elementor/templates/blog_posts/'. $settings['style'].'.php');

			$output .= ob_get_clean();

			if(!empty($css_rules) || !empty($js_scripts)) {
				$output .= '<script type="text/javascript">
								(function($) {';

				if(!empty($css_rules)) {
					$output .= '$("head").append("<style>'.$css_rules.'</style>");';
				}
				if(!empty($js_scripts)) {
					$output .= $js_scripts;
				}

				$output .= '})(jQuery);
							</script>';
			}

		$output .= '</div>';

		echo $output;
		
	}

}
