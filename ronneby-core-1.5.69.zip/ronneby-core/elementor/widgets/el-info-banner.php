<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Info_Banner extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_info_banner';
	}

	public function get_title() {
		return esc_html__('DFD Info banner', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'info_banner';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_info_banner', [
				'label' => esc_html__('Info banner', 'dfd')
			]
		);

		$this->add_control(
			'style', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-01' => esc_html__('Simple', 'dfd'),
					'style-02' => esc_html__('Overlay', 'dfd'),
					'style-03' => esc_html__('Title offset', 'dfd'),
					'style-04' => esc_html__('Top', 'dfd'),
					'style-05' => esc_html__('Right', 'dfd'),
					'style-06' => esc_html__('Left', 'dfd'),
					'style-07' => esc_html__('Centered', 'dfd'),
					'style-08' => esc_html__('Hovered content', 'dfd'),
					'style-09' => esc_html__('Hovered description', 'dfd'),
					'style-10' => esc_html__('Hovered center', 'dfd'),
					'style-11' => esc_html__('Hovered overlay', 'dfd'),
					'style-12' => esc_html__('Hovered bottom', 'dfd'),
					'style-13' => esc_html__('Hovered top', 'dfd')
				],
				'default' => 'style-01'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_info_banner_content', [
				'label' => esc_html__('Content', 'dfd')
			]
		);
		
		$this->add_control(
			'image', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd')
			]
		);
		
		$this->add_control(
			'img_width', [
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
//				'selectors' => [
//					'{{WRAPPER}} .team-member-photo' => 'border-radius: {{SCHEME}}px;'
//				],
				'default' => 400
			]
		);
		
		$this->add_control(
			'img_height', [
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
//				'selectors' => [
//					'{{WRAPPER}} .team-member-photo' => 'border-radius: {{SCHEME}}px;'
//				],
				'default' => 350
			]
		);
		
		$this->add_control(
			'title', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Title', 'dfd')
			]
		);

		$this->add_control(
			'subtitle', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Subtitle', 'dfd')
			]
		);

		$this->add_control(
			'content', [
				'label' => esc_html__('Content', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('Content', 'dfd')
			]
		);
		
		$this->add_control(
			'read_more', [
				'label' => esc_html__('Apply link to', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('No Link', 'dfd'),
					'box' => esc_html__('Complete Box', 'dfd'),
					'title' => esc_html__('Box Title', 'dfd'),
					'more' => esc_html__('Read More', 'dfd')
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'link',
			[
				'label' => esc_html__('Add link', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'read_more!' => ''
				]
			]
		);
		
		$this->add_control(
			'readmore_show', [
				'label' => esc_html__('Read more', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'read_more!' => ''
				]
			]
		);
		
		$this->add_control(
			'more_show', [
				'label' => esc_html__('Button visibility', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'permanent' => esc_html__('Permanent', 'dfd'),
					'hover' => esc_html__('Show on hover', 'dfd')
				],
				'default' => 'permanent',
				'condition' => [
					'read_more!' => '',
					'readmore_show' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'readmore_style', [
				'label' => esc_html__('Read more style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'read-more-01' => esc_html__('Text link', 'dfd'),
					'read-more-02' => esc_html__('Lines', 'dfd'),
					'read-more-03' => esc_html__('Dots', 'dfd'),
					'read-more-04' => esc_html__('Slashes', 'dfd'),
					'read-more-05' => esc_html__('Text + Arrow', 'dfd'),
					'read-more-06' => esc_html__('Arrow', 'dfd'),
					'read-more-07' => esc_html__('Circle', 'dfd'),
					'read-more-08' => esc_html__('Button', 'dfd')
				],
				'default' => 'read-more-01',
				'condition' => [
					'read_more!' => '',
					'readmore_show' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'readmore_text', [
				'label' => esc_html__('Read more text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Read more', 'dfd'),
				'condition' => [
					'read_more!' => '',
					'readmore_show' => 'yes',
					'readmore_style' => ['read-more-01', 'read-more-05', 'read-more-08']
				]
			]
		);

		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__('Horizontal alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'style' => ['style-01', 'style-02', 'style-03', 'style-04', 'style-07', 'style-08', 'style-09', 'style-10', 'style-11', 'style-12', 'style-13'],
				],
				'default' => 'text-left'
			]
		);

		$this->add_control(
			'vertical_content_alignment', [
				'label' => esc_html__('Vertical alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'title-top' => esc_html__('Top', 'dfd'),
					'' => esc_html__('Middle', 'dfd'),
					'title-bottom' => esc_html__('Bottom', 'dfd')
				],
				'default' => 'title-top',
				'condition' => [
					'style' => 'style-07'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_info_banner_style', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Style', 'dfd'),
			]
		);
		
		$this->add_control(
			'el_info_banner_style_image_effect',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Image effect', 'dfd')
			]
		);
		
		$this->add_control(
			'image_effect', [
				'label' => esc_html__('Image effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('None', 'dfd'),
					'panr' => esc_html__('Easy image parallax', 'dfd'),
					'dfd-image-blur' => esc_html__('Blur', 'dfd'),
					'dfd-image-scale' => esc_html__('Grow', 'dfd'),
					'dfd-image-scale-rotate' => esc_html__('Grow with rotation', 'dfd')
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'el_info_banner_style_overlay_color',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Overlay color', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__('Background color', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .overlay'
			]
		);
		
		$this->add_control(
			'shadow', [
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'image_effect' => ''
				]
			]
		);
		
		$this->add_control(
			'shadow_style', [
				'label' => esc_html__('Shadow visibility', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'permanent' => esc_html__('Permanent shadow', 'dfd'),
					'hover' => esc_html__('Shadow on hover', 'dfd')
				],
				'default' => 'permanent',
				'condition' => [
					'shadow' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'el_info_banner_style_delimiter_options',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Delimiter options', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'delimiter_style', [
				'label' => esc_html__('Delimiter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Solid', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd')
				],
				'default' => '',
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-bottom-style: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Title typography', 'dfd'),
			]
		);
		
		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-box-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .info-box-title.feature-title'
			]
		);
		
		$this->add_control(
			'subtitle_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .info-box-subtitle.widget-sub-title.subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .info-box-subtitle.widget-sub-title.subtitle'
			]
		);

		$this->add_control(
			'content_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Content typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'content_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .description' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'content-typography',
				'label' => esc_html__('Typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .description'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$output = $el_class = $shadow_class = $link_atts = $img_width = $img_height = '';
		$overlay_output = $delimiter_html = $content_html = $read_more_html = '';
		$title_html = $subtitle_html = $image_html = '';

		$settings = $this->get_settings_for_display();
	
//		$style =  = $subtitle = $image = $more_show = $readmore_style = $readmore_text = $read_more = $link = '';
//		 =  =  =  =  = $fill_color_start = $fill_color_end = $shadow =  = '';
//		$title_font_options = $subtitle_font_options = $font_options = $use_google_fonts = $custom_fonts =  = $subtitle_use_google_fonts = '';
//		 =  =  = $subtitle_custom_fonts = $vertical_content_alignment = '';
//		 =  =  =  =  =  = '';
//		$content_alignment = $image_effect = '';

		if(isset($settings['shadow']) && ($settings['shadow'] === 'yes')) {
			if(isset($settings['shadow_style']) && ($settings['shadow_style'] === 'hover')) {
				$shadow_class .= ' module-shadow-hover';
			} else {
				$shadow_class .= ' module-shadow-permanent';
			}
		}

		if(!empty($settings['link'])) {
			$link_atts .= 'href="' . (!empty($settings['link']['url']) ? esc_url($settings['link']['url']) : '#') . '"';
			$link_atts .= ' target="' . (!empty($settings['link']['is_external']) ? '_blank' : '_self' ) . '"';
			$link_atts .= !empty($settings['link']['nofollow']) ? ' rel="nofollow"' : '';
			$link_atts .= !empty($settings['link']['custom_attributes']) ? ' ' . esc_attr($settings['link']['custom_attributes']) : '';
		}
		
		if(!empty($settings['title'])) {
			if($settings['link'] && $settings['read_more'] === 'title') {
				$title_html .= '<'.$settings['title_html_tag'].' class="info-box-title feature-title"><a '.$link_atts.'>' . esc_html( $settings['title'] ) . '</a></'.$settings['title_html_tag'].'>';
			} else {
				$title_html .= '<'.$settings['title_html_tag'].' class="info-box-title feature-title">' . esc_html( $settings['title'] ) . '</'.$settings['title_html_tag'].'>';
			}
		}
		
		if(!empty($settings['subtitle'])) {
			$subtitle_html .= '<'.$settings['subtitle_html_tag'].' class="info-box-subtitle widget-sub-title subtitle">' . esc_html($settings['subtitle']) . '</'.$settings['subtitle_html_tag'].'>';
		}
		
		if(!empty($settings['image']['id'])) {
			$image_src = wp_get_attachment_image_src($settings['image']['id'], 'full');
			if(isset($settings['img_width']) && $settings['img_width'] == '') {
				$img_width = 400;
			} else {
				$img_width = $settings['img_width'];
			}
			if(isset($settings['img_height']) && $settings['img_height'] == '') {
				$img_height = 350;
			} else {
				$img_height = $settings['img_height'];
			}
			$image_url = dfd_aq_resize($image_src[0], $img_width, $img_height, true, true, true);

			if(!$image_url) {
				$image_url = $image_src[0];
			}

			$attr = Dfd_Theme_Helpers::get_image_attrs($image_src[0], $settings['image']['id'], $img_width, $img_height);

			global $dfd_ronneby;
			$cover_class = '';
			if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$cover_class = 'dfd-img-lazy-load';
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $img_width $img_height'%2F%3E";
				$img_html = '<img src="'.$loading_img_src.'" data-src="' . esc_url( $image_url ) . '" '.$attr.' width="'.esc_attr($img_width).'" height="'.esc_attr($img_height).'" class="info-banner-image' . esc_attr($shadow_class) . '" />';
			} else {
				$img_html = '<img src="' . esc_url( $image_url ) . '" '.$attr.' width="'.esc_attr($img_width).'" height="'.esc_attr($img_height).'" class="info-banner-image' . esc_attr($shadow_class) . '" />';
			}

			$image_html .= '<div class="image-cover '.esc_attr($cover_class).'">'.$img_html.'</div>';

			$overlay_output = '<div class="overlay"></div>';
			if($settings['link'] && ($settings['read_more'] === 'image-link')) {
				$overlay_output .= '<a class="image-custom-link" '.$link_atts.'></a>';
			}
		}
		
		if($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter"></div></div>';
		} else {
			$el_class .= ' delimiter-hidden';
		}

		if(!empty($settings['content'])) {
			$content_html .= '<div class="description">' . $settings['content'] . '</div>';
		}

		if(isset($settings['readmore_show']) && $settings['readmore_show'] === 'yes') {
			if($settings['link'] && $settings['read_more'] === 'more') {
				$more_open = '<div class="dfd-module-readmore"><a '.$link_atts.' class="' . esc_attr($settings['readmore_style']) . '">';
				$more_close = '</a></div>';
			} else {
				$more_open = '<div class="dfd-module-readmore"><span class="' . $settings['readmore_style'] . '">';
				$more_close = '</span></div>';
			}
			if($settings['readmore_style'] === 'read-more-01') {
				$read_more_html .= $more_open . $settings['readmore_text'] . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-02' || $settings['readmore_style'] === 'read-more-03' || $settings['readmore_style'] === 'read-more-04') {
				$read_more_html .= $more_open . '<span></span><span></span><span></span>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-05') {
				$read_more_html .= $more_open . '<i class="dfd-icon-down_right"></i><span>' . $settings['readmore_text'] . '</span><i class="dfd-icon-down_right"></i>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-06') {
				$read_more_html .= $more_open . '<i class="dfd-icon-down_right"></i>' . $more_close;
			} elseif ($settings['readmore_style'] === 'read-more-07') {
				$read_more_html .= $more_open . '<i class="dfd-added-font-icon-right-open"></i>' . $more_close;
			} else {
				$read_more_html .= $more_open . $settings['readmore_text'] . $more_close;
			}
		}

		if($settings['more_show'] === 'hover') {
			$el_class .= ' more-hover';
		}

		if($settings['image_effect'] != '') {
			$el_class .= ' '.$settings['image_effect'];
		}

		if($settings['content_alignment'] != '') {
			$el_class .= ' '.$settings['content_alignment'];
		}

		if(isset($settings['vertical_content_alignment']) && $settings['vertical_content_alignment'] != '') {
			$el_class .= ' '.esc_attr($settings['vertical_content_alignment']);
		}

		$output .= '<div class="dfd-info-banner ' . esc_attr($settings['style']) . '' . esc_attr($el_class) . '">';

		switch ($settings['style']) {
			case 'style-01':

				$output .= $image_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'style-02':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="title-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= '</div>';
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'style-03':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '</div>';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'style-04':
			case 'style-12':
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $image_html;
				$output .= '<div class="content-wrap">';
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			case 'style-05':
			case 'style-06':
				$output .= $image_html;
				$output .= '<div class="content-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			case 'style-07':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="content-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= '</div>';
				$output .= '</div>';
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				break;

			case 'style-08':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="title-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= '</div>';
				$output .= '</div>';
				$output .= '<div class="content-wrap">';
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			case 'style-09':
			case 'style-10':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="title-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= '</div>';
				$output .= '</div>';
				$output .= '<div class="content-wrap">';
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				break;

			case 'style-11':
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="content-wrap">';
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				$output .= '</div>';
				break;

			case 'style-13':
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= '<div class="image-wrap">';
				$output .= $image_html;
				$output .= $overlay_output;
				$output .= '<div class="content-wrap">';
				$output .= $content_html;
				$output .= $read_more_html;
				$output .= '</div>';
				$output .= '</div>';
				break;

			default:
				$output .= $image_html;
				$output .= $title_html;
				$output .= $subtitle_html;
				$output .= $delimiter_html;
				$output .= $content_html;
				$output .= $read_more_html;
		}

		if($settings['link'] && $settings['read_more'] === 'box') {
			$output .= '<a '.$link_atts.' class="full-box-link"></a>';
		}
		
		$output .= '</div>';

		echo $output;
	}

}
