<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

class El_Share extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_share';
	}

	public function get_title() {
		return esc_html__('DFD Share', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_new_share_module';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_share',
			[
				'label' => esc_html__('Share', 'dfd')
			]
		);
		
		$this->add_control(
			'main_style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Standard', 'dfd'),
					'style-2' => esc_html__('Standard colored', 'dfd'),
					'style-3' => esc_html__('Separated', 'dfd'),
					'style-4' => esc_html__('Separated colored', 'dfd'),
					'style-5' => esc_html__('Text', 'dfd'),
					'style-6' => esc_html__('Circle', 'dfd'),
					'style-7' => esc_html__('Circle colored', 'dfd'),
					'style-8' => esc_html__('Background change', 'dfd')
				],
				'default' => 'style-1'
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_social_networks',
			[
				'label' => esc_html__('Social Networks', 'dfd')
			]
		);
		
		$this->add_control(
			'enable_facebook_share',
			[
				'label' => esc_html__('Facebook share option', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'enable_twitter_share',
			[
				'label' => esc_html__('Twitter share option', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'enable_linkedin_share',
			[
				'label' => esc_html__('Linked-IN share option', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'enable_pinterest_share',
			[
				'label' => esc_html__('Pinterest share option', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_style_decoration',
			[
				'label' => esc_html__('Style decoration', 'dfd')
			]
		);
		
		$this->add_control(
			'single_share_height',
			[
				'label' => esc_html__('Block height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-1', 'style-2', 'style-3', 'style-4']
				]
			]
		);
		
		$this->add_control(
			'general_border_style',
			[
				'label' => esc_html__('General border style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'double' => esc_html__('Double', 'dfd'),
					'inset' => esc_html__('Inset', 'dfd'),
					'outset' => esc_html__('Outset', 'dfd')
				],
				'selectors' => [
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-top-style: {{SCHEME}}; border-bottom-style: {{SCHEME}};',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:first-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:first-child a' => 'border-left-style: {{SCHEME}};',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:last-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:last-child a' => 'border-right-style: {{SCHEME}};',
					'{{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-right-style: {{SCHEME}};'
				],
				'condition' => [
					'main_style' => ['style-1', 'style-5']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'general_border_width',
			[
				'label' => esc_html__('General Border Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-top-width: {{SCHEME}}px; border-bottom-width: {{SCHEME}}px;',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:first-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:first-child a' => 'border-left-width: {{SCHEME}}px;',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:last-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:last-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-right-width: {{SCHEME}}px;'
				],
				'condition' => [
					'main_style' => ['style-1', 'style-5'],
					'general_border_style!' => ''
				],
				'default' => 1
			]
		);
		
		$this->add_control(
			'general_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('General Border Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-top-color: {{SCHEME}}; border-bottom-color: {{SCHEME}};',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:first-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:first-child a' => 'border-left-color: {{SCHEME}};',
					'{{WRAPPER}} .dfd-new-share-module.style-1 ul li:last-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li:last-child a, {{WRAPPER}} .dfd-new-share-module.style-5 ul li a' => 'border-right-color: {{SCHEME}};',
				],
				'condition' => [
					'main_style' => ['style-1', 'style-5'],
					'general_border_style!' => ''
				],
				'default' => '#cdcdcd'
			]
		);
		
		$this->add_control(
			'single_border_radius',
			[
				'label' => esc_html__('Single item Border Radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-3', 'style-4', 'style-6', 'style-7']
				]
			]
		);
		
		$this->add_control(
			'single_font_size',
			[
				'label' => esc_html__('Single item Font Size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-5', 'style-6', 'style-7', 'style-8']
				]
			]
		);
		
		$this->add_control(
			'position_elements',
			[
				'label' => esc_html__('Share items alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'horizontal' => esc_html__('Horizontal', 'dfd'),
					'vertical' => esc_html__('Vertical', 'dfd')
				],
				'condition' => [
					'main_style' => ['style-8']
				],
				'default' => 'horizontal'
			]
		);
		
		$this->add_control(
			'top_bottom_spacer',
			[
				'label' => esc_html__('Top and bottom spacer', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-8']
				]
			]
		);
		
		$this->add_control(
			'left_right_spacer',
			[
				'label' => esc_html__('Left and right spacer', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-new-share-module.style-8.vertical ul li a .front-share' => 'padding-left: {{SCHEME}}px; padding-right: {{SCHEME}}px;'
				],
				'condition' => [
					'position_elements' => ['vertical']
				]
			]
		);
		
		$this->add_control(
			'share_uppercouse',
			[
				'label' => esc_html__('Text uppercase', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_style' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-8']
				]
			]
		);
		
		$this->add_control(
			'single_diameter',
			[
				'label' => esc_html__('Single Share Diameter', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-share-icon' => 'width: {{SCHEME}}px; height: {{SCHEME}}px; line-height: {{SCHEME}}px;'
				],
				'condition' => [
					'main_style' => ['style-6', 'style-7']
				]
			]
		);
		
		$this->add_control(
			'single_border_style',
			[
				'label' => esc_html__('Single Border Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('None', 'dfd'),
					'solid' => esc_html__('Solid', 'dfd'),
					'dashed' => esc_html__('Dashed', 'dfd'),
					'dotted' => esc_html__('Dotted', 'dfd'),
					'double' => esc_html__('Double', 'dfd'),
					'inset' => esc_html__('Inset', 'dfd'),
					'outset' => esc_html__('Outset', 'dfd')
				],
				'condition' => [
					'main_style' => ['style-6']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'single_border_width',
			[
				'label' => esc_html__('Single Border Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'main_style' => ['style-6'],
					'single_border_style!' => ''
				]
			]
		);
		
		$this->add_control(
			'single_border_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Single Border Color', 'dfd'),
				'condition' => [
					'main_style' => ['style-6'],
					'single_border_style!' => ''
				],
				'default' => '#cdcdcd'
			]
		);
		
		$this->add_control(
			'single_background_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Single Background Color', 'dfd'),
				'condition' => [
					'main_style' => 'style-6'
				],
				'default' => 'transparent'
			]
		);
		
		$this->add_control(
			'single_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Share icon color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition' => [
					'main_style' => 'style-6'
				]
			]
		);
		
		$this->add_control(
			'element_alignment',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'main_style' => ['style-5', 'style-6', 'style-7']
				],
				'default' => 'text-center'
			]
		);

		$this->add_control(
			'element_vertical_alignment',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'condition' => [
					'position_elements' => ['vertical']
				],
				'default' => 'text-center'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$output = $link_css = $general_class = $general_border_width = $single_style = $single_color = '';
		$general_border_color = $style_six = $hover_class = $hover_attr = $single_background_color = $style_class = '';
		
		$data_link = get_site_url();
		$data_title = $blog_title = get_bloginfo('name');

		$unique_id = uniqid('dfd_share_');

		$settings = $this->get_settings_for_display();

		$share_data = array(
			'facebook' => esc_html__('Facebook', 'dfd'),
			'twitter' => esc_html__('Twitter', 'dfd'),
			'linkedin' => esc_html__('LinkedIN', 'dfd'),
			'pinterest' => esc_html__('Pinterest', 'dfd'),
		);

		$shared_image = get_the_post_thumbnail_url();

		if (!$shared_image) {
			$shared_image = get_template_directory_uri() . '/assets/images/no_image_resized_480-360.jpg';
		}

		$share_urls = array(
			'facebook' => 'https://www.facebook.com/sharer/sharer.php?u=' . esc_attr($data_link),
			'twitter' => 'https://twitter.com/intent/tweet?text=' . esc_attr($data_link),
			'linkedin' => 'http://www.linkedin.com/shareArticle?mini=true&amp;url=' . esc_attr($data_link),
			'pinterest' => 'http://pinterest.com/pin/create/button/?url=' . esc_attr($data_link) . '&image_url=' . esc_url($shared_image),
		);

		if (isset($settings['general_border_style']) && !empty($settings['general_border_style'])) {
			$style_class = 'general-border';
			
			if (isset($settings['general_border_width']) && !empty($settings['general_border_width'])) {
				$general_border_width = esc_attr($settings['general_border_width']);
			}
			
			if (isset($settings['general_border_color']) && !empty($settings['general_border_color'])) {
				$general_border_color = esc_attr($settings['general_border_color']);
			}

			$link_css .= '.dfd-new-share-module.style-1 #' . esc_attr($unique_id) . ' ul li a,'
				. '.dfd-new-share-module.style-5 #' . esc_attr($unique_id) . ' ul li a'
				. ' {line-height: ' . (62 - $settings['general_border_width'] * 2) . 'px;}';

			/* Responcive */
			$link_css .= '@media only screen and (max-width: 799px) {'
				. '.dfd-new-share-module.style-1 #' . esc_attr($unique_id) . ' ul li a,'
				. '.dfd-new-share-module.style-5 #' . esc_attr($unique_id) . ' ul li a'
				. ' {border-left-width: ' . $general_border_width . 'px; border-right-width: ' . $general_border_width . 'px; border-bottom-width: 0; border-bottom-color: inherit; border-left-color: ' . $general_border_color . '; border-right-color: ' . $general_border_color . '; border-top-width: 0; border-left-style: ' . esc_attr($settings['general_border_style']) . '; border-right-style: ' . esc_attr($settings['general_border_style']) . '; border-bottom-style: solid;}'
				. '.dfd-new-share-module.style-1 #' . esc_attr($unique_id) . ' ul li:first-child a,'
				. '.dfd-new-share-module.style-5 #' . esc_attr($unique_id) . ' ul li:first-child a {border-top-width: ' . $general_border_width . 'px;}'
				. '.dfd-new-share-module.style-1 #' . esc_attr($unique_id) . ' ul li:last-child a {border-bottom-width: ' . $general_border_width . 'px; border-bottom-color: ' . $general_border_color . '; border-bottom-style: ' . esc_attr($settings['general_border_style']) . ';}'
				. '.dfd-new-share-module.style-5 #' . esc_attr($unique_id) . ' ul li a {border-bottom-width: ' . $general_border_width . 'px; border-bottom-color: ' . $general_border_color . '; border-bottom-style: ' . esc_attr($settings['general_border_style']) . ';}'
				. '}';
		}

		$single_style .= 'style="';
		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-3') === 0 || strcmp($settings['main_style'], 'style-4') === 0 || strcmp($settings['main_style'], 'style-6') === 0 || strcmp($settings['main_style'], 'style-7') === 0) {
			if (isset($settings['single_border_radius']) && !empty($settings['single_border_radius'])) {
				$single_style .= 'border-radius: ' . esc_attr($settings['single_border_radius']) . 'px; ';
			}
		}
		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-5') === 0 || strcmp($settings['main_style'], 'style-6') === 0 || strcmp($settings['main_style'], 'style-7') === 0 || strcmp($settings['main_style'], 'style-8') === 0) {
			if (isset($settings['single_font_size']) && !empty($settings['single_font_size'])) {
				$single_style .= 'font-size: ' . esc_attr($settings['single_font_size']) . 'px; ';
			}
		}
		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-1') === 0 || strcmp($settings['main_style'], 'style-2') === 0 || strcmp($settings['main_style'], 'style-3') === 0 || strcmp($settings['main_style'], 'style-4') === 0) {
			if (isset($settings['single_share_height']) && !empty($settings['single_share_height'])) {
				$single_style .= 'height: ' . esc_attr($settings['single_share_height']) . 'px; line-height: ' . esc_attr($settings['single_share_height']) . 'px; ';
			}
		}
		if ($settings['share_uppercouse'] === 'yes') {
			$single_style .= 'text-transform: uppercase;';
		}
		$single_style .= '"';

		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-6') === 0) {
			if (isset($settings['single_border_style']) && !empty($settings['single_border_style'])) {
				$style_six .= 'border-style: ' . esc_attr($settings['single_border_style']) . ';';
				if (isset($settings['single_border_width']) && !empty($settings['single_border_width'])) {
					$style_six .= 'border-width: ' . esc_attr($settings['single_border_width']) . 'px;';
				}
				if (isset($settings['single_border_color']) && !empty($settings['single_border_color'])) {
					$style_six .= 'border-color: ' . esc_attr($settings['single_border_color']) . ';';
				}
			}
			if (isset($settings['single_background_color']) && !empty($settings['single_background_color'])) {
				$single_background_color = 'background: ' . esc_attr($settings['single_background_color']) . ';';
			}
			if (isset($settings['single_color']) && !empty($settings['single_color'])) {
				$single_color = 'color: ' . esc_attr($settings['single_color']) . ';';
			}
			if ($settings['single_border_style'] || $single_background_color || $single_color) {
				$link_css .= '.dfd-new-share-module.style-6 #' . esc_attr($unique_id) . ' ul li a {' . $style_six . $single_background_color . $single_color . '}';
			}
		}

		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-5') === 0) {
			$hover_class = 'chaffle';
			$hover_attr = 'data-lang="en"';
		}
		
		if (isset($settings['top_bottom_spacer']) && !empty($settings['top_bottom_spacer'])) {
			$link_css .= '.dfd-new-share-module.style-8.vertical #' . esc_attr($unique_id) . ' ul li:first-child a .front-share {padding-top: ' . esc_attr($settings['top_bottom_spacer']) . 'px;}';
			$link_css .= '.dfd-new-share-module.style-8.vertical #' . esc_attr($unique_id) . ' ul li:last-child a .front-share {padding-bottom: ' . esc_attr($settings['top_bottom_spacer']) . 'px;}';
			$link_css .= '@media only screen and (min-width: 799px) {.dfd-new-share-module.style-8.horizontal #' . esc_attr($unique_id) . ' ul li a .front-share {padding: ' . esc_attr($settings['top_bottom_spacer']) . 'px 0;}}';
			$link_css .= '@media only screen and (max-width: 799px) {.dfd-new-share-module.style-8.horizontal #' . esc_attr($unique_id) . ' ul li:first-child a .front-share {padding-top: ' . esc_attr($settings['top_bottom_spacer']) . 'px;}}';
			$link_css .= '@media only screen and (max-width: 799px) {.dfd-new-share-module.style-8.horizontal #' . esc_attr($unique_id) . ' ul li:last-child a .front-share {padding-bottom: ' . esc_attr($settings['top_bottom_spacer']) . 'px;}}';
		}
		
		if (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-5') === 0 || strcmp($settings['main_style'], 'style-6') === 0 || strcmp($settings['main_style'], 'style-7') === 0) {
			$general_class .= ' ' . esc_attr($settings['element_alignment']) . ' ';
		} elseif (isset($settings['main_style']) && strcmp($settings['main_style'], 'style-8') === 0 && strcmp($settings['position_elements'], 'vertical') === 0) {
			$general_class .= ' ' . esc_attr($settings['element_vertical_alignment']) . ' ';
		} else {
			$general_class .= 'text-center ';
		}
		
		$general_class .= esc_attr($settings['main_style']) . ' ' . esc_attr($settings['position_elements']) . ' ' . esc_attr($style_class);

		ob_start();
		echo '<div class="dfd-shar-module-cover">';
		echo '<div class="dfd-new-share-module ' . $general_class . '">';
		echo '<div class="module module-entry-share" id="' . esc_attr($unique_id) . '">';
		echo '<ul class="module-entry-share-links-list rrssb-buttons" data-directory="' . get_template_directory_uri() . '">';
		foreach ($share_data as $key => $value) {
			if (strcmp($settings['main_style'], 'style-6') === 0 || strcmp($settings['main_style'], 'style-7') === 0) {
				$link_text = '<span class="dfd-share-icon"></span>';
			} else {
				$link_text = '<span class="back-share">' . $value . '</span><span class="front-share ' . esc_attr($hover_class) . '" ' . $hover_attr . '>' . $value . '</span>';
			}
			if ($settings['enable_' . $key . '_share']) {
				echo '<li class="rrssb-' . esc_attr($key) . '">';
				echo '<a class="module-entry-share-link-' . esc_attr($key) . ' feature-title" data-title="' . esc_attr($data_title) . '" data-url="' . esc_url($data_link) . '" data-media="" href="' . esc_url($share_urls[$key]) . '"  ' . $single_style . '>' . $link_text . '</a>';
				echo '</li>';
			}
		}
		echo '</ul>';
		echo '</div>';
		echo '</div>';
		?>
		<script type="text/javascript">
			(function ($) {
				"use strict";
				$(document).ready(function () {
					var $share_container = $('#<?php echo esc_js($unique_id); ?> .module-entry-share-links-list li');
					var parent = $share_container.parent().parent().parent();
					if ($share_container.length > 0) {
						var scrollbarWidth;
						var div = document.createElement('div');
						div.style.overflowY = 'scroll';
						div.style.width = '50px';
						div.style.height = '50px';
						div.style.visibility = 'hidden';
						document.body.appendChild(div);
						scrollbarWidth = div.offsetWidth - div.clientWidth;
						document.body.removeChild(div);
						var setShareWidth = function () {
							if (($(window).width() + scrollbarWidth) >= 800) {
								if (parent.hasClass("style-6") || parent.hasClass("style-7") || parent.hasClass("vertical")) {
									$share_container.width('auto');
								} else {
									$share_container.dfdEqWidth();
								}
							} else {
								if (parent.hasClass("style-6") || parent.hasClass("style-7") || parent.hasClass("vertical")) {
									$share_container.width('auto');
								} else {
									$share_container.width('100%');
								}
							}
						};
						setShareWidth();
						$(window).resize(setShareWidth);
					}
				});
		<?php if (!empty($link_css)) : ?>
					$('head').append('<style type="text/css"><?php echo esc_js($link_css); ?></style>');
		<?php endif; ?>
			})(jQuery);
		</script>

		<?php
		echo '</div>';
		$output .= ob_get_clean();

		echo $output;
	}

}
