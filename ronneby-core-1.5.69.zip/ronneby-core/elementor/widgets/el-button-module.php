<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Button_Module extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_button_module';
	}

	public function get_title() {
		return esc_html__('DFD Button', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_button';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'dfd_button_module',
			[
				'label' => esc_html__('Button', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__('Fade', 'dfd'),
					'style_2' => esc_html__('Slide', 'dfd'),
					'style_3' => esc_html__('Scale out', 'dfd'),
					'style_4' => esc_html__('Scale in', 'dfd'),
					'style_5' => esc_html__('Zoom in', 'dfd'),
					'style_6' => esc_html__('3D rotate', 'dfd')
				],
				'default' => 'style_1'
			]
		);

		$this->add_control(
			'button_size',
			[
				'label' => esc_html__('Button size', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Normal', 'dfd'),
					'dfd-button-full-width' => esc_html__('Full width', 'dfd')
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'direction_slide',
			[
				'label' => esc_html__('Animation direction', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-top-to-bottom' => esc_html__('Top to bottom', 'dfd'),
					'dfd-bottom-to-top' => esc_html__('Bottom to top', 'dfd'),
					'dfd-left-to-right' => esc_html__('Left to right', 'dfd'),
					'dfd-right-to-left' => esc_html__('Right to left', 'dfd')
				],
				'condition' => [
					'style' => 'style_2'
				],
				'default' => 'dfd-top-to-bottom'
			]
		);
		
		$this->add_control(
			'direction',
			[
				'label' => esc_html__('Animation direction', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-horizontal' => esc_html__('Horizontal', 'dfd'),
					'dfd-vertical' => esc_html__('Vertical', 'dfd'),
					'dfd-diagonal' => esc_html__('Diagonal', 'dfd')
				],
				'condition' => [
					'style' => ['style_3', 'style_4']
				],
				'default' => 'dfd-horizontal'
			]
		);
		
		$this->add_control(
			'direction_tilt',
			[
				'label' => esc_html__('Tilt', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Right (/)', 'dfd'),
					'top-left-to-bottom-right' => esc_html__('Left (\)', 'dfd')
				],
				'condition' => [
					'style' => ['style_3', 'style_4'],
					'direction' => 'dfd-diagonal'
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'direction_width',
			[
				'label' => esc_html__('Animation width', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Full', 'dfd'),
					'partial' => esc_html__('Partial', 'dfd')
				],
				'condition' => [
					'style' => ['style_3', 'style_4'],
					'direction' => ['dfd-diagonal', 'dfd-horizontal']
				],
				'default' => ''
			]
		);
		
		$this->add_control(
			'direction_effect',
			[
				'label' => esc_html__('Animation effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__('Simple', 'dfd'),
					'faden' => esc_html__('Faden', 'dfd')
				],
				'condition' => [
					'style' => ['style_3', 'style_4'],
					'direction' => ['dfd-diagonal', 'dfd-horizontal']
				],
				'default' => ''
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'main_heading',
			[
				'label' => esc_html__('Main button settings', 'dfd')
			]
		);
		
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Button'
			]
		);
		
		$this->add_control(
			'tooltip_text',
			[
				'label' => esc_html__('Tooltip text', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		
		$this->add_control(
			'tooltip_alignment',
			[
				'label' => esc_html__('Tooltip alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-button-tooltip-left' => esc_html__('Left', 'dfd'),
					'dfd-button-tooltip-right' => esc_html__('Right', 'dfd'),
					'dfd-button-tooltip-top' => esc_html__('Top', 'dfd'),
					'dfd-button-tooltip-bottom' => esc_html__('Bottom', 'dfd'),
					'dfd-button-tooltip-top-left' => esc_html__('Top Left', 'dfd'),
					'dfd-button-tooltip-top-right' => esc_html__('Top Right', 'dfd'),
					'dfd-button-tooltip-bottom-left' => esc_html__('Bottom Left', 'dfd'),
					'dfd-button-tooltip-bottom-right' => esc_html__('Bottom Right', 'dfd')
				],
				'condition' => [
					'tooltip_text!' => ''
				],
				'default' => 'dfd-button-tooltip-left'
			]
		);
		
		$this->add_control(
			'alignment',
			[
				'label' => esc_html__('Button alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'text-center'
			]
		);
	
		$this->add_control(
			'mobile_center',
			[
				'label' => esc_html__('Align center on mobile device', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'alignment' => ['text-left', 'text-right']
				]
			]
		);
	
		$this->add_control(
			'alignment_resolution',
			[
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'mobile_center' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'buttom_link_src',
			[
				'label' => esc_html__('Button link url', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_section',
			[
				'label' => esc_html__('Icon settings', 'dfd')
			]
		);
		
		$this->add_control(
			'icon_font',
			[
				'label' => esc_html__('Icon or image', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'icon' => esc_html__('Icon', 'dfd'),
					'icon_image' => esc_html__('Image', 'dfd')
				],
				'default' => 'icon'
			]
		);
		
		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Select Icon', 'dfd'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'condition' => [
					'icon_font' => 'icon'
				]
			]
		);
		
		$this->add_control(
			'image_id',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Upload Image', 'dfd'),
				'condition' => [
					'icon_font' => 'icon_image'
				]
			]
		);
		
		$this->add_control(
			'icon_align',
			[
				'label' => esc_html__('Icon alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-button-icon-left' => esc_html__('Left', 'dfd'),
					'dfd-button-icon-right' => esc_html__('Right', 'dfd')
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'terms' => [
								['name' => 'icon[value]', 'operator' => '!=', 'value' => '']
							]
						],
						[
							'terms' => [
								['name' => 'image_id[url]', 'operator' => '!=', 'value' => '']
							]
						],
					]
				],
				'default' => 'dfd-button-icon-left'
			]
		);
		
		$this->add_control(
			'icon_hover_action',
			[
				'label' => esc_html__('Icon action on hover', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfd-button-icon-hover-simple' => esc_html__('None', 'dfd'),
					'dfd-button-icon-hover-show' => esc_html__('Show on hover', 'dfd'),
					'dfd-button-icon-hover-hide' => esc_html__('Hide on hover', 'dfd')
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'terms' => [
								['name' => 'icon[value]', 'operator' => '!=', 'value' => '']
							]
						],
						[
							'terms' => [
								['name' => 'image_id[url]', 'operator' => '!=', 'value' => '']
							]
						],
					]
				],
				'default' => 'dfd-button-icon-hover-simple'
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'button_style_section',
			[
				'label' => esc_html__('Button styles', 'dfd'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__('Icon size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover span i' => 'font-size: {{SCHEME}}px;'
				],
				'condition' => [
					'icon[value]!' => ''
				]
			]
		);
		
		$this->add_responsive_control(
			'padding_left',
			[
				'label' => esc_html__('Left padding', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover, {{WRAPPER}} .dfd-button-module.with-icon.style-4 .dfd-button-link:hover .dfd-button-inner-cover' => 'padding-left: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_responsive_control(
			'padding_right',
			[
				'label' => esc_html__('Right padding', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover, {{WRAPPER}} .dfd-button-module.with-icon.style-5 .dfd-button-link:hover .dfd-button-inner-cover, {{WRAPPER}} .dfd-button-module.with-icon.style-7 .dfd-button-link:hover .dfd-button-inner-cover' => 'padding-right: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration',
			[
				'label' => esc_html__('Shadow border decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'subborder_decoration_width',
			[
				'label' => esc_html__('Shadow border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-border-decoration' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'tooltip_style_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Tooltip styles', 'dfd'),
				'separator' => 'before',
				'condition' => [
					'tooltip_text!' => ''
				]
			]
		);
		
		$this->add_control(
			'tooltip_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Tooltip color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-tooltip' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'tooltip_text!' => ''
				]
			]
		);
		
		$this->add_control(
			'tooltip_background',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Tooltip Background', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-tooltip' => 'background: {{SCHEME}};'
				],
				'condition' => [
					'tooltip_text!' => ''
				]
			]
		);
		
		$this->start_controls_tabs(
			'dfd_button_styles', [
				'separator' => 'before',
			]
		);
		
		$this->start_controls_tab(
			'dfd_button_styles_normal',
			[
				'label' => esc_html__('Normal', 'dfd')
			]
		);
		
		$this->add_control(
			'text_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__('Background color', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module:not(.style_4) .dfd-button-link .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_4 .dfd-button-link .dfd-button-inner-cover:after, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_6 .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'button_border',
				'label' => esc_html__('Button border', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module:not(.style_4) .dfd-button-link .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_4 .dfd-button-link .dfd-button-inner-cover:after, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_6 .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main'
			]
		);
		
		$this->add_control(
			'button_border_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-border-decoration, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover:after' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_x_offset',
			[
				'label' => esc_html__('Shadow border offset x', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_y_offset',
			[
				'label' => esc_html__('Shadow border offset y', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Shadow border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-border-decoration' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__('Box shadow', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover',
				'condition' => [
					'style' => ['style_1', 'style_2', 'style_3', 'style_4', 'style_5']
				]
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .featured-icon' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'icon[value]!' => ''
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'dfd_button_styles_hover',
			[
				'label' => esc_html__('Hover', 'dfd')
			]
		);
		
		$this->add_control(
			'hover_text_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module:not(.style_6) .dfd-button-link:hover .dfd-button-inner-cover .dfd-button-text-main, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'hover_background',
				'label' => esc_html__('Background color', 'dfd'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module:not(.style_4) .dfd-button-link .dfd-button-inner-cover:after, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_4 .dfd-button-link .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover'
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_button_border',
				'label' => esc_html__('Button border', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module:not(.style_4) .dfd-button-link .dfd-button-inner-cover:after, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_4 .dfd-button-link .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_3 .dfd-button-link:hover .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module.style_4 .dfd-button-link:hover .dfd-button-inner-cover:before'
			]
		);
		
		$this->add_control(
			'hover_button_border_radius',
			[
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-border-decoration, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-inner-cover, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-inner-cover:before, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-inner-cover:after' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_hover_x_offset',
			[
				'label' => esc_html__('Shadow border offset x', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_hover_y_offset',
			[
				'label' => esc_html__('Shadow border offset y', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'subborder_decoration_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Shadow border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-border-decoration' => 'border-color: {{SCHEME}};'
				],
				'condition' => [
					'subborder_decoration' => 'yes'
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'hover_box_shadow',
				'label' => esc_html__('Box shadow', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-inner-cover',
				'condition' => [
					'style' => ['style_1', 'style_2', 'style_3', 'style_4', 'style_5']
				]
			]
		);
		
		$this->add_control(
			'icon_hover_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Icon color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-button-link:hover .featured-icon' => 'color: {{SCHEME}};'
				],
				'condition' => [
					'icon[value]!' => ''
				]
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();

		$this->start_controls_section(
			'button_typography_section',
			[
				'label' => esc_html__('Button typography', 'dfd'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'button_font_options',
				'label' => esc_html__('Typography', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-main, {{WRAPPER}} .dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-inner-cover .dfd-button-text-hover',
			]
		);
		
		$this->end_controls_section();
		
	}

	protected function render() {
		$output = $css_rules = $icon_html = $link_atts = '';
		
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-button-');

		$el_class = ' '.$settings['style'];
		
		if($settings['button_size'] != '') {
			$el_class .= ' '.$settings['button_size'];
		}
		
		if(isset($settings['alignment']) && !empty($settings['alignment'])) {
			$el_class .= ' '.$settings['alignment'];
		}
		
		if(isset($settings['direction']) && !empty($settings['direction'])) {
			$el_class .= ' '.$settings['direction'];
		}
		
		if(isset($settings['direction_tilt']) != '' && !empty($settings['direction_tilt'])) {
			$el_class .= ' '.$settings['direction_tilt'];
		}
		
		if(isset($settings['direction_width']) != '' && !empty($settings['direction_width'])) {
			$el_class .= ' '.$settings['direction_width'];
		}
		
		if(isset($settings['direction_effect']) != '' && !empty($settings['direction_effect'])) {
			$el_class .= ' '.$settings['direction_effect'];
		}
		
		if(isset($settings['direction_slide']) != '' && !empty($settings['direction_slide'])) {
			$el_class .= ' '.$settings['direction_slide'];
		}
		
		if(isset($settings['icon_align']) != '' && !empty($settings['icon_align'])) {
			$el_class .= ' '.$settings['icon_align'];
		}
		
		if(isset($settings['icon_hover_action']) != '' && !empty($settings['icon_hover_action'])) {
			$el_class .= ' '.$settings['icon_hover_action'];
		}

		if(isset($settings['mobile_center']) && $settings['mobile_center'] == 'yes') {
			$el_class .= ' mobile-center';
			if($settings['alignment_resolution'] == '') {
				$settings['alignment_resolution'] = 799;
			}
			$css_rules .=	'@media only screen and (max-width: '.esc_js($settings['alignment_resolution']).'px) {'
								. '.'.esc_js($uniqid).' .mobile-center {text-align: center;}'
							. '}';
		}

		if($settings['icon_font'] == 'icon') {
			if($settings['icon']['value'] != '') {
				$icon_html .= '<i class="featured-icon '.$settings['icon']['value'].'"></i>';
			}
		} elseif($settings['icon_font'] == 'icon_image' && !empty($settings['image_id']['id'])) {
			$image_src = wp_get_attachment_image_src($settings['image_id']['id'], 'full');
			$alt = get_post_meta($image_src, '_wp_attachment_image_alt', true);

			$el_class .= ' with-icon';
			$icon_html .= '<span class="icon-wrap with-image">';
				global $dfd_ronneby;
				if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
					$el_class .= ' dfd-img-lazy-load';
					$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $image_src[1] $image_src[2]'%2F%3E";
					$icon_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($image_src[0]).'" width="'.esc_attr($image_src[1]).'" height="'.$image_src[2].'" alt="'.esc_attr($alt).'" />';
				} else {
					$icon_html .= '<img src="'.esc_url($image_src[0]).'" alt="'.esc_attr($alt).'" width="'.esc_attr($image_src[1]).'" height="'.$image_src[2].'" / >';
				}
			$icon_html .= '</span>';
		}

		if(isset($settings['subborder_decoration']) && $settings['subborder_decoration'] == 'yes') {
			if(isset($settings['subborder_decoration_x_offset']) && !empty($settings['subborder_decoration_x_offset'])) {
				$settings['subborder_decoration_x_offset'] = (int)$settings['subborder_decoration_x_offset'];
			} else {
				$settings['subborder_decoration_x_offset'] = 0;
			}
			if(isset($settings['subborder_decoration_y_offset']) && !empty($settings['subborder_decoration_y_offset'])) {
				$settings['subborder_decoration_y_offset'] = (int)$settings['subborder_decoration_y_offset'];
			} else {
				$settings['subborder_decoration_y_offset'] = 0;
			}
			if(isset($settings['subborder_decoration_hover_x_offset']) && !empty($settings['subborder_decoration_hover_x_offset'])) {
				$settings['subborder_decoration_hover_x_offset'] = (int)$settings['subborder_decoration_hover_x_offset'];
			} else {
				$settings['subborder_decoration_hover_x_offset'] = 0;
			}
			if(isset($settings['subborder_decoration_hover_y_offset']) && !empty($settings['subborder_decoration_hover_y_offset'])) {
				$settings['subborder_decoration_hover_y_offset'] = (int)$settings['subborder_decoration_hover_y_offset'];
			} else {
				$settings['subborder_decoration_hover_y_offset'] = 0;
			}
			$css_rules	.= '.' . esc_js($uniqid) . '.dfd-button-module-wrap .dfd-button-module .dfd-button-link .dfd-button-border-decoration {'
							. '-webkit-transform: translate('.esc_attr($settings['subborder_decoration_x_offset']).'px, '.esc_attr($settings['subborder_decoration_y_offset']).'px);'
							. '-moz-transform: translate('.esc_attr($settings['subborder_decoration_x_offset']).'px, '.esc_attr($settings['subborder_decoration_y_offset']).'px);'
							. '-o-transform: translate('.esc_attr($settings['subborder_decoration_x_offset']).'px, '.esc_attr($settings['subborder_decoration_y_offset']).'px);'
							. 'transform: translate('.esc_attr($settings['subborder_decoration_x_offset']).'px, '.esc_attr($settings['subborder_decoration_y_offset']).'px);'
						. '}';
			$css_rules	.= '.' . esc_js($uniqid) . '.dfd-button-module-wrap .dfd-button-module .dfd-button-link:hover .dfd-button-border-decoration {'
							. '-webkit-transform: translate('.esc_attr($settings['subborder_decoration_hover_x_offset']).'px, '.esc_attr($settings['subborder_decoration_hover_y_offset']).'px);'
							. '-moz-transform: translate('.esc_attr($settings['subborder_decoration_hover_x_offset']).'px, '.esc_attr($settings['subborder_decoration_hover_y_offset']).'px);'
							. '-o-transform: translate('.esc_attr($settings['subborder_decoration_hover_x_offset']).'px, '.esc_attr($settings['subborder_decoration_hover_y_offset']).'px);'
							. 'transform: translate('.esc_attr($settings['subborder_decoration_hover_x_offset']).'px, '.esc_attr($settings['subborder_decoration_hover_y_offset']).'px);'
						. '}';
		}

		if(!empty($settings['buttom_link_src'])) {
			$link_atts .= 'href="' . (!empty($settings['buttom_link_src']['url']) ? esc_url($settings['buttom_link_src']['url']) : '#') . '"';
			$link_atts .= ' target="' . (!empty($settings['buttom_link_src']['is_external']) ? '_blank' : '_self' ) . '"';
			$link_atts .= !empty($settings['buttom_link_src']['nofollow']) ? ' rel="nofollow"' : '';
			$link_atts .= !empty($settings['buttom_link_src']['custom_attributes']) ? ' ' . esc_attr($settings['buttom_link_src']['custom_attributes']) : '';
		}
		
		$output .= '<div class="dfd-button-module-wrap '.esc_attr($uniqid).'">';

			$output .= '<div class="dfd-button-module '.esc_attr($el_class).'">';

				$output .= '<a '.$link_atts.' class="dfd-button-link">';

					$output .= '<span class="dfd-button-inner-cover">';

						if($settings['button_text'] != '') {
							if($icon_html != '') {
								if($settings['icon_align'] == 'dfd-button-icon-right' || $settings['icon_align'] == 'dfd-button-icon-bottom') {
									$settings['button_text'] = $settings['button_text'] . $icon_html;
								} else {
									$settings['button_text'] = $icon_html . $settings['button_text'];
								}
							}

							$output .= '<span class="dfd-button-text-main">' . $settings['button_text'].'</span>';

							if($settings['style'] == 'style_6') {
								$output .= '<span class="dfd-button-text-hover">' . $settings['button_text'] . '</span>';
							}
						}

					$output .= '</span>';
					if(isset($settings['subborder_decoration']) && strcmp($settings['subborder_decoration'], 'yes') == 0) {
						$output .= '<span class="dfd-button-border-decoration"></span>';
					}

					if($settings['tooltip_text'] != '') {
						$output .= '<span class="dfd-button-tooltip '.esc_attr($settings['tooltip_alignment']).'">'.esc_html($settings['tooltip_text']).'</span>';
					}

				$output .= '</a>';

			$output .= '</div>';

			if($css_rules != '') {
				$output .=	'<script type="text/javascript">
								(function($) {
									$("head").append("<style>'.$css_rules.'</style>")
								})(jQuery);
							</script>';
			}

		$output .= '</div>';

		echo $output;
		
	}

}