<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Carousel_Team_Member extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_carousel_team_member';
	}

	public function get_title() {
		return esc_html__('DFD Team member carousel', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_carousel';
	}
	
	private function dfd_team_member_social() {
		return array(
			'deviantart' => array('name' => 'Deviantart', 'icon' => 'soc_icon-deviantart'),
			'digg' => array('name' => 'Digg', 'icon' => 'soc_icon-digg'),
			'dribbble' => array('name' => 'Dribbble', 'icon' => 'soc_icon-dribbble'),
			'dropbox' => array('name' => 'Dropbox', 'icon' => 'soc_icon-dropbox'),
			'evernote' => array('name' => 'Evernote', 'icon' => 'soc_icon-evernote'),
			'facebook' => array('name' => 'Facebook', 'icon' => 'soc_icon-facebook'),
			'flickr' => array('name' => 'Flickr', 'icon' => 'soc_icon-flickr'),
			'foursquare' => array('name' => 'Foursquare', 'icon' => 'soc_icon-foursquare_2'),
			'google' => array('name' => 'Google', 'icon' => 'soc_icon-google__x2B_'),
			'instagram' => array('name' => 'Instagram', 'icon' => 'soc_icon-instagram'),
			'last_fm' => array('name' => 'Last FM', 'icon' => 'soc_icon-last_fm'),
			'linkedin' => array('name' => 'LinkedIN', 'icon' => 'soc_icon-linkedin'),
			'livejournal' => array('name' => 'Livejournal', 'icon' => 'soc_icon-livejournal'),
			'picasa' => array('name' => 'Picasa', 'icon' => 'soc_icon-picasa'),
			'pinterest' => array('name' => 'Pinterest', 'icon' => 'soc_icon-pinterest'),
			'rss' => array('name' => 'RSS', 'icon' => 'soc_icon-rss'),
			'tumblr' => array('name' => 'Tumblr', 'icon' => 'soc_icon-tumblr'),
			'twitter' => array('name' => 'Twitter', 'icon' => 'dfd-added-icon-twitter-x-logo'),
			'vimeo' => array('name' => 'Vimeo', 'icon' => 'soc_icon-vimeo'),
			'wordpress' => array('name' => 'Wordpress', 'icon' => 'soc_icon-wordpress'),
			'youtube' => array('name' => 'Youtube', 'icon' => 'soc_icon-youtube'),
			'px_500' => array('name' => '500 px', 'icon' => 'dfd-added-font-icon-px-icon'),
			'mail' => array('name' => 'Mail', 'icon' => 'soc_icon-mail'),
			'viewbug' => array('name' => 'ViewBug', 'icon' => 'dfd-added-font-icon-vb'),
			'vkontakte' => array('name' => 'VKontakte', 'icon' => 'soc_icon-rus-vk-02'),
			'xing' => array('name' => 'Xing', 'icon' => 'dfd-added-font-icon-b_Xing-icon_bl'),
			'spotify' => array('name' => 'Spotify', 'icon' => 'dfd-added-font-icon-c_spotify-512-black'),
			'houzz' => array('name' => 'Houzz', 'icon' => 'dfd-added-font-icon-houzz-dark-icon'),
			'skype' => array('name' => 'Skype', 'icon' => 'dfd-added-font-icon-skype'),
			'slideshare' => array('name' => 'Slideshare', 'icon' => 'dfd-added-font-icon-slideshare'),
			'bandcamp' => array('name' => 'Bandcamp', 'icon' => 'dfd-added-font-icon-bandcamp-logo'),
			'soundcloud' => array('name' => 'Soundcloud', 'icon' => 'dfd-added-font-icon-soundcloud-logo'),
			'meerkat' => array('name' => 'Meerkat', 'icon' => 'dfd-added-font-icon-Meerkat-color'),
			'periscope' => array('name' => 'Periscope', 'icon' => 'dfd-added-font-icon-periscope-logo'),
			'snapchat' => array('name' => 'Snapchat', 'icon' => 'dfd-added-font-icon-Snapchat-logo'),
			'thecity' => array('name' => 'The City', 'icon' => 'dfd-added-font-icon-the-city'),
			'behance' => array('name' => 'Behance', 'icon' => 'soc_icon-behance'),
			'microsoft_pinpoint' => array('name' => 'Microsoft Pinpoint', 'icon' => 'dfd-added-font-icon-pinpoint'),
			'viadeo' => array('name' => 'Viadeo', 'icon' => 'dfd-added-font-icon-viadeo')
		);
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_carousel_content', [
				'label' => esc_html__('Carousel content', 'dfd')
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->start_controls_section(
			'el_team_member', [
				'label' => esc_html__('Team member', 'dfd')
			]
		);
		
		$repeater->add_control(
			'team_member_photo', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Image', 'dfd')
			]
		);
		
		$repeater->add_control(
			'team_member_name', [
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('John Brown', 'dfd')
			]
		);
		
		$repeater->add_control(
			'team_member_job_position', [
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Manager', 'dfd')
			]
		);
		
		$repeater->add_control(
			'team_member_description', [
				'label' => esc_html__('Description', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __('The main text about your team member', 'dfd')
			]
		);
		
		$repeater->add_control(
			'enable_custom_link', [
				'label' => esc_html__('Team member custom link', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$repeater->add_control(
			'custtom_link_url', [
				'label' => esc_html__('Custom link url', 'dfd'),
				'type' => \Elementor\Controls_Manager::URL,
				'condition' => [
					'enable_custom_link' => 'yes'
				]
			]
		);
		
		$repeater->end_controls_section();
		
		$repeater->start_controls_section(
			'el_soc_member', [
				'label' => esc_html__('Social accounts', 'dfd')
			]
		);
		
		$repeater->add_control(
			'soc_icons_hover', [
				'label' => esc_html__('Icon hover style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_attr__('Square top to bottom', 'dfd'),
					'2' => esc_attr__('Circle colored style', 'dfd'),
					'3' => esc_attr__('Square colored style', 'dfd'),
					'4' => esc_attr__('Flying line', 'dfd'),
					'5' => esc_attr__('Square black and white', 'dfd'),
					'6' => esc_attr__('Circle black and white', 'dfd'),
					'7' => esc_attr__('Circle icons with border 3px', 'dfd'),
					'8' => esc_attr__('Square icons with border 3px', 'dfd'),
					'9' => esc_attr__('Square icon on a dark background', 'dfd'),
					'10' => esc_attr__('Circle icon on a light background', 'dfd'),
					'11' => esc_attr__('Square icon on a light background', 'dfd'),
					'12' => esc_attr__('Circle icons with border', 'dfd'),
					'13' => esc_attr__('Square icons with border', 'dfd'),
					'14' => esc_attr__('Change color', 'dfd'),
					'15' => esc_attr__('In general border', 'dfd'),
					'16' => esc_attr__('Retro Disco Style', 'dfd'),
					'17' => esc_attr__('Circle from the center', 'dfd'),
					'18' => esc_attr__('The circle in the center', 'dfd'),
					'19' => esc_attr__('Round icons on gray background', 'dfd'),
					'20' => esc_attr__('Square icon on a gray background', 'dfd'),
					'21' => esc_attr__('Circle fade', 'dfd'),
					'22' => esc_attr__('Square background from left to right', 'dfd'),
					'23' => esc_attr__('Circle icon on a dark background', 'dfd'),
					'24' => esc_attr__('Square icon scale background', 'dfd'),
					'25' => esc_attr__('Circle icon scale background', 'dfd'),
					'26' => esc_attr__('Square icon on a light background', 'dfd'),
				],
				'default' => '1'
			]
		);
		
		foreach($this->dfd_team_member_social() as $key => $value) {
			$repeater->add_control(
				$key, [
					'label' => $value['name'],
					'type' => \Elementor\Controls_Manager::TEXT
				]
			);
		}
		
		$repeater->end_controls_section();
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('Team members', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		/*END Repeater*/
		
		/*Start team member settings*/
		$this->start_controls_section(
			'el_carousel_team_members_settings', [
				'label' => esc_html__('Team members settings', 'dfd')
			]
		);
		
		$this->add_control(
			'main_layout', [
				'label' => esc_html__('Team style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-01' => esc_html__('Classic', 'dfd'),
					'layout-02' => esc_html__('Classic left', 'dfd'),
					'layout-03' => esc_html__('Classic right', 'dfd'),
					'layout-04' => esc_html__('Classic top', 'dfd'),
					'layout-05' => esc_html__('Classic overlay', 'dfd'),
					'layout-06' => esc_html__('Hovered slide', 'dfd'),
					'layout-07' => esc_html__('Hovered bottom', 'dfd'),
					'layout-08' => esc_html__('Hovered description', 'dfd'),
					'layout-09' => esc_html__('Hovered overlay', 'dfd'),
					'layout-10' => esc_html__('Hovered thumbnail', 'dfd'),
					'layout-11' => esc_html__('Hovered title & icons', 'dfd')
				],
				'default' => 'layout-01'
			]
		);
		
		$this->add_control(
			'apply_link_to', [
				'label' => esc_html__('Team Apply link to', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'image-link' => esc_html__('Team member image', 'dfd'),
					'title-link' => esc_html__('Title', 'dfd'),
					'both-title-and-image' => esc_html__('Both title and image', 'dfd'),
				],
				'default' => 'image-link'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_member_style', [
				'label' => esc_html__('Team image options', 'dfd')
			]
		);
		
		$this->add_control(
			'team_member_img_width', [
				'label' => esc_html__('Image width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 400
			]
		);
		
		$this->add_control(
			'team_member_img_height', [
				'label' => esc_html__('Image height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 400
			]
		);
		
		$this->add_control(
			'thumb_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .team-member-photo' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'shadow', [
				'label' => esc_html__('Shadow', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'shadow_style', [
				'label' => esc_html__('Shadow style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'permanent' => esc_html__('Permanent', 'dfd'),
					'hover' => esc_html__('On hover', 'dfd')
				],
				'default' => 'permanent',
				'condition' => [
					'shadow' => 'yes'
				],
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_overlay_style',
			[
				'label' => esc_html__('Overlay options', 'dfd'),
				'condition' => [
					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
				]
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'gradient_color',
				'label' => esc_html__('Background', 'plugin-name'),
				'types' => ['gradient'],
				'selector' => '{{WRAPPER}} .overlay',
				'condition' => [
					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'full_width_overlay', [
				'label' => esc_html__('Full width overlay', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'main_layout' => ['layout-11']
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_subtitle_d_heading', [
				'label' => esc_html__('Delimiter settings', 'dfd'),
				'condition' => [
					'main_layout' => ['layout-05', 'layout-06', 'layout-07', 'layout-08', 'layout-09', 'layout-10', 'layout-11']
				]
			]
		);
		
		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable delimeter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-width: {{SCHEME}}px;'
				],
				'condition' => [
					'line_hide' => 'yes'
				]
			]
		);
		
		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Delimiter color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .delimiter' => 'border-color: {{SCHEME}};'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd')
			]
		);

		$this->add_control(
			'title_html_tag', [
				'label' => esc_html__('Title HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-title.feature-title'
			]
		);

		$this->add_control(
			'subtitle_html_tag', [
				'label' => esc_html__('Subtitle HTML Tag', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-subtitle'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name' => 'style-description-typography',
				'label' => esc_html__('Content typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .team-member-description'
			]
		);

		$this->add_control(
			'content_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Content color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .team-member-description' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->end_controls_section();
		/*END team member settings*/

		$this->start_controls_section(
			'el_carousel_image', [
				'label' => esc_html__('Carousel settings', 'dfd')
			]
		);

		$this->add_control(
			'slider_type', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'horizontal' => esc_html__('Horizontal', 'dfd'),
					'vertical' => esc_html__('Vertical', 'dfd')
				],
				'default' => 'horizontal'
			]
		);

		$this->add_control(
			'infinite_loop', [
				'label' => esc_html__('Loop', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode', [
				'label' => esc_html__('Center Mode', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode_scale', [
				'label' => esc_html__('Scale center element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'center_mode' => 'yes'
				]
			]
		);

		$this->add_control(
			'draggable', [
				'label' => esc_html__('Draggable Effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'touch_move', [
				'label' => esc_html__('Touch Move', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'adaptive_height', [
				'label' => esc_html__('Adaptive height', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_car_set', [
				'label' => esc_html__('Slideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'slides_to_show', [
				'label' => esc_html__('Slides to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'speed', [
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 300
			]
		);

		$this->add_control(
			'items_offset', [
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_slide_set', [
				'label' => esc_html__('Autoslideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'autoplay', [
				'label' => esc_html__('Autoplay', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'autoplay_speed', [
				'label' => esc_html__('Autoplay Speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5000,
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_resp_set', [
				'label' => esc_html__('Responsive settings', 'dfd')
			]
		);

		$this->add_control(
			'screen_normal_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1024
			]
		);

		$this->add_control(
			'screen_normal_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_tablet_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 800
			]
		);

		$this->add_control(
			'screen_tablet_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_mobile_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 480
			]
		);

		$this->add_control(
			'screen_mobile_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_set', [
				'label' => esc_html__('Navigation settings', 'dfd')
			]
		);

		$this->add_control(
			'arrows', [
				'label' => esc_html__('Navigation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'arrows_position', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'aside_offset' => esc_html__('Aside with offset', 'dfd'),
					'aside' => esc_html__('Aside', 'dfd'),
					'aside2' => esc_html__('Inside', 'dfd'),
					'top_left' => esc_html__('Top left', 'dfd'),
					'top_center' => esc_html__('Top center', 'dfd'),
					'top_right' => esc_html__('Top right', 'dfd'),
					'bottom_left' => esc_html__('Bottom left', 'dfd'),
					'bottom_center' => esc_html__('Bottom center', 'dfd'),
					'bottom_right' => esc_html__('Bottom right', 'dfd')
				],
				'default' => 'aside_offset',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_vertical_offset', [
				'label' => esc_html__('Navigation vertical offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'arrows' => 'yes',
				]
			]
		);

		$this->add_control(
			'arrow_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'default' => esc_html__('Pre-built', 'dfd'),
					'upload' => esc_html__('Upload', 'dfd')
				],
				'default' => 'default',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__('Simple arrows', 'dfd'),
					'style_2' => esc_html__('Arrows', 'dfd'),
					'style_3' => esc_html__('Arrows with rounded background', 'dfd'),
					'style_4' => esc_html__('Arrows with square background', 'dfd'),
					'style_5' => esc_html__('Simple arrows with square background', 'dfd'),
				],
				'default' => 'style_1',
				'condition' => [
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'arrows_bg', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows background', 'dfd'),
				'condition' => [
					'arrows_style' => ['style_3', 'style_4', 'style_5'],
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'left_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Left navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'right_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Right navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'enable_counter', [
				'label' => esc_html__('Slides counter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'counter_style', [
				'label' => esc_html__('Counter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'over_arrows' => esc_html__('Simple arrows', 'dfd'),
					'between_arrows' => esc_html__('Between arrows', 'dfd')
				],
				'default' => 'over_arrows',
				'condition' => [
					'enable_counter' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_always_show', [
				'label' => esc_html__('Always show arrows', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_hover_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows hover color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_dot_set', [
				'label' => esc_html__('Navigation dots settings', 'dfd')
			]
		);

		$this->add_control(
			'dots', [
				'label' => esc_html__('Dots Pagination', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		$this->add_control(
			'dots_style', [
				'label' => esc_html__('Pagination style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfdrounded' => esc_html__('Rounded dot', 'dfd'),
					'dfdfillrounded' => esc_html__('Filled rounded', 'dfd'),
					'dfdemptyrounded' => esc_html__('Transparent rounded', 'dfd'),
					'dfdfillsquare' => esc_html__('Filled square', 'dfd'),
					'dfdroundedold' => esc_html__('Rounded', 'dfd'),
					'dfdsquare' => esc_html__('Square', 'dfd'),
					'dfdemptysquare' => esc_html__('Transparent square', 'dfd'),
					'dfdline' => esc_html__('Line', 'dfd'),
					'dfdlineold' => esc_html__('Line hovered', 'dfd'),
					'dfdadvancesquare' => esc_html__('Advanced square', 'dfd'),
					'dfdemptyroundedold' => esc_html__('Transparent rounded small', 'dfd'),
					'dfdfillsquareold' => esc_html__('Filled square small', 'dfd'),
				],
				'default' => 'dfdrounded',
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dots_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Active dot color', 'dfd'),
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		if (is_rtl()) {
			$this->add_control(
				'rtl', [
					'label' => esc_html__('RTL Mode', 'dfd'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'condition' => [
						'slider_type' => 'horizontal'
					]
				]
			);
		}

		$this->end_controls_section();
	}

	protected function render() {
		$el_class = $css_rules = $setting = $counter_between_html = $cover_class = '';
		$left_arrow_html = $right_arrow_html = $counter_html = '';

		global $dfd_ronneby;
		
		if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
			$cover_class = 'dfd-img-lazy-load';
		}
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-carousel-');
			
		$setting .= 'arrows: false,';
		$setting .= 'dotsClass: \'dfd-slick-dots\',';
		$setting .= 'slidesToScroll: 1,';

		if($settings['autoplay'] == 'yes') {
			$setting .= 'autoplay: true,';
			if($settings['autoplay_speed'] != '') {
				$setting .= 'autoplaySpeed: '.esc_js($settings['autoplay_speed']).',';
			}
		}
		
		$el_class .= ' dfd-carousel-' . $settings['slider_type'];

		if(isset($settings['arrows_position'])) {
			$el_class .= ' dfd-arrows_'.$settings['arrows_position'];
		}
		
		if($settings['arrows_always_show'] == 'yes') {
			$el_class .= ' dfd-keep-arrows';
		}

		if(isset($settings['dots_style'])) {
			$el_class .= ' ' . $settings['dots_style'];
		}
		if($settings['arrow_style'] == 'default') {
			$el_class .= ' dfd-arrows-' . $settings['arrows_style'] . ' dfd-arrows-enabled';
			$left_arrow_html .= '<i class="dfd-added-font-icon-left-open2"></i>';
			$right_arrow_html .= '<i class="dfd-added-font-icon-right-open2"></i>';
		} elseif($settings['arrow_style'] == 'upload' && isset($settings['left_arrow']) && !empty($settings['left_arrow']) && isset($settings['right_arrow']) && !empty($settings['right_arrow'])) {
			$left_arrow_src = wp_get_attachment_image_src($settings['left_arrow']['id'], 'full');
			$right_arrow_src = wp_get_attachment_image_src($settings['right_arrow']['id'], 'full');

			if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 50 50'%2F%3E";
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			} else {
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			}

			$el_class .= ' dfd-arrows-enabled dfd-arrows-uploaded';
		}
			
			
		if($settings['slider_type'] == 'vertical') {
			$setting .= 'vertical: true,';
		}

		if($settings['dots'] == 'yes' && $settings['arrows_position'] != 'bottom_center') {
			$setting .= 'dots: true,';
			$setting .=	'customPaging: function(slider, i) {
								return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
							},';
			$el_class .= ' dfd-dots-enabled';
		} else {
			$setting .= 'dots: false,';
		}

		if($settings['infinite_loop'] == 'yes') {
			$setting .= 'infinite: true,';
		}else{
			$setting .= 'infinite: false,';
		}

		if($settings['center_mode'] == 'yes') {
			$setting .= 'centerMode: true,';
			if($settings['center_mode_scale'] == 'yes') {
				$el_class .= ' dfd-center-mode-scale';
			}
		}
		
		if($settings['slides_to_show'] != '') {
			$setting .= 'slidesToShow: '.esc_js($settings['slides_to_show']).',';
		}

		if($settings['speed'] != '') {
			$setting .= 'speed: '.esc_js($settings['speed']).',';
		}

		if($settings['draggable'] == 'yes') {
			$setting .= 'swipe: true,';
			$setting .= 'draggable: true,';
		} else {
			$setting .= 'swipe: false,';
			$setting .= 'draggable: false,';

			if($settings['touch_move'] == 'yes') {
				$setting .= 'touchMove: true,';
			}
		}

		if($settings['adaptive_height'] == 'yes') {
			$setting .= 'adaptiveHeight: true,';
		}

		if(isset($settings['rtl']) && $settings['rtl'] == 'yes') {
			$setting .= 'rtl: true,';
		}
			
		if($settings['screen_normal_resolution'] == '') {
			$settings['screen_normal_resolution'] = 1024;
		}

		if($settings['screen_tablet_resolution'] == '') {
			$settings['screen_tablet_resolution'] = 800;
		}

		if($settings['screen_mobile_resolution'] == '') {
			$settings['screen_mobile_resolution'] = 480;
		}

		if($settings['screen_normal_slides'] != '' || $settings['screen_tablet_slides'] != '' || $settings['screen_mobile_slides'] != '') {
			$setting .= 'responsive: [';
			if($settings['screen_normal_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_normal_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_normal_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_tablet_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_tablet_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_tablet_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_mobile_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_mobile_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_mobile_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			$setting .= ']';
		}

		if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {
			$counter_html .= '<span class="count"></span>';
		} else if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) {
			$el_class .= ' counter-between-arrows';
			$counter_between_html .= '<span class="dfd-slide-between-counter"><span class="current-slide"></span>/<span class="number-slides"></span></span>';
		}

		if($settings['arrows_bg'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_3 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_4 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control {background: '.esc_js($settings['arrows_bg']).'}';
		}
		if($settings['dots_color'] != '') {
			$css_rules .=	'#'.esc_js($uniqid).' .dfdrounded ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdsquare ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:after, #'.esc_js($uniqid).' .dfdroundedold ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).'}'
							.'#'.esc_js($uniqid).' .dfdfillrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquare ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdemptysquare ul.dfd-slick-dots li.slick-active span {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdline ul.dfd-slick-dots li.slick-active span:before {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span:before {border-bottom-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyroundedold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).';}';
		}
		if($settings['items_offset'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' > .dfd-carousel-module-wrapper > .dfd-carousel > .slick-list > .slick-track .dfd-team-member {padding: '.esc_js($settings['items_offset']/2).'px;}'
						. '#'.esc_js($uniqid).' {margin: -'.esc_js($settings['items_offset']/2).'px;}';
		}
		if(isset($settings['arrows_vertical_offset']) && $settings['arrows_vertical_offset'] != '') {
			if($settings['arrows_position'] == 'aside_offset' || $settings['arrows_position'] == 'aside' || $settings['arrows_position'] == 'aside2') {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control {margin-top: '.esc_js($settings['arrows_vertical_offset']).'px;}';
			} else {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control, #'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slide-between-counter {'
								. '-webkit-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-moz-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-o-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. 'transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
							. '}';
			}
		}
		if(isset($settings['arrows_color']) && !empty($settings['arrows_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control i, #'.esc_js($uniqid).' .dfd-slider-control .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after {color: '.esc_js($settings['arrows_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:after {background: '.esc_js($settings['arrows_color']).';}';
		}
		if(isset($settings['arrows_hover_color']) && !empty($settings['arrows_hover_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control:hover i, #'.esc_js($uniqid).' .dfd-slider-control:hover .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after {color: '.esc_js($settings['arrows_hover_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:hover:after {background: '.esc_js($settings['arrows_hover_color']).';}';
		}
		
		echo '<div id="'.esc_attr($uniqid).'" class="dfd-carousel-wrapper">';
			echo '<div class="dfd-carousel-module-wrapper '.esc_attr($el_class).'" >';
				echo '<div class="dfd-carousel">';
				
					$team_el_class = $cover_class;
					$delimiter_html = $shadow_class = $content_css = $overlay_output_m = $output = '';
					if(isset($settings['full_width_overlay']) && $settings['full_width_overlay'] == 'yes') {
						$team_el_class .= ' team-full-width-owerlay';
					}
					if ($settings['line_hide'] == 'yes') {
						$delimiter_html .= '<div class="wrap-delimiter"><div class="delimiter" ></div></div>';
					}
					if ($settings['shadow'] == 'yes') {
						if ('hover' === $settings['shadow_style']) {
							$shadow_class .= ' module-shadow-hover ';
						} else {
							$shadow_class .= ' module-shadow-permanent ';
						}
					}
					if ($settings['main_layout'] === 'layout-11') {
						if (isset($settings['team_member_img_width']) && !empty($settings['team_member_img_width'])) {
							$content_css .= 'style="max-width:' . $settings['team_member_img_width'] . 'px;"';
						}
					}
					if ('layout-06' === $settings['main_layout'] || 'layout-09' === $settings['main_layout'] || 'layout-10' === $settings['main_layout'] || 'layout-05' === $settings['main_layout'] || 'layout-07' === $settings['main_layout'] || 'layout-11' === $settings['main_layout']) {
						$overlay_output_m = '<div class="overlay"></div>';
					}
					foreach ($settings['list_fields'] as $fields) {
						$link_atts = $soc_icon_html = $soc_networks_output = $content_output = '';
						
						$overlay_output = $overlay_output_m;

						if($fields['enable_custom_link']) {
							$link_atts .= 'href="' . (!empty($fields['custtom_link_url']['url']) ? esc_url($fields['custtom_link_url']['url']) : '#') . '"';
							$link_atts .= ' target="' . (!empty($fields['custtom_link_url']['is_external']) ? '_blank' : '_self' ) . '"';
							$link_atts .= !empty($fields['custtom_link_url']['nofollow']) ? ' rel="nofollow"' : '';
							$link_atts .= !empty($fields['custtom_link_url']['custom_attributes']) ? ' ' . esc_attr($fields['custtom_link_url']['custom_attributes']) : '';
						}

						foreach($this->dfd_team_member_social() as $soc_network => $soc_name) {
							if (isset($fields[$soc_network]) && !empty($fields[$soc_network])) {
								$soc_icon_html .= '<a href="' . $fields[$soc_network] . '" class="' . esc_attr($soc_name['icon']) . '" ' . esc_attr(' target="' . ($fields['enable_custom_link'] == 'new_tab' ? '_blank' : '_self' ) . '"') . '><span class="line-top-left ' . esc_attr($soc_name['icon']) . '"></span><span class="line-top-center ' . esc_attr($soc_name['icon']) . '"></span><span class="line-top-right ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-left ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-center ' . esc_attr($soc_name['icon']) . '"></span><span class="line-bottom-right ' . esc_attr($soc_name['icon']) . '"></span><i class="' . esc_attr($soc_name['icon']) . '"></i></a>';
							}
						}

						if(!empty($soc_icon_html)) {
							$soc_networks_output .= '<div class="widget soc-icons dfd-soc-icons-hover-style-'.esc_attr($fields['soc_icons_hover']).'">';
								$soc_networks_output .= $soc_icon_html;
							$soc_networks_output .= '</div>';
						}

						if(!empty($fields['team_member_name'])) {
							$title_html = '<'.$settings['title_html_tag'].' class="team-member-title feature-title">';
							if ($fields['enable_custom_link'] && ('title-link' === $settings['apply_link_to']) || $fields['enable_custom_link'] && ('both-title-and-image' === $settings['apply_link_to'])) {
								$title_html .= '<a'.$link_atts.'>';
									$title_html .= esc_html($fields['team_member_name']);
								$title_html .= '</a>';
							} else {
								$title_html .= esc_html($fields['team_member_name']);
							}
							$title_html .= '</'.$settings['title_html_tag'].'>';
						}
						
						if (!empty($fields['team_member_job_position'])) {
							$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="team-member-subtitle subtitle" >'.esc_html($fields['team_member_job_position']).'</'.$settings['subtitle_html_tag'].'>';
						}
						
						if(!empty($fields['team_member_description'])) {
							$content_output .= '<div class="team-member-description" >'.$fields['team_member_description'].'</div>';
						}
						
						if (isset($fields['team_member_photo']) && !( $fields['team_member_photo'] == '' )) {
							$image_src = wp_get_attachment_image_src($fields['team_member_photo']['id'], 'full');
							$image_url = dfd_aq_resize($image_src[0], $settings['team_member_img_width'], $settings['team_member_img_height'], true, true, true);
							if (!$image_url) {
								$image_url = $image_src[0];
							}
							$attr = Dfd_Theme_Helpers::get_image_attrs($image_src[0], $fields['team_member_photo'], $settings['team_member_img_width'], $settings['team_member_img_height']);
							
							if (isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
								$team_member_img_width = $settings['team_member_img_width'];
								$team_member_img_height = $settings['team_member_img_height'];
								$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $team_member_img_width $team_member_img_height'%2F%3E";
								$image_output = '<img src="' . $loading_img_src . '" data-src="' . esc_url($image_url) . '" ' . $attr . ' width="' . esc_attr($team_member_img_width) . '" height="' . esc_attr($team_member_img_height) . '" class="team-member-photo ' . $shadow_class . '"/>';
							} else {
								$image_output = '<img src="' . esc_url($image_url) . '" ' . $attr . ' class="team-member-photo ' . $shadow_class . '"/>';
							}
						}

						if ($fields['enable_custom_link'] && ('image-link' === $settings['apply_link_to']) || $fields['enable_custom_link'] && ('both-title-and-image' === $settings['apply_link_to'])) {
							$overlay_output .= '<a class="image-custom-link ' . esc_attr($settings['apply_link_to']) . '" ' . $link_atts . '></a>';
						}
						
						$output .= '<div class="dfd-team-member ' . $settings['main_layout'] . ' ' . $team_el_class . '" >';

						if ('layout-05' === $settings['main_layout'] || 'layout-06' === $settings['main_layout'] || 'layout-07' === $settings['main_layout']) {

							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
							$output .= $content_output;
							$output .= $soc_networks_output;
							$output .= '</div>';
						} elseif ('layout-04' === $settings['main_layout'] || 'layout-08' === $settings['main_layout']) {
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
							$output .= $content_output;
							$output .= $soc_networks_output;
							$output .= '</div>';
						} elseif ('layout-09' === $settings['main_layout']) {
							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							$output .= '<div class="ovh">';
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= $content_output;
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= $content_output;
							$output .= '</div>';
							$output .= '</div>';
							$output .= '</div>';
							if (!empty($soc_networks_output)) {
								$output .= '<div class="soc-icons-wrap">';
								$output .= $soc_networks_output;
								$output .= '</div>';
							}
						} elseif ('layout-10' === $settings['main_layout']) {
							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
							$output .= $content_output;
							$output .= $soc_networks_output;
							$output .= '</div>';
						} elseif ('layout-11' === $settings['main_layout']) {
							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							if (!empty($soc_networks_output)) {
								$output .= '<div class="soc-icon-wrap">';
								$output .= $soc_networks_output;
								$output .= '</div>';
							}
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= '</div>';
							$output .= '<div class="content-wrap" ' . $content_css . '>';
							$output .= $content_output;
							$output .= '</div>';
						} else {
							$output .= '<div class="image-wrap">';
							$output .= $image_output;
							$output .= $overlay_output;
							$output .= '</div>';
							$output .= '<div class="content-wrap">';
							$output .= '<div class="title-wrap">';
							$output .= $title_html;
							$output .= $subtitle_html;
							$output .= $delimiter_html;
							$output .= '</div>';
							$output .= $content_output;
							$output .= $soc_networks_output;
							$output .= '</div>';
						}

						$output .= '</div>';
					}
					echo $output;
						
				echo '</div>';
				if($settings['arrows'] == 'yes') {
					echo '<a href="#" class="dfd-slider-control prev '.esc_attr($cover_class).'" title="'.esc_attr__('Previous slide','dfd').'">'.$counter_html.$left_arrow_html.'</a>';
					echo $counter_between_html;
					echo '<a href="#" class="dfd-slider-control next '.esc_attr($cover_class).'" title="'.esc_attr__('Next slide','dfd').'">'.$counter_html.$right_arrow_html.'</a>';
				}
			echo '</div>';
			?>
			<script type="text/javascript">
				(function($) {
					"use strict";
					var $carousel = $('#<?php echo esc_js($uniqid); ?>').find('.dfd-carousel');
					$(document).ready(function() {
						var $initialized = ($('body').hasClass('page-template-tmp-side-by-side')) ? $carousel.not('.slick-initialized') : $carousel;
						<?php if($settings['arrows'] == 'yes') {
							if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {  ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									var prev_slide_index, next_slide_index, current;
									var $prev_counter = $carousel.siblings('.dfd-slider-control.prev').find('.count');
									var $next_counter = $carousel.siblings('.dfd-slider-control.next').find('.count');
									total_slides = slick.slideCount;
									current = (currentSlide ? currentSlide : 0) + 1;
									prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
									next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
									$prev_counter.text(prev_slide_index + '/' + total_slides);
									$next_counter.text(next_slide_index + '/'+ total_slides);
								});
							<?php } elseif ($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) { ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									total_slides = slick.slideCount;
									var $current_slide = $carousel.siblings('.dfd-slide-between-counter').find('.current-slide'),
										$number_slides = $carousel.siblings('.dfd-slide-between-counter').find('.number-slides'),
										current;

										current = (currentSlide ? currentSlide : 0) + 1;

										$current_slide.text(current);
										$number_slides.text(total_slides);
								});
							<?php }
						} ?>
						$carousel.siblings('.dfd-slider-control.prev').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickPrev');
						});
						$carousel.siblings('.dfd-slider-control.next').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickNext');
						});
						$initialized.slick({<?php echo $setting; ?>});
						<?php if($css_rules != '') {
							echo '$("head").append("<style>' . $css_rules . '</style>")';
						}
						?>
					});
				})(jQuery);
			</script>
			<?php
		echo '</div>';
	}
}

