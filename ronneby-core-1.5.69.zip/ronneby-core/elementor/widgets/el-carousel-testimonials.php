<?php

if (!defined('ABSPATH')) {
	exit;
}

class El_Carousel_Testimonials extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_carousel_testimonials';
	}

	public function get_title() {
		return esc_html__('DFD Testimonials carousel', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_carousel';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_carousel_content', [
				'label' => esc_html__('Carousel content', 'dfd')
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'image',
			[
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Author Image', 'dfd')
			]
		);
		
		$repeater->add_control(
			'author',
			[
				'label' => esc_html__('Title', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Title'
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label' => esc_html__('Subtitle', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Subtitle'
			]
		);

		$repeater->add_control(
			'description',
			[
				'label' => esc_html__('Testimonial', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Content'
			]
		);
		
		$this->add_control(
			'list_fields',
			[
				'label' => esc_html__('Testimonials', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'testimonials_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Testimonials styles', 'dfd')
			]
		);
		
		$this->add_control(
			'main_style', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style-1' => esc_html__('Simple', 'dfd'),
					'style-2' => esc_html__('Decorated', 'dfd'),
					'style-3' => esc_html__('Background', 'dfd')
				],
				'default' => 'style-1'
			]
		);
		
		$this->add_control(
			'main_layout', [
				'label' => esc_html__('Layout', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__('Middle line', 'dfd'),
					'layout-2' => esc_html__('Top line', 'dfd'),
					'layout-3' => esc_html__('Big quotes', 'dfd'),
					'layout-4' => esc_html__('Bottom line', 'dfd'),
					'layout-5' => esc_html__('Top info', 'dfd'),
					'layout-6' => esc_html__('Top image', 'dfd'),
					'layout-7' => esc_html__('Bottom quotes', 'dfd'),
					'layout-11' => esc_html__('Bottom title', 'dfd'),
					'layout-8' => esc_html__('Top quotes', 'dfd'),
					'layout-9' => esc_html__('Left image', 'dfd'),
					'layout-10' => esc_html__('Right image', 'dfd'),
					'layout-12' => esc_html__('Combined info', 'dfd')
				],
				'default' => 'layout-1'
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'typography_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography styles', 'dfd')
			]
		);
		
		$this->add_control(
			'testimonial_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Testimonial typography', 'dfd')
			]
		);
		
		$this->add_control(
			'testimonial_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Testimonial color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-testimonial-content.testimonial-content' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'testimonial-typography',
				'label' => esc_html__('Testimonial typography', 'dfd'),
				'selector' => '{{WRAPPER}} .dfd-testimonial-content.testimonial-content'
			]
		);
		
		$this->add_control(
			'title_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Title typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'title_html_tag',
			[
				'label' => esc_html__('Title HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'title_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Title color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .testimonial-title.feature-title' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-title-typography',
				'label' => esc_html__('Title typography', 'dfd'),
				'selector' => '{{WRAPPER}} .testimonial-title.feature-title'
			]
		);
		
		$this->add_control(
			'subtitle_typography_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'subtitle_html_tag',
			[
				'label' => esc_html__('Subtitle HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p'
				],
				'default' => 'div'
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Subtitle color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .subtitle.testimonial-subtitle' => 'color: {{SCHEME}};'
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-subtitle-typography',
				'label' => esc_html__('Subtitle typography', 'dfd'),
				'selector' => '{{WRAPPER}} .subtitle.testimonial-subtitle'
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'decoration_section', [
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Testimonials settings', 'dfd')
			]
		);

		$this->add_control(
			'align',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'align-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'align-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'align-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					]
				],
				'default' => 'align-center'
			]
		);
		
		$this->add_control(
			'thumb_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Author thumbnail', 'dfd'),
				'separator' => 'before'
			]
		);

		$this->add_control(
			'thumb_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .image-wrap img' => 'border-radius: {{SCHEME}}px;'
				],
				'default' => 80
			]
		);

		$this->add_control(
			'thumb_border_width', [
				'label' => esc_html__('Border width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);

		$this->add_control(
			'thumb_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Border color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-testimonial-item .image-wrap img' => 'border-color: {{SCHEME}};'
				]
			]
		);

		$this->add_control(
			'thumb_size', [
				'label' => esc_html__('Image size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 80
			]
		);

		$this->add_control(
			'image_offset', [
				'label' => esc_html__('Image offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'description' => esc_html__( 'For Layouts Left image & Right image only.', 'dfd' ),
				'selectors' => [
					'{{WRAPPER}} .dfd-testimonial-item.layout-9 .image-wrap' => 'margin-right: {{SCHEME}}px;',
					'{{WRAPPER}} .dfd-testimonial-item.layout-10 .image-wrap' => 'margin-left: {{SCHEME}}px;'
				],
				'default' => 80,
				'condition' => [
					'main_layout' => ['layout-9', 'layout-10']
				]
			]
		);

		$this->add_control(
			'del_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Delimiter style', 'dfd'),
				'separator' => 'before'
			]
		);

		$this->add_control(
			'line_hide', [
				'label' => esc_html__('Enable element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'line_width', [
				'label' => esc_html__('Width', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-delimiter' => 'width: {{SCHEME}}px;'
				]
			]
		);

		$this->add_control(
			'line_border', [
				'label' => esc_html__('Height', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-delimiter' => 'height: {{SCHEME}}px;'
				]
			]
		);

		$this->add_control(
			'line_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'condition' => [
					'line_hide' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-delimiter' => 'background: {{SCHEME}};'
				]
			]
		);

		$this->add_control(
			'bg_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Content style', 'dfd'),
				'description' => esc_html__( 'For Style Decorated & Background only', 'dfd' ),
				'separator' => 'before'
			]
		);

		$this->add_control(
			'bg_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'description' => esc_html__( 'For Style Decorated & Background only', 'dfd' ),
				'selectors' => [
					'{{WRAPPER}} .content-wrap-bg' => 'background: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'bg_radius', [
				'label' => esc_html__('Background border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .content-wrap-bg' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'quote_t_heading',
			[
				'type' => \Elementor\Controls_Manager::HEADING,
				'label' => esc_html__('Quote symbol', 'dfd'),
				'separator' => 'before'
			]
		);
		
		$this->add_control(
			'quote_hide', [
				'label' => esc_html__('Enable element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		
		$this->add_control(
			'quote_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .navicon-quote-right' => 'color: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'quote_size', [
				'label' => esc_html__('Size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .navicon-quote-right' => 'font-size: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'quote_margin', [
				'label' => esc_html__('Margin from testimonial content', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'description' => esc_html__( 'For Layout Middle line & Top line & Bottom line', 'dfd' ),
				'selectors' => [
					'{{WRAPPER}} .navicon-quote-right' => 'margin-bottom: {{SCHEME}}px; display: inline-block;'
				]
			]
		);
		
		$this->add_control(
			'enabled_bg_decor', [
				'label' => esc_html__('Background decoration', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description' => esc_html__( 'For Layout Middle line & Bottom title', 'dfd' ),
			]
		);
		
		$this->add_control(
			'bg_size', [
				'label' => esc_html__('Background size', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_bg_decor' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .simbol-with-bg .icon-wrap i' => 'width: {{SCHEME}}px; height: {{SCHEME}}px; line-height: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'bg_border_radius', [
				'label' => esc_html__('Border radius', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_bg_decor' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .simbol-with-bg .icon-wrap i' => 'border-radius: {{SCHEME}}px;'
				]
			]
		);
		
		$this->add_control(
			'bg_background', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Background color', 'dfd'),
				'condition' => [
					'enabled_bg_decor' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .simbol-with-bg .icon-wrap i' => 'background: {{SCHEME}};'
				]
			]
		);
		
		$this->add_control(
			'icon_offset_bottom', [
				'label' => esc_html__('Bottom offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'enabled_bg_decor' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .simbol-with-bg .icon-wrap i' => 'padding-bottom: {{SCHEME}}px;'
				]
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'el_carousel_image', [
				'label' => esc_html__('Carousel settings', 'dfd')
			]
		);

		$this->add_control(
			'slider_type', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'horizontal' => esc_html__('Horizontal', 'dfd'),
					'vertical' => esc_html__('Vertical', 'dfd')
				],
				'default' => 'horizontal'
			]
		);

		$this->add_control(
			'infinite_loop', [
				'label' => esc_html__('Loop', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode', [
				'label' => esc_html__('Center Mode', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'center_mode_scale', [
				'label' => esc_html__('Scale center element', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'center_mode' => 'yes'
				]
			]
		);

		$this->add_control(
			'draggable', [
				'label' => esc_html__('Draggable Effect', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'touch_move', [
				'label' => esc_html__('Touch Move', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'adaptive_height', [
				'label' => esc_html__('Adaptive height', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_car_set', [
				'label' => esc_html__('Slideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'slides_to_show', [
				'label' => esc_html__('Slides to show', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'speed', [
				'label' => esc_html__('Slideshow speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 300
			]
		);

		$this->add_control(
			'items_offset', [
				'label' => esc_html__('Items offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 20
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_slide_set', [
				'label' => esc_html__('Autoslideshow settings', 'dfd')
			]
		);

		$this->add_control(
			'autoplay', [
				'label' => esc_html__('Autoplay', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'autoplay_speed', [
				'label' => esc_html__('Autoplay Speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5000,
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_resp_set', [
				'label' => esc_html__('Responsive settings', 'dfd')
			]
		);

		$this->add_control(
			'screen_normal_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1024
			]
		);

		$this->add_control(
			'screen_normal_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_tablet_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 800
			]
		);

		$this->add_control(
			'screen_tablet_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->add_control(
			'screen_mobile_resolution', [
				'label' => esc_html__('Screen resolution', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 480
			]
		);

		$this->add_control(
			'screen_mobile_slides', [
				'label' => esc_html__('Number of slides', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_set', [
				'label' => esc_html__('Navigation settings', 'dfd')
			]
		);

		$this->add_control(
			'arrows', [
				'label' => esc_html__('Navigation', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'arrows_position', [
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'aside_offset' => esc_html__('Aside with offset', 'dfd'),
					'aside' => esc_html__('Aside', 'dfd'),
					'aside2' => esc_html__('Inside', 'dfd'),
					'top_left' => esc_html__('Top left', 'dfd'),
					'top_center' => esc_html__('Top center', 'dfd'),
					'top_right' => esc_html__('Top right', 'dfd'),
					'bottom_left' => esc_html__('Bottom left', 'dfd'),
					'bottom_center' => esc_html__('Bottom center', 'dfd'),
					'bottom_right' => esc_html__('Bottom right', 'dfd')
				],
				'default' => 'aside_offset',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_vertical_offset', [
				'label' => esc_html__('Navigation vertical offset', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'condition' => [
					'arrows' => 'yes',
				]
			]
		);

		$this->add_control(
			'arrow_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'default' => esc_html__('Pre-built', 'dfd'),
					'upload' => esc_html__('Upload', 'dfd')
				],
				'default' => 'default',
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_style', [
				'label' => esc_html__('Arrow Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'style_1' => esc_html__('Simple arrows', 'dfd'),
					'style_2' => esc_html__('Arrows', 'dfd'),
					'style_3' => esc_html__('Arrows with rounded background', 'dfd'),
					'style_4' => esc_html__('Arrows with square background', 'dfd'),
					'style_5' => esc_html__('Simple arrows with square background', 'dfd'),
				],
				'default' => 'style_1',
				'condition' => [
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'arrows_bg', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows background', 'dfd'),
				'condition' => [
					'arrows_style' => ['style_3', 'style_4', 'style_5'],
					'arrow_style' => 'default'
				]
			]
		);

		$this->add_control(
			'left_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Left navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'right_arrow', [
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label' => esc_html__('Right navigation arrow', 'dfd'),
				'condition' => [
					'arrow_style' => 'upload'
				]
			]
		);

		$this->add_control(
			'enable_counter', [
				'label' => esc_html__('Slides counter', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'counter_style', [
				'label' => esc_html__('Counter style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'over_arrows' => esc_html__('Above arrows', 'dfd'),
					'between_arrows' => esc_html__('Between arrows', 'dfd')
				],
				'default' => 'over_arrows',
				'condition' => [
					'enable_counter' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_always_show', [
				'label' => esc_html__('Always show arrows', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->add_control(
			'arrows_hover_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Arrows hover color', 'dfd'),
				'condition' => [
					'arrows' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'el_nav_dot_set', [
				'label' => esc_html__('Navigation dots settings', 'dfd')
			]
		);

		$this->add_control(
			'dots', [
				'label' => esc_html__('Dots Pagination', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER
			]
		);
		$this->add_control(
			'dots_style', [
				'label' => esc_html__('Pagination style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'dfdrounded' => esc_html__('Rounded dot', 'dfd'),
					'dfdfillrounded' => esc_html__('Filled rounded', 'dfd'),
					'dfdemptyrounded' => esc_html__('Transparent rounded', 'dfd'),
					'dfdfillsquare' => esc_html__('Filled square', 'dfd'),
					'dfdroundedold' => esc_html__('Rounded', 'dfd'),
					'dfdsquare' => esc_html__('Square', 'dfd'),
					'dfdemptysquare' => esc_html__('Transparent square', 'dfd'),
					'dfdline' => esc_html__('Line', 'dfd'),
					'dfdlineold' => esc_html__('Line hovered', 'dfd'),
					'dfdadvancesquare' => esc_html__('Advanced square', 'dfd'),
					'dfdemptyroundedold' => esc_html__('Transparent rounded small', 'dfd'),
					'dfdfillsquareold' => esc_html__('Filled square small', 'dfd'),
				],
				'default' => 'dfdrounded',
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		$this->add_control(
			'dots_color', [
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Active dot color', 'dfd'),
				'condition' => [
					'dots' => 'yes'
				]
			]
		);

		if (is_rtl()) {
			$this->add_control(
				'rtl', [
					'label' => esc_html__('RTL Mode', 'dfd'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'condition' => [
						'slider_type' => 'horizontal'
					]
				]
			);
		}

		$this->end_controls_section();
	}

	protected function render() {
		$el_class = $css_rules = $setting = $counter_between_html = $cover_class = '';
		$left_arrow_html = $right_arrow_html = $counter_html = $content_bg = '';
		$icon_html = $delimiter_html = $el_testimonial_class = '';

		global $dfd_ronneby;
		
		if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
			$cover_class = 'dfd-img-lazy-load';
		}
		$settings = $this->get_settings_for_display();

		$uniqid = uniqid('dfd-carousel-');
			
		$setting .= 'arrows: false,';
		$setting .= 'dotsClass: \'dfd-slick-dots\',';
		$setting .= 'slidesToScroll: 1,';

		if($settings['autoplay'] == 'yes') {
			$setting .= 'autoplay: true,';
			if($settings['autoplay_speed'] != '') {
				$setting .= 'autoplaySpeed: '.esc_js($settings['autoplay_speed']).',';
			}
		}
		
		$el_class .= ' dfd-carousel-' . $settings['slider_type'];

		if(isset($settings['arrows_position'])) {
			$el_class .= ' dfd-arrows_'.$settings['arrows_position'];
		}
		
		if($settings['arrows_always_show'] == 'yes') {
			$el_class .= ' dfd-keep-arrows';
		}

		if(isset($settings['dots_style'])) {
			$el_class .= ' ' . $settings['dots_style'];
		}
		if($settings['arrow_style'] == 'default') {
			$el_class .= ' dfd-arrows-' . $settings['arrows_style'] . ' dfd-arrows-enabled';
			$left_arrow_html .= '<i class="dfd-added-font-icon-left-open2"></i>';
			$right_arrow_html .= '<i class="dfd-added-font-icon-right-open2"></i>';
		} elseif($settings['arrow_style'] == 'upload' && isset($settings['left_arrow']) && !empty($settings['left_arrow']) && isset($settings['right_arrow']) && !empty($settings['right_arrow'])) {
			$left_arrow_src = wp_get_attachment_image_src($settings['left_arrow']['id'], 'full');
			$right_arrow_src = wp_get_attachment_image_src($settings['right_arrow']['id'], 'full');

			if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
				$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 50 50'%2F%3E";
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.$loading_img_src.'" data-src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			} else {
				if(isset($left_arrow_src[0]) && !empty($left_arrow_src[0])) {
					$left_arrow_html .= '<img src="'.esc_url($left_arrow_src[0]).'" alt="'.esc_attr__('Left arrow', 'dfd').'" />';
				}
				if(isset($right_arrow_src[0]) && !empty($right_arrow_src[0])) {
					$right_arrow_html .= '<img src="'.esc_url($right_arrow_src[0]).'" alt="'.esc_attr__('Right arrow', 'dfd').'" />';
				}
			}

			$el_class .= ' dfd-arrows-enabled dfd-arrows-uploaded';
		}
			
			
		if($settings['slider_type'] == 'vertical') {
			$setting .= 'vertical: true,';
		}

		if($settings['dots'] == 'yes' && $settings['arrows_position'] != 'bottom_center') {
			$setting .= 'dots: true,';
			$setting .=	'customPaging: function(slider, i) {
								return \'<span data-role="none" role="button" aria-required="false" tabindex="0"></span>\';
							},';
			$el_class .= ' dfd-dots-enabled';
		} else {
			$setting .= 'dots: false,';
		}

		if($settings['infinite_loop'] == 'yes') {
			$setting .= 'infinite: true,';
		}else{
			$setting .= 'infinite: false,';
		}

		if($settings['center_mode'] == 'yes') {
			$setting .= 'centerMode: true,';
			if($settings['center_mode_scale'] == 'yes') {
				$el_class .= ' dfd-center-mode-scale';
			}
		}
		
		if($settings['slides_to_show'] != '') {
			$setting .= 'slidesToShow: '.esc_js($settings['slides_to_show']).',';
		}

		if($settings['speed'] != '') {
			$setting .= 'speed: '.esc_js($settings['speed']).',';
		}

		if($settings['draggable'] == 'yes') {
			$setting .= 'swipe: true,';
			$setting .= 'draggable: true,';
		} else {
			$setting .= 'swipe: false,';
			$setting .= 'draggable: false,';

			if($settings['touch_move'] == 'yes') {
				$setting .= 'touchMove: true,';
			}
		}

		if($settings['adaptive_height'] == 'yes') {
			$setting .= 'adaptiveHeight: true,';
		}

		if(isset($settings['rtl']) && $settings['rtl'] == 'yes') {
			$setting .= 'rtl: true,';
		}
			
		if($settings['screen_normal_resolution'] == '') {
			$settings['screen_normal_resolution'] = 1024;
		}

		if($settings['screen_tablet_resolution'] == '') {
			$settings['screen_tablet_resolution'] = 800;
		}

		if($settings['screen_mobile_resolution'] == '') {
			$settings['screen_mobile_resolution'] = 480;
		}

		if($settings['screen_normal_slides'] != '' || $settings['screen_tablet_slides'] != '' || $settings['screen_mobile_slides'] != '') {
			$setting .= 'responsive: [';
			if($settings['screen_normal_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_normal_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_normal_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_tablet_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_tablet_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_tablet_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			if($settings['screen_mobile_slides'] != '') {
				$setting .= '
						{
							breakpoint: '.esc_js($settings['screen_mobile_resolution']).',
							settings: {
								slidesToShow: '.esc_js($settings['screen_mobile_slides']).',
								slidesToScroll: 1,
							}
						},';
			}
			$setting .= ']';
		}

		if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {
			$counter_html .= '<span class="count"></span>';
		} else if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) {
			$el_class .= ' counter-between-arrows';
			$counter_between_html .= '<span class="dfd-slide-between-counter"><span class="current-slide"></span>/<span class="number-slides"></span></span>';
		}

		if($settings['arrows_bg'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_3 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_4 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control {background: '.esc_js($settings['arrows_bg']).'}';
		}
		if($settings['dots_color'] != '') {
			$css_rules .=	'#'.esc_js($uniqid).' .dfdrounded ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdsquare ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:before, #'.esc_js($uniqid).' .dfdlineold ul.dfd-slick-dots li.slick-active span:after, #'.esc_js($uniqid).' .dfdroundedold ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).'}'
							.'#'.esc_js($uniqid).' .dfdfillrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquare ul.dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyrounded ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdemptysquare ul.dfd-slick-dots li.slick-active span {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdline ul.dfd-slick-dots li.slick-active span:before {border-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span, #'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {background: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdadvancesquare ul.dfd-slick-dots li.slick-active span:before {border-bottom-color: '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdemptyroundedold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 2px '.esc_js($settings['dots_color']).';}'
							.'#'.esc_js($uniqid).' .dfdfillsquareold .dfd-slick-dots li.slick-active span {-webkit-box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).'; box-shadow: 0 0 0 1px '.esc_js($settings['dots_color']).';}';
		}
		if($settings['items_offset'] != '') {
			$css_rules .= '#'.esc_js($uniqid).' > .dfd-carousel-module-wrapper > .dfd-carousel > .slick-list > .slick-track .dfd-testimonial-item {padding: '.esc_js($settings['items_offset']/2).'px;}'
						. '#'.esc_js($uniqid).' {margin: -'.esc_js($settings['items_offset']/2).'px;}';
		}
		if(isset($settings['arrows_vertical_offset']) && $settings['arrows_vertical_offset'] != '') {
			if($settings['arrows_position'] == 'aside_offset' || $settings['arrows_position'] == 'aside' || $settings['arrows_position'] == 'aside2') {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control {margin-top: '.esc_js($settings['arrows_vertical_offset']).'px;}';
			} else {
				$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slider-control, #'.esc_js($uniqid).' .dfd-arrows-enabled .dfd-slide-between-counter {'
								. '-webkit-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-moz-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. '-o-transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
								. 'transform: translateY('.esc_js($settings['arrows_vertical_offset']).'px);'
							. '}';
			}
		}
		if(isset($settings['arrows_color']) && !empty($settings['arrows_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control i, #'.esc_js($uniqid).' .dfd-slider-control .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after {color: '.esc_js($settings['arrows_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:after {background: '.esc_js($settings['arrows_color']).';}';
		}
		if(isset($settings['arrows_hover_color']) && !empty($settings['arrows_hover_color'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-slider-control:hover i, #'.esc_js($uniqid).' .dfd-slider-control:hover .count, #'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after {color: '.esc_js($settings['arrows_hover_color']).';}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-arrows-style_1 .dfd-slider-control:hover:after, #'.esc_js($uniqid).' .dfd-arrows-style_5 .dfd-slider-control:hover:after {background: '.esc_js($settings['arrows_hover_color']).';}';
		}
		
		/*Testimonials settings*/
		$thumb_size = $settings['thumb_size'];
		if(empty($thumb_size)) {
			$thumb_size = 80;
		}
		
		if(!empty($settings['thumb_border_width'])) {
			$css_rules .= '#'.esc_js($uniqid).' .dfd-testimonial-item .image-wrap img {border-width:' . esc_html($settings['thumb_border_width']).'px;}';
			$css_rules .= '#'.esc_js($uniqid).' .dfd-testimonial-item .image-wrap img {border-style: solid;}';
		}
		
		if($settings['thumb_size'] !== 80 && $settings['main_style'] === 'style-2') {
			$content_bg .= 'style="';
				$margin = 0;
				if($settings['main_layout'] === 'layout-1') {
					$margin = 21;
				}
				if($settings['main_layout'] === 'layout-1' || $settings['main_layout'] === 'layout-2' || $settings['main_layout'] === 'layout-3' || $settings['main_layout'] === 'layout-4') {
					$bottom = (intval((int)$thumb_size / 2 ) + intval((int)$margin));
					if (!empty($settings['thumb_border_width'])){
						$bottom = intval((int)$settings['thumb_border_width']) + intval((int)$bottom);
					}
					$content_bg .= 'bottom: -'.$bottom.'px;';
				} elseif ($settings['main_layout'] === 'layout-5' || $settings['main_layout'] === 'layout-6' || $settings['main_layout'] === 'layout-7' || $settings['main_layout'] === 'layout-8'){
					$top = (intval((int)$thumb_size / 2 ) + intval((int)$margin));
					if (!empty($settings['thumb_border_width'])){
						$top = intval((int)$settings['thumb_border_width']) + intval((int)$top);
					}
					$content_bg .= 'top: '.$top.'px;';
				}
			$content_bg .= '"';
		}
		
		if($settings['line_hide'] == 'yes') {
			$delimiter_html .= '<div class="wrap-delimiter"><div class="testimonial-delimiter"></div></div>';
		}

		if($settings['quote_hide'] == 'yes') {
			$icon_html .= '<div class="icon-wrap">';
				$icon_html .= '<i class="navicon-quote-right"></i>';
			$icon_html .= '</div>';
		}

		if($settings['main_layout'] === 'layout-9' || $settings['main_layout'] === 'layout-10') {
			$settings['align'] = '';
		}

		if($settings['main_style'] === 'style-1' && $settings['main_layout'] === 'layout-12') {
			$settings['align'] = '';
		}
		
		if(isset($settings['enabled_bg_decor']) && $settings['enabled_bg_decor'] == 'yes') {
			$el_testimonial_class .= ' simbol-with-bg';
		}
						
		echo '<div id="'.esc_attr($uniqid).'" class="dfd-carousel-wrapper">';
			echo '<div class="dfd-carousel-module-wrapper '.esc_attr($el_class).'" >';
				echo '<div class="dfd-carousel">';
					foreach ($settings['list_fields'] as $fields) {
						$avatar_html = $output = $subtitle_html = '';
						$author_html = $content_html = '';
						if(!empty($fields['image']['id'])) {
							$image_src = wp_get_attachment_image_src( $fields['image']['id'], 'full' );
							$avatar = dfd_aq_resize( $image_src[0], $thumb_size, $thumb_size, true, true, true );
							if(!$avatar) {
								$avatar = $image_src[0];
							}
						
							$avatar_html .= '<div class="image-wrap '.$cover_class.'">';
								if(isset($dfd_ronneby['enable_images_lazy_load']) && $dfd_ronneby['enable_images_lazy_load'] == 'on') {
									$loading_img_src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg' viewBox%3D'0 0 $thumb_size $thumb_size'%2F%3E";
									$avatar_html .= '<img src="'.$loading_img_src.'" data-src="' . esc_url( $avatar ) . '" width="'.$thumb_size.'" height="'.$thumb_size.'" />';
								} else {
									$avatar_html .= '<img src="' . esc_url( $avatar ) . '" width="'.$thumb_size.'" height="'.$thumb_size.'" />';
								}
							$avatar_html .= '</div>';
						}
						
						if(!empty($fields['author'])) {
							$author_html = '<'.$settings['title_html_tag'].' class="feature-title testimonial-title">'.esc_html($fields['author']).'</'.$settings['title_html_tag'].'>';
						}
						
						if(!empty($fields['subtitle'])) {
							$subtitle_html = '<'.$settings['subtitle_html_tag'].' class="subtitle testimonial-subtitle">'.esc_html($fields['subtitle']).'</'.$settings['subtitle_html_tag'].'>';
						}
						
						if(!empty($fields['description'])) {
							if($settings['main_style'] !== 'style-1'){
								$content_html .= '<div class="content-wrap-bg" ' . $content_bg . '></div>';
							}
							$content_html .= '<div class="dfd-testimonial-content testimonial-content">';
								$content_html .= wp_kses($fields['description'], array('br' => array()));
							$content_html .= '</div>';
						}

						$output .= '<div class="dfd-testimonial-item ' . $settings['main_style'] . ' ' . $settings['main_layout'] . ' ' . $settings['align'] . ' ' . $el_testimonial_class . '">';

							switch($settings['main_layout']) {
								case 'layout-1':
									$output .= $icon_html;
									$output .= '<div class="pos-rel">';
										$output .= $content_html;
									$output .= '</div>';
									$output .= '<div class="centered-line">';
										$output .= $delimiter_html;
										$output .= $avatar_html;
									$output .= '</div>';
									$output .= $author_html;
									$output .= $subtitle_html;
	
									break;
								case 'layout-2':
								case 'layout-3':
	
									$output .= $icon_html;
									$output .= '<div class="pos-rel">';
									$output .= $content_html;
									if($settings['main_style'] === 'style-2'){
										$output .= $delimiter_html;
										$output .= '</div>';
									} else{
										$output .= '</div>';
										$output .= $delimiter_html;
									}
									$output .= $avatar_html;
									$output .= $author_html;
									$output .= $subtitle_html;
	
									break;
								case 'layout-4':
									$output .= $icon_html;
									$output .= '<div class="pos-rel">';
										$output .= $content_html;
									$output .= '</div>';
									$output .= $avatar_html;
									$output .= $author_html;
									$output .= $subtitle_html;
									$output .= $delimiter_html;
	
									break;
								case 'layout-5':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $author_html;
										$output .= $subtitle_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= $author_html;
										$output .= $subtitle_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $delimiter_html;
									$output .= $icon_html;
	
									break;
								case 'layout-6':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $delimiter_html;
									$output .= $author_html;
									$output .= $subtitle_html;
									$output .= $icon_html;
	
									break;
								case 'layout-7':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $delimiter_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= $delimiter_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $author_html;
									$output .= $subtitle_html;
									$output .= $icon_html;
	
									break;
								case 'layout-8':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $icon_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= $icon_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $delimiter_html;
									$output .= $author_html;
									$output .= $subtitle_html;
	
									break;
								case 'layout-9':
								case 'layout-10':
									$output .= $avatar_html;
									$output .= '<div class="content-wrap">';
										$output .= '<div class="pos-rel">';
											$output .= $content_html;
										$output .= '</div>';
										$output .= $delimiter_html;
										$output .= '<div class="title-wrap">';
											$output .= $icon_html;
											$output .= $author_html;
											$output .= '<br/>'.$subtitle_html;
										$output .= '</div>';
									$output .= '</div>';
	
									break;
								case 'layout-11':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $delimiter_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= $delimiter_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $icon_html;
									$output .= $author_html;
									$output .= $subtitle_html;
	
									break;
								case 'layout-12':
									if($settings['main_style'] === 'style-2'){
										$output .= '<div class="pos-rel">';
										$output .= $avatar_html;
										$output .= $content_html;
									} else {
										$output .= $avatar_html;
										$output .= '<div class="pos-rel">';
										$output .= $content_html;
									}
									$output .= '</div>';
									$output .= $delimiter_html;
									$output .= $author_html;
									$output .= $subtitle_html;
									$output .= $icon_html;
	
									break;
							}

						$output .= '</div>';

						echo $output;
						
					}
				echo '</div>';
				if($settings['arrows'] == 'yes') {
					echo '<a href="#" class="dfd-slider-control prev '.esc_attr($cover_class).'" title="'.esc_attr__('Previous slide','dfd').'">'.$counter_html.$left_arrow_html.'</a>';
					echo $counter_between_html;
					echo '<a href="#" class="dfd-slider-control next '.esc_attr($cover_class).'" title="'.esc_attr__('Next slide','dfd').'">'.$counter_html.$right_arrow_html.'</a>';
				}
			echo '</div>';
			?>
			<script type="text/javascript">
				(function($) {
					"use strict";
					var $carousel = $('#<?php echo esc_js($uniqid); ?>').find('.dfd-carousel');
					$(document).ready(function() {
						var $initialized = ($('body').hasClass('page-template-tmp-side-by-side')) ? $carousel.not('.slick-initialized') : $carousel;
						<?php if($settings['arrows'] == 'yes') {
							if($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'over_arrows') == 0) {  ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									var prev_slide_index, next_slide_index, current;
									var $prev_counter = $carousel.siblings('.dfd-slider-control.prev').find('.count');
									var $next_counter = $carousel.siblings('.dfd-slider-control.next').find('.count');
									total_slides = slick.slideCount;
									current = (currentSlide ? currentSlide : 0) + 1;
									prev_slide_index = (current - 1 < 1) ? total_slides : current - 1;
									next_slide_index = (current + 1 > total_slides) ? 1 : current + 1;
									$prev_counter.text(prev_slide_index + '/' + total_slides);
									$next_counter.text(next_slide_index + '/'+ total_slides);
								});
							<?php } elseif ($settings['enable_counter'] == 'yes' && strcmp($settings['counter_style'], 'between_arrows') == 0) { ?>
								var total_slides;
								$carousel.on('init reInit afterChange', function (event, slick, currentSlide) {
									total_slides = slick.slideCount;
									var $current_slide = $carousel.siblings('.dfd-slide-between-counter').find('.current-slide'),
										$number_slides = $carousel.siblings('.dfd-slide-between-counter').find('.number-slides'),
										current;

										current = (currentSlide ? currentSlide : 0) + 1;

										$current_slide.text(current);
										$number_slides.text(total_slides);
								});
							<?php }
						} ?>
						$carousel.siblings('.dfd-slider-control.prev').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickPrev');
						});
						$carousel.siblings('.dfd-slider-control.next').click(function(e) {
							e.preventDefault();
							$carousel.eq(0).slick('slickNext');
						});
						$initialized.slick({<?php echo $setting; ?>});
						<?php if($css_rules != '') {
							echo '$("head").append("<style>' . $css_rules . '</style>")';
						}
						?>
					});
				})(jQuery);
			</script>
			<?php
		echo '</div>';
	}
}

