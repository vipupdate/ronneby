<?php

if (!defined('ABSPATH')) {
	exit;
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class El_Animated_Text extends \Elementor\Widget_Base {

	public function get_name() {
		return 'el_animated_text';
	}

	public function get_title() {
		return esc_html__('DFD Animated text', 'dfd');
	}

	public function get_categories() {
		return ['ronneby-category'];
	}

	public function get_icon() {
		return 'dfd_animated_text';
	}

	protected function register_controls() {

		$this->start_controls_section(
			'el_animated_text',
			[
				'label' => esc_html__('DFD Animated text', 'dfd')
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__('Style', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'chaffle' => esc_html__('Standard', 'dfd'),
					'typed' => esc_html__('Typing', 'dfd'),
					'changethewords' => esc_html__('Changing words', 'dfd'),

				],
				'default' => 'chaffle'
			]
		);
		
		$this->add_control(
			'alignment',
			[
				'label' => esc_html__('Alignment', 'dfd'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'text-left' => [
						'title' => esc_html__('Left', 'dfd'),
						'icon' => 'eicon-text-align-left'
					],
					'text-center' => [
						'title' => esc_html__('Center', 'dfd'),
						'icon' => 'eicon-text-align-center'
					],
					'text-right' => [
						'title' => esc_html__('Right', 'dfd'),
						'icon' => 'eicon-text-align-right'
					],
				],
				'default' => 'text-left'
			]
		);
		
		$this->add_control(
			'type_speed',
			[
				'label' => esc_html__('Typing speed', 'dfd'),
				'type' => \Elementor\Controls_Manager::NUMBER
			]
		);
		
		$this->add_control(
			'onchange_animation',
			[
				'label' => esc_html__('Words animation in', 'dfd'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'bounceIn' => esc_html__('BounceIn', 'dfd'),
					'bounceInDown' => esc_html__('BounceInDown', 'dfd'),
					'bounceInLeft' => esc_html__('BounceInLeft', 'dfd'),
					'bounceInRight' => esc_html__('BounceInRight', 'dfd'),
					'bounceInUp' => esc_html__('BounceInUp', 'dfd'),
					'fadeIn' => esc_html__('FadeIn', 'dfd'),
					'fadeInDown' => esc_html__('FadeInDown', 'dfd'),
					'fadeInDownBig' => esc_html__('FadeInDownBig', 'dfd'),
					'fadeInLeft' => esc_html__('FadeInLeft', 'dfd'),
					'fadeInLeftBig' => esc_html__('FadeInLeftBig', 'dfd'),
					'fadeInRight' => esc_html__('FadeInRight', 'dfd'),
					'fadeInRightBig' => esc_html__('FadeInRightBig', 'dfd'),
					'fadeInUp' => esc_html__('FadeInUp', 'dfd'),
					'fadeInUpBig' => esc_html__('FadeInUpBig', 'dfd'),
					'lightSpeedIn' => esc_html__('LightSpeedIn', 'dfd'),
					'rotateIn' => esc_html__('RotateIn', 'dfd'),
					'rotateInDownLeft' => esc_html__('RotateInDownLeft', 'dfd'),
					'rotateInDownRight' => esc_html__('RotateInDownRight', 'dfd'),
					'rotateInUpLeft' => esc_html__('RotateInUpLeft', 'dfd'),
					'rotateInUpRight' => esc_html__('RotateInUpRight', 'dfd'),
					'rollIn' => esc_html__('RollIn', 'dfd'),
					'zoomIn' => esc_html__('ZoomIn', 'dfd'),
					'zoomInDown' => esc_html__('ZoomInDown', 'dfd'),
					'zoomInLeft' => esc_html__('ZoomInLeft', 'dfd'),
					'zoomInRight' => esc_html__('ZoomInRight', 'dfd'),
					'zoomInUp' => esc_html__('ZoomInUp', 'dfd'),
					'slideInDown' => esc_html__('SlideInDown', 'dfd'),
					'slideInLeft' => esc_html__('SlideInLeft', 'dfd'),
					'slideInRight' => esc_html__('SlideInRight', 'dfd'),
					'slideInUp' => esc_html__('SlideInUp', 'dfd')
				],
				'condition' => [
					'style' => 'changethewords'
				],
				'default' => 'bounceOut'
			]
		);
		$this->add_control(
			'loop',
			[
				'label' => esc_html__('Loop', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [
					'style' => 'typed'
				]
			]
		);
		$this->add_control(
			'cursor',
			[
				'label' => esc_html__('Cursor', 'dfd'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'condition' => [
					'style' => 'typed'
				]
			]
		);
		$this->add_control(
			'prefix',
			[
				'label' => esc_html__('Prefix', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'text_field',
			[
				'label' => esc_html__('Single string', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		$repeater->add_control(
			'string_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('String color', 'dfd'),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
			]
		);
		$repeater->add_control(
			'text_field_background',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('String background', 'dfd'),
				'default' => 'transparent'
			]
		);
		$this->add_control(
			'text_fields',
			[
				'label' => esc_html__('Animated text string', 'dfd'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls()
			]
		);
		$this->add_control(
			'postfix',
			[
				'label' => esc_html__('Postfix', 'dfd'),
				'type' => \Elementor\Controls_Manager::TEXT
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'color_set',
			[
				'label' => esc_html__('Color settings', 'dfd'),
			]
		);
		$this->add_control(
			'prefix_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Prefix color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-anim-prefix' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'postfix_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Postfix color', 'dfd'),
				'selectors' => [
					'{{WRAPPER}} .dfd-anim-postfix' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'cursor_color',
			[
				'type' => \Elementor\Controls_Manager::COLOR,
				'label' => esc_html__('Cursor color', 'dfd'),
				'condition' => [
					'style' => 'typed'
				],
				'selectors' => [
					'{{WRAPPER}} .typed-cursor' => 'color: {{VALUE}};'
				]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'typography_section',
			[
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => esc_html__('Typography', 'dfd'),
			]
		);

		$this->add_control(
			'prefix_html_tag',
			[
				'label' => esc_html__('Prefix HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-prefix-typography',
				'label' => esc_html__('Prefix typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-anim-prefix',
			]
		);

		$this->add_control(
			'postfix_html_tag',
			[
				'label' => esc_html__('Postfix HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
				'separator' => 'before'
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-postfix-typography',
				'label' => esc_html__('Postfix typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-anim-postfix',
			]
		);
		$this->add_control(
			'string_html_tag',
			[
				'label' => esc_html__('String HTML Tag', 'elementor'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'div',
				'separator' => 'before'
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'style-string-typography',
				'label' => esc_html__('String typography', 'dfd'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .dfd-animated-text-wrap .dfd-animated-text-block span.dfd-animate-text span, {{WRAPPER}}.dfd-animated-text-wrap .dfd-animated-text-block span.dfd-animate-me, {{WRAPPER}} .dfd-animate-me, {{WRAPPER}} .typed-cursor',
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$html = $el_class = $animated_text = $css_rules = $js_rules = $data_atts = $js_atts = '';
		
		$settings = $this->get_settings_for_display();

		if (!isset($settings['style']) || $settings['style'] == '') {
			$settings['style'] = 'typed';
		}

		$uniqid = uniqid('dfd-animated-text-') . '-' . rand(1, 9999);

		if ($settings['alignment'] != '') {
			$el_class .= ' '.$settings['alignment'];
		}

		if ($settings['type_speed'] == '') {
			$settings['type_speed'] = 10;
		}

		switch ($settings['style']) {
			case 'typed':
				if(isset($settings['cursor']) && $settings['cursor'] == 'yes') {
					$js_atts .= 'showCursor: true,';
				} else {
					$js_atts .= 'showCursor: false,';
				}

				if($settings['loop'] == 'yes') {
					$js_atts .= 'loop: true,';
				}

				$js_rules .=	'$("#'.esc_js($uniqid).' .dfd-animate-me").typed({
									stringsElement: $("#'. esc_js($uniqid) .' .dfd-animate-text"),'
									.$js_atts.
									'typeSpeed: '. esc_js($settings['type_speed']) .'
								});';
				break;
			case 'chaffle':
				$js_rules .=	'$("#'.esc_js($uniqid).' .dfd-animate-text").changeWords({
									animate: "none",
									afterChangeAnimate: "none",	
									selector: "span",
									time: '. esc_js($settings['type_speed']) * 1000 .'
								});';
				break;
			case 'changethewords':
				$js_rules .=	'$("#'.esc_js($uniqid).' .dfd-animate-text").changeWords({
									animate: "'. esc_js($settings['onchange_animation']) .'",
									selector: "span",
									time: '. esc_js($settings['type_speed']) * 1000 .'
								});';
				break;
		}

		/* Animated text */
		if (!empty($settings['text_fields'])) {
			$i = 1;
			foreach ($settings['text_fields'] as $field) {
				$single_field_css = '';
				if (isset($field['string_color'])) {
					$single_field_css .= 'color: ' . esc_attr($field['string_color']) . ';';
				}
				if (isset($field['text_field_background'])) {
					$single_field_css .= 'background: ' . esc_attr($field['text_field_background']) . '; padding: 0 10px .1em;';
				}
				if (isset($field['text_field'])) {
					$animated_text .= '<span class="dfd-animated-text-string ' . esc_attr($settings['style']) . '" data-remove-hover="true" data-lang="en" data-load="onload" data-speed="' . esc_attr($settings['type_speed'] * 10) . '" data-id="' . esc_attr($i) . '" style="' . $single_field_css . '">' . strip_tags($field['text_field'], '<br></br>') . '</span>';
				}
				$i++;
			}
			$animated_text = '<span class="dfd-animate-text">' . $animated_text . '</span>';

			if ($settings['style'] == 'typed') {
				$animated_text .= '<span class="dfd-animate-me"></span>';
			}
		}

		$el_class .= ' style-' . $settings['style'];

		$html .= '<div class="dfd-animated-text-wrap" id="' . esc_attr($uniqid) . '">';

		$html .= '<div class="dfd-animated-text-block ' . esc_attr($el_class) . '">';
		if ($settings['prefix'] != '') {
			$html .= '<span class="dfd-anim-prefix">' . strip_tags($settings['prefix'], '<br></br>') . '</span>';
		}

		$html .= $animated_text;

		if ($settings['postfix'] != '') {
			$html .= '<span class="dfd-anim-postfix">' . strip_tags($settings['postfix'], '<br></br>') . '</span>';
		}

		$html .= '</div>';

		if ($css_rules != '' || $js_rules != '') {
			$html .= '<script type="text/javascript">
						(function($) {';

							if($js_rules != '') {
								$html .= '$(document).ready(function() {'.$js_rules.'});';
							}
						
							if($css_rules != '') {
								$html .= '$("head").append("<style>'.$css_rules.'</style>")';
							}

							$html .= '
							})(jQuery);
						</script>';
		}

		$html .= '</div>';

		echo $html;
	}

}
