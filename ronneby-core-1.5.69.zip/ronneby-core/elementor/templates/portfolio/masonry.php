<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$extra_class_name = '';

$columns = (isset($settings['columns']) && !empty($settings['columns'])) ? $settings['columns'] : 3;

$data_atts .= ' data-columns="'.esc_attr($columns).'"';
$data_atts .= ' data-layout-style="'.esc_attr($settings['style']).'"';
$data_atts .= ' data-item="project"';

if(isset($settings['items_offset'])) {
	$css_rules .= '#'.esc_js($uniqid).' .dfd-portfolio {margin: -'.esc_js($settings['items_offset']/2).'px;}';
	$css_rules .= '#'.esc_js($uniqid).' .dfd-portfolio .cover {padding: '.esc_js($settings['items_offset']/2).'px;}';
}

if($settings['folio_hover_plus_bg'] && !empty($settings['folio_hover_plus_bg'])) {
	switch($settings['folio_hover_plus_position']) {
		case 'dfd-top-right' :
		case 'dfd-bottom-right' :
			$css_rules .= '#'.esc_attr($uniqid).' .project .entry-thumb .portfolio-custom-hover .plus-link:before {border-right-color: '.esc_attr($settings['folio_hover_plus_bg']).';}';
			break;
		case 'dfd-top-left' :
		case 'dfd-bottom-left' :
			$css_rules .= '#'.esc_attr($uniqid).' .project .entry-thumb .portfolio-custom-hover .plus-link:before {border-left-color: '.esc_attr($settings['folio_hover_plus_bg']).';}';
			break;
	}
}

if(isset($settings['sort_panel']) && $settings['sort_panel'] == 'yes') {
	$sort_panel_enabled = true;
}

$extra_class_name .= 'dfd-new-isotope';

$js_scripts .= 'if(typeof $.fn.initTaxonomyIsotope !== "undefined") {
					$("#'.esc_js($uniqid).' .'.esc_js($extra_class_name).'").initTaxonomyIsotope();
				}';
?>
<div class="dfd-portfolio-loop dfd-portfolio-module <?php echo esc_attr($el_class) ?>" id="<?php echo esc_attr($uniqid) ?>">
	<div class="dfd-portfolio-wrap">
		<?php
			if($sort_panel_enabled) {
				include(DFD_RONNEBY_PLUGIN_PATH.'elementor/templates/portfolio/template_parts/sort-panel.php');
			}
		?>
		
		<div class="dfd-portfolio dfd-portfolio-<?php echo esc_attr($settings['style'] .' '. $extra_class_name .' '. $settings['heading_position']) ?>" <?php echo $data_atts ?>>
		<?php
		
			while ($wp_query->have_posts()) : $wp_query->the_post();

				$permalink = get_permalink();

				$excerpt = get_the_excerpt();

				if(!empty($excerpt)) {
					$excerpt = '<div class="entry-content"><p>'.$excerpt.'</p></div>';
				}

				$post_class = 'project';

				$post_class .= ' '.$folio_hover_style_class;
				
				if($sort_panel_enabled) {
					include(DFD_RONNEBY_PLUGIN_PATH.'elementor/templates/portfolio/template_parts/article_data_atts.php');
				}
				?>
				<div class="<?php echo esc_attr($post_class) ?>" <?php echo $article_data_atts; ?>>
					<div class="cover <?php echo esc_attr($settings['content_alignment']) ?>">
						<?php

						$caption = get_the_title();
						if (has_post_thumbnail()) {

							$thumb = get_post_thumbnail_id();
							$img_src = wp_get_attachment_image_src($thumb, 'full');
							$img_url = (isset($img_src[0]) && !empty($img_src[0])) ? $img_src[0] : get_template_directory_uri() . '/assets/images/no_image_resized_675-450.jpg';
							$meta = wp_get_attachment_metadata($thumb);
							if(isset($meta['image_meta']['caption']) && $meta['image_meta']['caption'] != '') {
								$caption = $meta['image_meta']['caption'];
							} else if(isset($meta['image_meta']['title']) && $meta['image_meta']['title'] != '') {
								$caption = $meta['image_meta']['title'];
							}

						} else {
							$img_url = get_template_directory_uri() . '/assets/images/no_image_resized_675-450.jpg';
						} ?>
						
						<div class="entry-thumb <?php echo esc_attr($media_class) ?>">
							<img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($caption); ?>"/>
							<?php include(DFD_RONNEBY_PLUGIN_PATH.'inc/vc_custom/dfd_vc_addons/templates/portfolio/template_parts/comments_likes.php'); ?>
							<?php include(DFD_RONNEBY_PLUGIN_PATH.'elementor/templates/portfolio/template_parts/custom-hover.php'); ?>
						</div>

						<?php
						include(DFD_RONNEBY_PLUGIN_PATH.'elementor/templates/portfolio/template_parts/heading.php');
						
						if($enable_excerpt) {
							echo $excerpt;
						}

						if($read_more || $share) : ?>
							<div class="dfd-read-share clearfix">
								<?php if($read_more) : ?>
									<div class="read-more-wrap">
										<a href="<?php echo esc_url($permalink) ?>" class="more-button <?php echo esc_attr($settings['read_more_style']) ?>" title="<?php __('Read more','dfd') ?>" data-lang="en"><?php _e('More', 'dfd'); ?></a>
									</div>
								<?php endif; ?>
								<?php if($share) : ?>
									<div class="dfd-share-cover dfd-share-<?php echo esc_attr($settings['share_style']);  ?>">
										<?php get_template_part('templates/entry-meta/mini','share-blog') ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php
			endwhile;
		wp_reset_postdata();
		?>
		</div>
	</div>
</div>
