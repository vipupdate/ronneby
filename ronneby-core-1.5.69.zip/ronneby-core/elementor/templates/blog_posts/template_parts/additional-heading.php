<?php
if (!defined('ABSPATH')) {
	exit;
}
echo '<div class="dfd-blog-add-heading-wrap">';
	$title = get_the_title();

	if(isset($permalink) && !empty($permalink)) {
		$title = '<a href="' . esc_url($permalink) . '" title="' . esc_attr($title) . '">' . esc_html($title) . '</a>';
	}
	if(!empty($title)) {
		if(isset($settings['style']) && $settings['style'] == 'deployed' && isset($settings['enabled_numeric_title']) && $settings['enabled_numeric_title'] == 'yes') {
			echo '<'.$settings['additional_news_title_html_tag'].' class="box-name widget-title"><div class="dfd-number-decor">'.esc_html($i).'</div>' . $title . '</'.$settings['additional_news_title_html_tag'].'>';
		} else {
			echo '<'.$settings['additional_news_title_html_tag'].' class="box-name widget-title">' . $title . '</'.$settings['additional_news_title_html_tag'].'>';
		}
	}
	?>
	<div class="dfd-meta-wrap">
		<?php get_template_part('templates/entry-meta', 'post-bottom'); ?>
	</div>
	<?php
echo '</div>';
