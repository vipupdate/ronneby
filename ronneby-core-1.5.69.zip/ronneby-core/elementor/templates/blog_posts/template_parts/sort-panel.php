<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$taxonomy = 'category';

$categories = get_terms($taxonomy);

echo '<div class="clearfix">';
	echo '<div class="sort-panel '.esc_attr($settings['sort_alignment']).'">';
		echo '<ul class="filter">';
			echo '<li class="active"><a data-filter=".post" href="#">'. __('All', 'dfd') .'</a></li>';
			foreach ($categories as $category) {
				echo '<li><a data-filter=".post[data-category~=\'' . strtolower(preg_replace('/\s+/', '-', $category->slug)) . '\']" href="#">' . $category->name . '</a></li>';
			}
		echo '</ul>';
	echo '</div>';
echo '</div>';