<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if($enable_title || $enable_meta) {
	echo '<div class="dfd-blog-heading-wrap">';
	if($enable_title) {
		$title = get_the_title();

		if(isset($permalink) && !empty($permalink)) {
			$title = '<a href="'.esc_url($permalink).'" title="'.esc_attr($title).'">'.esc_html($title).'</a>';
		}

		if($enable_cat) {
			echo '<div class="dfd-news-categories">';
				get_template_part('templates/entry-meta/mini', 'category-highlighted');
			echo '</div>';
		}

		if(!empty($title)) {
			if(isset($settings['style']) && $settings['style'] == 'deployed' && isset($settings['enabled_numeric_title']) && $settings['enabled_numeric_title'] !== 'yes') {
				echo '<'.$settings['title_html_tag'].' class="dfd-blog-title widget-title"><div class="dfd-number-decor">'.esc_html($i).'</div>' . $title . '</'.$settings['title_html_tag'].'>';
			} else {
				echo '<'.$settings['title_html_tag'].' class="dfd-blog-title widget-title">' . $title . '</'.$settings['title_html_tag'].'>';
			}
		}
	}
	if($enable_meta) {
	?>
		<div class="dfd-meta-wrap">
			<?php get_template_part('templates/entry-meta', 'post-bottom'); ?>
		</div>
	<?php
	}
	echo '</div>';
}