<?php
if(!defined('ABSPATH')) {
	exit;
}

# Including theme components
require_once get_template_directory().'/inc/includes.php';

if(defined('ELEMENTOR_VERSION')) {
	define('DFD_ELEMENTOR', true);
}