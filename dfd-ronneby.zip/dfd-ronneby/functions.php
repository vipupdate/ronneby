<?php
if(!defined('ABSPATH')) {
	exit;
}

# Including theme components
require_once get_template_directory().'/inc/includes.php';

if(defined('ELEMENTOR_VERSION')) {
	define('DFD_ELEMENTOR', true);
}

update_site_option('dfd_ronneby_theme_activated', 'active');
update_site_option('dfd_ronneby_purchase_code', '80ebcaa2-49e6-47e9-891f-642b999d0ebc');