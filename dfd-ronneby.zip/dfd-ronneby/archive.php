<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_template_part('index');