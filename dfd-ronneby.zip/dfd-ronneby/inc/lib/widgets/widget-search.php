<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class crum_search_widget extends WP_Widget {
	function __construct() {
		parent::__construct(
            'crum_search_widget', // Base ID
            'Widget: Search widget', // Name
            array(
				'classname' => 'widget_search',
                'description' => esc_html__('Search widget', 'dfd')
            ) // Args
        );
	}

	function widget($args, $instance) {
		$title = $text = '';
		//get theme options

		extract($args);
		
		if (isset($instance['title'])) {
			$title = $instance['title'];
		}
		if (isset($instance['text'])) {
			$text = $instance['text'];
		}

		/* show the widget content without any headers or wrappers */

		echo wp_kses_post($before_widget);

		if ($title) {
			echo wp_kses_post($before_title . $title . $after_title);
		}
		?>

		<?php $id_s = uniqid('s_'); ?>
		<form role="search" method="get" id="<?php echo esc_attr(uniqid('searchform_')); ?>" class="form-search" action="<?php echo home_url('/'); ?>">
			<label class="hide" for="<?php echo esc_attr($id_s); ?>"><?php esc_html_e('Search for:', 'dfd'); ?></label>
			<input type="text" value="" name="s" id="<?php echo esc_attr($id_s); ?>" class="s-field" placeholder="<?php echo esc_attr($text); ?>">
			<input type="submit" value="<?php esc_html_e('Search', 'dfd'); ?>" class="btn">
		</form>

		<?php
		echo wp_kses_post($after_widget);
	}

	function update($new_instance, $old_instance) {

		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);

		/* Strip tags (if needed) and update the widget settings. */

		$instance['text'] = strip_tags($new_instance['text']);

		return $instance;
	}

	function form($instance) {

		$title = isset($instance['title']) ? apply_filters('widget_title', $instance['title']) : '';

		$text = isset($instance['text']) ? $instance['text'] : '';

		/* Set up some default widget settings. */

		$defaults = array('text' => 'Enter request...');

		$instance = wp_parse_args((array) $instance, $defaults);
		?>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'dfd'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Placeholder', 'dfd'); ?></label><br/>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>" type="text" value="<?php echo esc_attr($text); ?>"/>
		</p>

		<?php
	}
}