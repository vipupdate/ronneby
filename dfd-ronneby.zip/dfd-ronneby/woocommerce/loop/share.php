<?php 
if(class_exists('YITH_WCWL')) {
	wc_get_template_part('add-to-wishlist-button');
}