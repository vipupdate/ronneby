<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_template_part('templates/portfolio/entry-meta'); ?>
<?php /*
<a href="<?php the_permalink(); ?>" class="hover-link"> </a>

<div class="social-share animate-all"><?php echo Dfd_Theme_Helpers::getPostLikeLink(); ?></div>
 */