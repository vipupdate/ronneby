<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span><?php echo Dfd_Theme_Helpers::postsViewCounter(get_the_id()); ?></span>