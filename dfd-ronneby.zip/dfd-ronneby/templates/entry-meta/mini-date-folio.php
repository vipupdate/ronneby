<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span class="entry-date"><span class="entry-title"><?php esc_html_e('Date:', 'dfd'); ?></span><?php echo get_the_date(); ?></span>