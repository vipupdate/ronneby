<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span class="delim blank"></span>