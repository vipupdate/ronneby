<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="social-share animate-all"><?php echo Dfd_Theme_Helpers::getPostLikeLink(); ?></div>