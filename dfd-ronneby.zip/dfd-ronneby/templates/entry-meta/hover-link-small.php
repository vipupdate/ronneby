<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<a href="<?php the_permalink(); ?>" class="hover-link small">
	<i class="icon-add-1"></i>
</a>