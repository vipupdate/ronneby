<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span class="delim"></span>