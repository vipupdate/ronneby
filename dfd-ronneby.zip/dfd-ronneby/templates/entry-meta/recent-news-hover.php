<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="hover-link">
	<a class="box-name" href="<?php echo the_permalink(); ?>"><?php echo the_title(); ?></a>
</div>
