<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="entry-meta meta-top">
	<?php
		get_template_part('templates/entry-meta/mini', 'like');
	?>
</div>