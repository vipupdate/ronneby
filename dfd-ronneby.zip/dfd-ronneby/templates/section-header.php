<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<?php get_template_part('templates/header/panel-inner'); ?>
<?php get_template_part('templates/header/style', Dfd_Theme_Helpers::getHeaderStyleOption()); ?>