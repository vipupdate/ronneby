<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="entry-meta">
	<?php get_template_part('templates/entry-meta/mini', 'category'); ?>
</div>