<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="side-area-controller-wrap">
	<a href="#" id="dfd-menu-button">
		<span class="icon-wrap dfd-middle-line"></span>
		<span class="icon-wrap dfd-top-line"></span>
		<span class="icon-wrap dfd-bottom-line"></span>
	</a>
</div>