<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="form-search-section" style="display: none;">
	<div class="row">
		<?php echo get_template_part('templates/searchform'); ?>
	</div>
</div>