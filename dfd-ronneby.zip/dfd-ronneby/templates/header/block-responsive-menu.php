<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="dl-menuwrapper">
	<a href="#sidr" class="dl-trigger icon-mobile-menu dfd-vertical-aligned" id="mobile-menu" aria-label="Open mobile menu">
		<span class="icon-wrap dfd-middle-line"></span>
		<span class="icon-wrap dfd-top-line"></span>
		<span class="icon-wrap dfd-bottom-line"></span>
	</a>
</div>