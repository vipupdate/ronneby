<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="entry-meta dopinfo">
	<?php get_template_part('templates/entry-meta/mini', 'author'); ?>
	<?php get_template_part('templates/entry-meta/mini', 'delim-blank'); ?>
	<?php get_template_part('templates/entry-meta/mini', 'comments'); ?>
</div>