<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_filter( 'wpml_pb_shortcode_encode', 'ronneby_wpml_pb_custom_shortcode_encode', 10, 3);

function ronneby_wpml_pb_custom_shortcode_encode($string, $encoding, $original_string) {
    if ('ronneby_urlencoded_json' === $encoding) {
        $output = array();
        foreach ($original_string as $combined_key => $value) {
            $parts = explode('_', $combined_key);
            $i = array_pop($parts);
            $key = implode('_', $parts);
            $output[$i][$key] = $value;
        }
        $string = rawurlencode(json_encode($output));
    }
    return $string;
}

add_filter('wpml_pb_shortcode_decode', 'ronneby_wpml_pb_custom_shortcode_decode', 10, 3);

function ronneby_wpml_pb_custom_shortcode_decode($string, $encoding, $original_string) {
	if ('ronneby_urlencoded_json' === $encoding) {
		$rows = json_decode(urldecode($original_string), true);
		$string = array();
		$translate_fields = array(
			'icon_text',
			'block_title',
			'block_subtitle',
			'block_content',
			'label',
			'title',
			'subtitle',
			'testimonial_text',
			'block_date',
			'text_field',
			'text_fields',
			'info_text',
			'price',
			'hotspot_data',
			'Title',
            'Message',
		);
		foreach ($rows as $i => $row) {
			foreach ($row as $key => $value) {
				if (in_array($key, $translate_fields)) {
					$string[$key . '_' . $i] = array('value' => $value, 'translate' => true);
				} else {
					$string[$key . '_' . $i] = array('value' => $value, 'translate' => false);
				}
			}
		}
	}
	return $string;
}
