<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require(locate_template('templates/blog-media.php'));